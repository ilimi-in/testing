'use strict';

module.exports = (router) => ({
  reference: require('./reference')(router),
});
