'use strict';

module.exports = {
  machineName: require('./machineName'),
  timestamps: require('./timestamps'),
};
