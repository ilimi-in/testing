<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Org_1/Home/task_list.twig */
class __TwigTemplate_08b203b01bdcf614f8ae4a630aadce5a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'scriptBlock' => [$this, 'block_scriptBlock'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "Org_1/Layout/app_home.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("Org_1/Layout/app_home.twig", "Org_1/Home/task_list.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 3
        echo "
  <section class=\"\">
        <div class=\"pathwaytable-section\">

            <div >

                <div class=\"d-flex justify-content-between custom-ul pathwayheader\">

                    <ul class=\"mb-0\">
                        <li>
                            <h1 class=\"serifb-text\">";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("pathways"), "html", null, true);
        echo "</h1>
                        </li>
                    </ul>

                </div>


                <ul class=\"nav nav-tabs customtab\" id=\"myTab\" role=\"tablist\">
                    <li class=\"nav-item\" role=\"presentation\">
                        <a class=\"nav-link active\" id=\"home-tab\" data-bs-toggle=\"tab\"
                            href=\"#home-tab-pane\" type=\"button\" role=\"tab\" aria-controls=\"home-tab-pane\"
                            aria-selected=\"true\" onclick=\"loadFilter()\">";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("drafts"), "html", null, true);
        echo "</a>
                    </li>
                    <li class=\"nav-item\" role=\"presentation\">
                        <a class=\"nav-link\" id=\"profile-tab\" data-bs-toggle=\"tab\"
                            href=\"#home-tab-pane\" type=\"button\" role=\"tab\" aria-controls=\"home-tab-pane\"
                            aria-selected=\"false\" onclick=\"loadFilter()\">";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("published"), "html", null, true);
        echo "</a>
                    </li>
                </ul>
                <div class=\"tab-content\" id=\"myTabContent\">
                    <div class=\"tab-pane fade show active\" id=\"home-tab-pane\" role=\"tabpanel\" aria-labelledby=\"home-tab\"
                        tabindex=\"0\">


                        <div class=\"d-flex justify-content-between custom-ul pathwaysubhead\">

                            <ul class=\"mb-0\">
                                <li>
                                </li>
                            </ul>
                            <ul class=\"mb-0\">
                                <li><span  id=\"download_btn\" class=\"secondarybtn-fade mgr-20\" data-download=\"no\" onclick=\"downloadPathwayExl(this)\">";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("download"), "html", null, true);
        echo "</span></li>
                                <li>
                                    <a href=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("newFormRender", ["lang" => ($context["lang"] ?? null), "formName" => "pwc-create-pathway
"]), "html", null, true);
        // line 47
        echo "
\" class=\"primarybtn\"> Add Pathway </a>
                                </li>
                                
                            </ul>
                        </div>


                        <div class=\"custom-ul filtersection\">

                            <ul class=\"mb-0 searchsection\">
                                <li class=\"pathwaysearch-row position-relative\">
                                    <input type=\"text\" class=\"form-control\" id=\"filterTextBox\"
                                        aria-describedby=\"search\" placeholder=\"Search pathway\" onkeyup=\"loadSearchFilter()\">
                                    <img class=\"pathwaysearchinput-icon\" src=\"";
        // line 61
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "images/search-icon.svg\" alt=\"\" id=\"searchBoxImgIcon\" style=\"cursor:pointer;\">
                                </li>
                                <li>

                                </li>
                            </ul>
                            <ul class=\"mb-0 dropdown-row mt-32\">

                                <li>
                                <label class=\"filter-bar\">";
        // line 70
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("filter"), "html", null, true);
        echo "</label>
                                </li>

                                <li>
                                    <div class=\"dropdown\">
                                        <button class=\"btn btn-secondary dropdown-toggle\" type=\"button\"
                                            aria-expanded=\"false\" id=\"durationBtn\">
                                            ";
        // line 77
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        echo "
                                        </button>
                                     <ul class=\"dropdown-menu\" id=\"duration\">
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"form-check-label\" for=\"check_duration_selectall\" id=\"level_duration_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_duration_selectall\" onclick=\"selectAll('duration', this)\"> ";
        // line 83
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("selectAll"), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t";
        // line 86
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["duration"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["d_value"]) {
            // line 87
            echo "                                            <li class=\"dropdown-item bdr-row\"><div class=\"form-check\">
                                                    
                                                    <label class=\"form-check-label\" for=\"check_child_";
            // line 89
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\" id=\"level_child_";
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_child_";
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\" onclick=\"selectAll('', this, 'check_duration_selectall')\"> ";
            echo twig_escape_filter($this->env, $context["d_value"], "html", null, true);
            echo "</label>
                                                </div>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['d_value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 93
        echo "\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\"></li>
\t\t\t\t\t\t\t\t\t\t<li><button type=\"button\" class=\"cancelbtn d-inline\" id=\"cancelbtn\">Cancel</button>
                                        <button type=\"submit\" class=\"publishbtn d-inline\" id=\"submit\" onclick=\"addSelection()\">";
        // line 95
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("apply"), "html", null, true);
        echo "</button></li>
                                        </ul>
                                    </div>
                                </li> 
                                <li>
                                    <div class=\"dropdown\">
                                        <button class=\"btn btn-secondary dropdown-toggle level\" type=\"button\"
                                             aria-expanded=\"false\" id=\"levelBtn\">
                                            Level
                                        </button>\t\t\t\t\t\t\t\t\t\t
                                        <ul class=\"dropdown-menu\" id=\"level_sel_id\">\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t";
        // line 106
        if ((twig_length_filter($this->env, ($context["level"] ?? null)) > 0)) {
            $context["nos"] = 1;
            // line 107
            echo "\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"form-check-label\" for=\"check_avl_selectall\" id=\"level_avl_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_avl_selectall\" onclick=\"selectAll('level_sel_id', this)\"> ";
            // line 109
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("selectAll"), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t             \t";
            // line 112
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["level"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["data"]) {
                // line 113
                echo "\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\">
                                                <div class=\"form-check\">                                                    
                                                    <label class=\"form-check-label\" for=\"check_child_";
                // line 115
                echo twig_escape_filter($this->env, ($context["nos"] ?? null), "html", null, true);
                echo "\" id=\"level_child_";
                echo twig_escape_filter($this->env, ($context["nos"] ?? null), "html", null, true);
                echo "\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_child_";
                echo twig_escape_filter($this->env, ($context["nos"] ?? null), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 115), "html", null, true);
                echo "</label>
                                                </div>
                                            </li> ";
                // line 117
                $context["nos"] = (($context["nos"] ?? null) + 1);
                // line 118
                echo "\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['data'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 119
            echo "\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\"></li>
\t\t\t\t\t\t\t\t\t\t<li><button type=\"button\" class=\"cancelbtn d-inline\" id=\"cancelbtn\" onclick=\"\$('#level_sel_id').removeClass('show')\">Cancel</button>
                                        <button type=\"submit\" class=\"publishbtn d-inline\" id=\"submit\" onclick=\"addSelection()\">";
            // line 121
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("apply"), "html", null, true);
            echo "</button></li>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 123
        echo "\t\t\t\t\t\t\t\t\t\t
                                        </ul>\t\t\t\t\t\t\t\t\t\t
                                    </div>
                                </li>
\t\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\t\tfunction searchInList(obj){
\t\t\t\t\t\t\t\t\t\t if(obj.value.length >= 2){
\t\t\t\t\t\t\t\t\t\t\t var avl_length = '";
        // line 130
        echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["availability"] ?? null)), "html", null, true);
        echo "';
\t\t\t\t\t\t\t\t\t\t \t \$('#avail_menu').find('li').each(function(){
\t\t\t\t\t\t\t\t\t\t\t\t 
\t\t\t\t\t\t\t\t\t\t\t\tif(\$(this).index() > 1){ \t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t\$(this).hide();
\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t\t\t });
\t\t\t\t\t\t\t\t\t\t\t var txt = \$.trim(obj.value).toLowerCase();
\t\t\t\t\t\t\t\t\t\t\t //var s = \"India\";
\t\t\t\t\t\t\t\t\t\t\t\$('#avail_menu').find('li').each(function(){
\t\t\t\t\t\t\t\t\t\t\t\tvar str= \$.trim(\$(this).text());
\t\t\t\t\t\t\t\t\t\t\t\tif (str.toLowerCase().indexOf(txt) >= 0){
\t\t\t\t\t\t\t\t\t\t\t\t\t \$(this).show();
\t\t\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t\t\t});
\t\t\t\t\t\t\t\t\t\t\t//alert(txt);
\t\t\t\t\t\t\t\t\t\t\t \$('#avail_menu #avl_applybtn').show();

\t\t\t\t\t\t\t\t\t\t\t 

\t\t\t\t\t\t\t\t\t\t }else{
\t\t\t\t\t\t\t\t\t\t \t\$('#avail_menu').find('li').each(function(){
\t\t\t\t\t\t\t\t\t\t\t\t 
\t\t\t\t\t\t\t\t\t\t\t\tif(\$(this).index() > 1){ \t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t\$(this).show();
\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t\t\t });
\t\t\t\t\t\t\t\t\t\t }
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t</script>
                                <li>
                                    <div class=\"dropdown\">
                                        <button class=\"btn btn-secondary dropdown-toggle\" type=\"button\"
                                             aria-expanded=\"false\" id=\"avlBtn\">
                                            Availability
                                        </button>
                                        <ul class=\"dropdown-menu\" id=\"avail_menu\">

                                        <li class=\"dropdown-item pos-r\">
                                        <input type=\"text\" class=\"form-control-search\" placeholder=\"Search\" onkeyup=\"searchInList(this)\">

                                        <i class=\"filter-searchicon\"></i>
                                        </li>

\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">                                                    
                                                    <label class=\"form-check-label\" for=\"avl_selectall\" id=\"level_avl_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"avl_selectall\" onclick=\"selectAll('avail_menu', this)\">";
        // line 180
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("selectAll"), "html", null, true);
        echo "</label>
                                                </div>
\t\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t\t";
        // line 184
        if ((twig_length_filter($this->env, ($context["availability"] ?? null)) > 0)) {
            echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t             \t";
            // line 185
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["availability"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["data"]) {
                // line 186
                echo "                                             
\t\t\t\t\t\t\t\t\t\t\t <li class=\"dropdown-item bdr-row\">
                                                <div class=\"form-check\">
                                                    <input type=\"checkbox\" class=\"form-check-input\" id=\"avl_";
                // line 189
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 189), "html", null, true);
                echo "\" onclick=\"selectAll('', this, 'avl_selectall')\">
                                                    <label class=\"form-check-label\" for=\"avl_";
                // line 190
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 190), "html", null, true);
                echo "\" id=\"level_avl_";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 190), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 190), "html", null, true);
                echo "</label>
                                                </div>
                                            </li>
                                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['data'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 194
            echo "\t\t\t\t\t\t\t\t\t\t<li class=\"filter-btnrow\" id=\"avl_applybtn\">
                                        <button type=\"button\" class=\"cancelbtn d-inline\"  style=\"cursor:pointer\" onclick=\"\">";
            // line 195
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("cancel"), "html", null, true);
            echo "</button>
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"publishbtn d-inline\"  onclick=\"addSelection()\">";
            // line 196
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("apply"), "html", null, true);
            echo "</button></li>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 198
        echo "                                        </ul>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"dropdown\" id=\"pathway_type_menu\">
                                        <button class=\"btn btn-secondary dropdown-toggle\" type=\"button\"
                                             aria-expanded=\"false\" id=\"ptypeBtn\">
                                            ";
        // line 205
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("pathwayType"), "html", null, true);
        echo "
                                        </button>
                                        <ul class=\"dropdown-menu\" id=\"pathway_menu\">
\t\t\t\t\t\t\t\t\t\t";
        // line 208
        if ((twig_length_filter($this->env, ($context["pathway_type"] ?? null)) > 0)) {
            // line 209
            echo "\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"form-check-label\" for=\"check_pathway_selectall\" id=\"level_pathway_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_pathway_selectall\" onclick=\"selectAll('pathway_menu', this)\"> ";
            // line 212
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("selectAll"), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t             \t";
            // line 215
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["pathway_type"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["data"]) {
                echo "                                            
\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\">
                                                <div class=\"form-check\">                                                    
                                                    <label class=\"form-check-label\" for=\"ptype_";
                // line 218
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 218), "html", null, true);
                echo "\" id=\"level_ptype_";
                echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 218), [" " => "-"]), "html", null, true);
                echo "\"><input type=\"checkbox\" class=\"form-check-input\" id=\"ptype_";
                echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 218), [" " => "-"]), "html", null, true);
                echo "\" onclick=\"selectAll('', this, 'check_pathway_selectall')\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "value_of_data", [], "any", false, false, false, 218), "html", null, true);
                echo "</label>
                                                </div>
                                            </li>
\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['data'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 222
            echo "\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\"></li>
\t\t\t\t\t\t\t\t\t\t<li><button type=\"button\" class=\"cancelbtn d-inline\"  style=\"cursor:pointer\" onclick=\"\">";
            // line 223
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("cancel"), "html", null, true);
            echo "</button>
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"publishbtn d-inline\"  onclick=\"addSelection()\">";
            // line 224
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("apply"), "html", null, true);
            echo "</button></li>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 226
        echo "                                        </ul>
                                    </div>
                                </li>

                                <li>
                                    <div class=\"dropdown\">
                                        <button class=\"btn btn-secondary dropdown-toggle\" type=\"button\"
                                            aria-expanded=\"false\" id=\"statusBtn\">
                                            ";
        // line 234
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status"), "html", null, true);
        echo "
                                        </button>
                                        <ul class=\"dropdown-menu\" id=\"status_menu\">
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"form-check-label\" for=\"check_status_selectall\" id=\"level_status_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_status_selectall\" onclick=\"selectAll('status_menu', this)\"> ";
        // line 240
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("selectAll"), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\" >
                                                <div class=\"form-check\">
                                                    
                                                    <label class=\"form-check-label\" for=\"check_active\" id=\"level_active\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_active\" onclick=\"selectAll('', this, 'check_status_selectall')\"> ";
        // line 246
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("active"), "html", null, true);
        echo "</label>
                                                </div>
                                            </li>
\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\">
                                                <div class=\"form-check\">
                                                    
                                                    <label class=\"form-check-label\" for=\"check_inactive\" id=\"level_inactive\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_inactive\" onclick=\"selectAll('', this, 'check_status_selectall')\"> ";
        // line 252
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("inactive"), "html", null, true);
        echo "</label>
                                                </div>
                                            </li>
\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\"></li>
                                            <li><button type=\"button\" class=\"cancelbtn d-inline\"  style=\"cursor:pointer\">";
        // line 256
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("cancel"), "html", null, true);
        echo "</button>
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"publishbtn d-inline\"  onclick=\"addSelection()\">";
        // line 257
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("apply"), "html", null, true);
        echo "</button></li>                                                                                         
                                        </ul>
                                    </div>
                                </li>
                            </ul>
\t\t\t\t\t\t\t<ul class=\"mb-0 mt-32\" id=\"fSelSection\" style=\"display:none\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<label class=\"filter-bar\">Selected</label>
                                </li> 
                            </ul>
\t\t\t\t\t\t
                        </div>

\t\t\t\t\t\t<!-- ############### -->
\t\t\t\t\t\t<div class=\"task-list-data\">
\t\t\t\t\t\t   <div class=\"spinner-border\" role=\"status\" style=\"margin:50px 0px 0px 50%\">
\t\t\t\t\t\t\t  <span class=\"visually-hidden\">Loading...</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- ################ -->

                    </div>
                    <div class=\"tab-pane fade\" id=\"profile-tab-pane\" role=\"tabpanel\" aria-labelledby=\"profile-tab\"
                        tabindex=\"0\">


<div class=\"pathwaytable\">
                        <table class=\"table pathwaytable\">
                            <thead>
                                <tr>
                                    <th scope=\"col\">
                                        <input class=\"form-check-input\" type=\"checkbox\" value=\"\" id=\"flexCheckDefault\">
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"";
        // line 290
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "images/sorting-icon.svg\" alt=\"\"> ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("title"), "html", null, true);
        echo "
                                    </th>
                                    <th scope=\"col\"> <img class=\"sorting-btn\" src=\"";
        // line 292
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "images/sorting-icon.svg\" alt=\"\"> ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        echo "
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"";
        // line 294
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "images/sorting-icon.svg\" alt=\"\"> Level
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"";
        // line 296
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "images/sorting-icon.svg\" alt=\"\"> Availability
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"";
        // line 298
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "images/sorting-icon.svg\" alt=\"\"> ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("pathwayType"), "html", null, true);
        echo "
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"";
        // line 300
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "images/sorting-icon.svg\" alt=\"\"> ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status"), "html", null, true);
        echo "</th>
                                    <th scope=\"col\">";
        // line 301
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("actions"), "html", null, true);
        echo "</th>
                                </tr>
                            </thead>                            
                            <tbody id=\"fbody1\">     
                            ";
        // line 305
        if ((twig_length_filter($this->env, ($context["pathwayListPub"] ?? null)) > 0)) {
            echo "                         
                            ";
            // line 306
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["pathwayListPub"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["data"]) {
                echo "   

                                <tr>
                                    <th scope=\"row\" class=\"move-btnrow\">
                                        <input class=\"form-check-input\" type=\"checkbox\" value=\"\" id=\"flexCheckDefault\">
                                        <!-- <a href=\"#\" class=\"\"> <img src=\"images/moveup-icon.svg\" alt=\"\"></a>
                                        <a href=\"#\" class=\"\"><img src=\"images/movedown-icon.svg\" alt=\"\"></a> -->
                                    </th>
                                    <td>";
                // line 314
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "title", [], "any", false, false, false, 314), "html", null, true);
                echo "</td>
                                    
                                    <td>";
                // line 316
                echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "duration", [], "any", false, false, false, 316)), "html", null, true);
                echo "</td>
                                    <td>";
                // line 317
                echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "proficency_level", [], "any", false, false, false, 317)), "html", null, true);
                echo "</td>
                                    <td>";
                // line 318
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "availability", [], "any", false, false, false, 318), "html", null, true);
                echo "</td>
                                    ";
                // line 319
                if ((twig_get_attribute($this->env, $this->source, $context["data"], "pathway_type", [], "any", false, false, false, 319) == "completionRule")) {
                    // line 320
                    echo "                                    <td>";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("completionRules"), "html", null, true);
                    echo "</td>
                                    ";
                } else {
                    // line 322
                    echo "                                    <td>";
                    echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "pathway_type", [], "any", false, false, false, 322)), "html", null, true);
                    echo "</td>
                                    ";
                }
                // line 323
                echo " 


                                    ";
                // line 326
                if ((twig_get_attribute($this->env, $this->source, $context["data"], "is_active", [], "any", false, false, false, 326) == "1")) {
                    // line 327
                    echo "                                    <td>";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("active"), "html", null, true);
                    echo "</td>
                                    ";
                } elseif ((twig_get_attribute($this->env, $this->source,                 // line 328
$context["data"], "is_active", [], "any", false, false, false, 328) == "2")) {
                    // line 329
                    echo "                                    <td>";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("inactive"), "html", null, true);
                    echo "</td>
                                    ";
                }
                // line 330
                echo " 
                                    <!--<td><a href=\"";
                // line 331
                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("pathwayDetails", ["id" => twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 331), "lang" => ($context["lang"] ?? null)]), "html", null, true);
                echo "\" class=\"table-circlebtn \"> <img src=\"images/more-icon.svg\" alt=\"\">
                                        </a></td> -->
                                     <td>
                                        <div class=\"dropdown elipses-btn\">
                                            <a class=\"table-circlebtn dropdown-toggle\" href=\"#\" role=\"button\"
                                                data-bs-toggle=\"dropdown\" aria-expanded=\"false\">
                                                <img src=\"";
                // line 337
                echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                echo "images/more-icon.svg\" alt=\"\">
                                            </a>

                                            <ul class=\"dropdown-menu\">
                                                <li><a class=\"dropdown-item\" href=\"#\">";
                // line 341
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("previewPathway"), "html", null, true);
                echo " </a></li>
                                                <li><a class=\"dropdown-item\" href=\"";
                // line 342
                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("editDraft", ["id" => twig_get_attribute($this->env, $this->source, $context["data"], "mongo_id", [], "any", false, false, false, 342), "form_type" => "pwc-create-pathway", "lang" => ($context["lang"] ?? null)]), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("editDetails"), "html", null, true);
                echo " </a></li>
                                                <li><a class=\"dropdown-item\" href=\"";
                // line 343
                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("pathwayDetails", ["id" => twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 343), "lang" => ($context["lang"] ?? null)]), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("editPathway"), "html", null, true);
                echo " </a></li>
                                                <li><a class=\"dropdown-item\" href=\"#\">";
                // line 344
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("managePeople"), "html", null, true);
                echo " </a></li>

                                                ";
                // line 346
                if ((twig_get_attribute($this->env, $this->source, $context["data"], "is_active", [], "any", false, false, false, 346) == "1")) {
                    // line 347
                    echo "                                                <li class=\"inactive\" id=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 347), "html", null, true);
                    echo "\" data-active=\"inactive\"><a class=\"dropdown-item\" href=\"javascript:void(0)\" onclick=\"changeStatus('";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 347), "html", null, true);
                    echo "', 'inactive')\">";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("makePathwayInactive"), "html", null, true);
                    echo "</a></li>
                                                ";
                } elseif ((twig_get_attribute($this->env, $this->source,                 // line 348
$context["data"], "is_active", [], "any", false, false, false, 348) == "2")) {
                    // line 349
                    echo "                                                <li class=\"inactive\" id=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 349), "html", null, true);
                    echo "\" data-active=\"active\"><a class=\"dropdown-item\" href=\"javascript:void(0)\" onclick=\"changeStatus('";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 349), "html", null, true);
                    echo "', 'active')\">";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("makePathwayActive"), "html", null, true);
                    echo "</a></li>
                                                ";
                }
                // line 351
                echo "                                                <li class=\"copyPathway\" id=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 351), "html", null, true);
                echo "\" ><a class=\"dropdown-item\" href=\"javascript:void(0)\" onclick=\"copyPathway('";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 351), "html", null, true);
                echo "', 'active')\">";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("makeACopy"), "html", null, true);
                echo "</a></li>  



                                            </ul>
                                        </div>
                                    </td>
                                </tr> 
                                
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['data'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 360
            echo "                        
                                ";
        } else {
            // line 362
            echo "                                  <tr>
                                      <td> <p>No record found.</p></td>
                                  </tr>
                                ";
        }
        // line 366
        echo "                            </tbody>
                            
                        </table>

                    </div>
                    </div>
                </div>





            </div>
        </div>
    </section>   


 <div id=\"myModal\" class=\"modal\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
          <div class=\"modal-header\">
            <!-- <h1 class=\"modal-title fs-5\" id=\"exampleModalLabel\">Delete Learning Object?</h1> -->
            <button type=\"button\" id=\"closelBtnLO\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
          </div>
          <div class=\"modal-body\">
             <p>Are you sure you want to <span id=\"statusText\"></span> this item?</p>
        </div>

        <div class=\"modal-footer\">
            <button id=\"cancelBtn\" class=\"cancelbtn\">";
        // line 395
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("cancel"), "html", null, true);
        echo "</button>
            <button id=\"confirmBtn\" class=\"deletebtn\">";
        // line 396
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("yes"), "html", null, true);
        echo "</button>
            
          </div>
      </div>
    </div> 

</div>
    
";
    }

    // line 406
    public function block_scriptBlock($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 407
        echo " <script>
 function changeStatus(id, active){
\t//var id = \$(li).attr('id');

    //var active = \$(li).attr('data-active');
\tif(active=='active'){
\t\t\$('#statusText').text('activate');
\t}else{
\t\t\$('#statusText').text('inactivate');
\t}
    \$(\"#myModal\").show();
      
    \$(\"#cancelBtn\").click(function(){
        \$(\"#myModal\").hide();
        return false;
    });

      \$(\"#confirmBtn\").click(function(){
         \$.ajax({
                url: '";
        // line 426
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("inactivatePathway"), "html", null, true);
        echo "',
                type: 'POST',
                data: {'id': id,'active': active},
                success: function success(response) {
                  if (response.success) {
                    location.reload();
                    } else {
                       
                    }
                }               
              });
        \$(\"#myModal\").hide();
      });
 
 }
document.querySelectorAll(\".inactive\").forEach(function(li) {
    li.addEventListener(\"click\", function() {
    var id = \$(li).attr('id');

    var active = \$(li).attr('data-active');

    \$(\"#myModal\").show();
      
    \$(\"#cancelBtn\").click(function(){
        \$(\"#myModal\").hide();
        return false;
    });

      \$(\"#confirmBtn\").click(function(){
         \$.ajax({
                url: '";
        // line 456
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("inactivatePathway"), "html", null, true);
        echo "',
                type: 'POST',
                data: {'id': id,'active': active},
                success: function success(response) {
                  if (response.success) {
                    location.reload();
                    } else {
                       
                    }
                }               
              });
        \$(\"#myModal\").hide();
      });
  
      
  
    });
});


 function copyPathway(id, active){
    
     // \$(\"#confirmBtn\").click(function(){
         \$.ajax({
                url: '";
        // line 480
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("copyPathway"), "html", null, true);
        echo "',
                type: 'POST',
                data: {'id': id},
                success: function success(response) {
                  if (response.success) {
                    location.reload();
                    } else {
                       
                    }
                }               
              });
        //\$(\"#myModal\").hide();
     // });
 
 }

  


\$(function() {
  
  \$('a[data-bs-toggle=\"tab\"]').on('shown.bs.tab', function (e) {
    localStorage.setItem('lastTab', \$(this).attr('href'));
  });
  var lastTab = localStorage.getItem('lastTab');
  
  if (lastTab) {
    \$('[href=\"' + lastTab + '\"]').tab('show');
  }
  
});


function loadPagingData(page_no, move=''){
\t\$('.task-list-data').html('<div class=\"spinner-border\" role=\"status\" style=\"margin:50px 0px 0px 50%\"><span class=\"visually-hidden\">Loading...</span></div>');
\t\$.ajax({
\t   url: 'task-list-data?page='+page_no+((move=='yes')?'&move=y':''),
\t\ttype: 'POST',
\t\tdata: {'level':'', 'is_published' : 0},                
\t\tsuccess: function success(response) {
\t\t\t//console.log('non',response); return;
\t\t\t\$('.task-list-data').html('');
\t\t\t\$('.task-list-data').append(response);
\t\t\t
\t\t},
\t\terror: function error(err) {
\t\t\tif (err.status == 401) {
\t\t\t\tlocation.reload();
\t\t\t}
\t\t}
\t});

}

\$(document).ready(function () {
\t\$('ul#myTab  a#home-tab').addClass('active');
\t\$('ul#myTab  a#profile-tab').removeClass('active');

\tlet pub = sessionStorage.getItem(\"published\");
\tif(pub == null){
\t\tsessionStorage.setItem(\"published\", \"0\");
\t\tpub=0;
\t}else if(pub == 1){
\t\t\$('ul#myTab  a#home-tab').removeClass('active');
\t\t\$('ul#myTab  a#profile-tab').addClass('active');
\t}
\t//\$(\".lds-spinner\").show();
\t
\t\$.ajax({
               url: 'task-list-data',
                type: 'POST',
                data: {'level':'', 'is_published' : pub},                
                success: function success(response) {
                    //console.log('non',response); return;
                    \$('.task-list-data').html('');
                    \$('.task-list-data').append(response);
                    
                },
                error: function error(err) {
                    if (err.status == 401) {
                        location.reload();
                    }
                }
            });
});
function getCookie(cname) {
  let name = cname + \"=\";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i <ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return \"\";
}
\$('#filterTextBox').keydown(function (event) {
    let keyPressed = event.keyCode || event.which;
    if (keyPressed === 13) {
       \t   loadSearchFilter();
    }
});

\$('#searchBoxImgIcon').click(loadSearchFilter);
function loadSearchFilter(){
\t loadFilter();

}
function selectAll(id='', obj='', selAll=''){
\tif(id != ''){
\t\t\$('#'+id+' li input[type=checkbox]').each(function(){
\t\t\t   if(obj.checked){
\t\t\t\t\t\$(this).prop('checked', true);
\t\t\t   }else{
\t\t\t\t \$(this).prop('checked', false);
\t\t\t   }
\t   
\t   });
\t}
\tif(!obj.checked && selAll != ''){
\t\t\$('#'+selAll).prop('checked', false);
\t}
\tevent.stopPropagation();
}
function addSelection(){
\t\$('.filtersection ul').removeClass('show');
\t\$('.filtersection button').removeClass('show');
\t\$('#fSelSection li').remove();
\t\$('#fSelSection').append('<li><label class=\"filter-bar\">Selected</label></li>');
\t\$('#fSelSection').show();
\t\$('#duration li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_child_'+idsArr[2]).text();
\t\tleveText = \$.trim(leveText);
\t\tif(leveText == ''){
\t\t\tleveText = \$('#level_'+idsArr[1]+'_'+idsArr[2]).text();
\t\t}
\t\t//alert(leveText);
\t\tif(\$.trim(leveText) == 'Select all'){
\t\t\tleveText = 'All Duration';
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"duration_li_'+idsArr[2]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'duration\\', \\''+idsArr[2]+'\\');loadFilter()\"></button></li>');
\t\t\treturn false;
\t\t}else{
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"duration_li_'+idsArr[2]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'duration\\', \\''+idsArr[2]+'\\');loadFilter()\"></button></li>');
\t\t}
\t});
\t\$('#level_sel_id li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_child_'+idsArr[2]).text();
\t\tif(leveText == ''){
\t\t\tleveText = \$('#level_'+idsArr[1]+'_'+idsArr[2]).text();
\t\t}
\t\tleveText = \$.trim(leveText);
\t\tif(leveText == 'Select all'){
\t\t\tleveText = 'All Level';
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"level_li_'+idsArr[2]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'level\\', \\''+idsArr[2]+'\\');loadFilter()\"></button></li>');
\t\t\treturn false;
\t\t}else{
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"level_li_'+idsArr[2]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'level\\', '+idsArr[2]+');loadFilter()\"></button></li>');
\t\t}
\t});
\t
\t\$('#avail_menu li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_avl_'+idsArr[1]).text();
\t\tleveText = \$.trim(leveText);
\t\tif(leveText=='Select all'){
\t\t\tleveText = 'All Countries';
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"avail_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'avail\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t\treturn false;
\t\t}else{
\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"avail_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'avail\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t}
\t});
\t\$('#pathway_type_menu li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_ptype_'+idsArr[1]).text();
\t\tleveText = \$.trim(leveText);
\t\tif(leveText == ''){
\t\t\tleveText = \$('#level_'+idsArr[1]+'_'+idsArr[2]).text();
\t\t}
\t\tif(\$.trim(leveText) == 'Select all'){
\t\t\tleveText = 'All Pathway Type';
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"ptype_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'ptype\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t\treturn false;
\t\t}else{

\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"ptype_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'ptype\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t}
\t});
\t\$('#status_menu li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_'+idsArr[1]).text();
\t\tleveText = \$.trim(leveText);
\t\tif(leveText == ''){
\t\t\tleveText = \$('#level_'+idsArr[1]+'_'+idsArr[2]).text();
\t\t}
\t\tif(\$.trim(leveText) == 'Select all'){
\t\t\tleveText = 'All Status';
\t\t   \$('#fSelSection').append('<li class=\"filterbar\" id=\"status_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'status\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t   return false;
\t\t}else{
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"status_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'status\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t}
\t});
\t\$('#fSelSection').append('<li><label class=\"clearfilters\" onclick=\"clearAllFil();loadFilter()\" style=\"cursor:pointer\">&nbsp;Clear all filters</label></li>');
\tloadFilter();
\t //if(\$('#check_child_'+id).is(':checked')){
\t \t// var leveText = \$('#level_child_'+id).text();
\t\t //\$('#fSelSection').append('<div class=\"alert alert-primary alert-dismissible fade show\" style=\"width:120px;\"><strong>'+leveText+'</strong><button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\"></button></div>');
\t //}

}
function removeElem(wFil, id){
\tif(wFil == 'duration'){
\t  \$('#duration_li_'+id).remove();
\t  
\t  \$('#check_child_'+id).prop('checked', false);
\t  if(id == 'selectall'){
\t  \t \$('#duration li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
\tif(wFil == 'level'){
\t  \$('#level_li_'+id).remove();
\t  
\t  \$('#check_child_'+id).prop('checked', false);
\t  if(id == 'selectall'){
\t  \t \$('#level_sel_id li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
\tif(wFil == 'status'){
\t  \$('#status_li_'+id).remove();\t  
\t  \$('#check_'+id).prop('checked', false);
\t  if(id == 'status'){
\t  \t \$('#status_menu li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
\tif(wFil == 'avail'){
\t  \$('#avail_li_'+id).remove();\t  
\t  \$('#avl_'+id).prop('checked', false);
\t  if(id == 'selectall'){
\t  \t \$('#avail_menu li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
\tif(wFil == 'ptype'){
\t  \$('#ptype_li_'+id).remove();\t  
\t  \$('#ptype_'+id).prop('checked', false);
\t   if(id == 'pathway'){
\t  \t \$('#pathway_menu li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
}
function clearAllFil(){
\t\$('#filterTextBox').val('');
\t\$('#fSelSection li').remove();
\t\$('#duration li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#level_sel_id li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#status_menu li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#avail_menu li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#pathway_type_menu li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#fSelSection').append('<li><label class=\"filter-bar\">Selected</label></li>');
\t\$('#fSelSection').hide();
}
function loadFilter(obj='', sort=''){
\tvar classes = \$('ul#myTab  a#profile-tab').attr('class');
\tvar clsArr = classes.split(' ');
\tvar actCls = \$.trim(clsArr[1]);
\tvar\tpublished = 0;
\t
\t
\tif(actCls=='active'){
\t   published = 1;
\t   sessionStorage.setItem(\"published\", \"1\"); 
\t}else{
\t   sessionStorage.setItem(\"published\", \"0\");
\t}
\tif(obj != ''){
\t//\$('button.level').text(obj);
\t}else{
\t  obj = \$.trim(\$('button.level').text());\t
\t}
\tvar flevel = '';
\tif(obj != 'Level'){
\t\t flevel =  obj;
\t}
\tvar searchText = '';
\tif(\$.trim(\$('#filterTextBox').val()) != ''){
\t\t searchText = \$.trim(\$('#filterTextBox').val());
\t}
\tlet filter_data = [];
\tvar cnt = 0;
\t\$('#fSelSection').find('li').each(function(){
\t\tif(\$(this).text() != 'Selected'){
\t\t\tif(\$.trim(\$(this).text()) != 'Clear all filters'){
\t\t\t\tfilter_data[cnt]= \$(this).text();
\t\t\t\tcnt++;
\t\t\t}
\t\t}
\t});
\tif(filter_data == ''){
\t\t\$('#fSelSection li').remove();
\t}
   \$('.task-list-data').html('<div class=\"spinner-border\" role=\"status\" style=\"margin:50px 0px 0px 50%\"><span class=\"visually-hidden\">Loading...</span></div>');
   \$.ajax({
               url: 'task-list-data',
                type: 'POST',
                data: {'fil_data':filter_data, 'is_published' : published, 'searchText': searchText, 'sort': sort},                
                success: function success(response) {
                    //console.log('non',response); return;
                    \$('.task-list-data').html('');
                    \$('.task-list-data').append(response);
                    
                },
                error: function error(err) {
                    if (err.status == 401) {
                        location.reload();
                    }
                }
            });
}


 function sortThis(obj, str=''){
 \t var classArr = obj.className;
\t var classes = classArr.split(' ');
\t if(classes.length==1){
\t \t\$(obj).addClass('filtershow');
\t\t loadFilter('', str);

\t }else{
\t \t\$(obj).removeClass('filtershow');
\t\tloadFilter('', str+'-no')
\t }
 }
 
 

function checkAll(obj='', child=''){
\tif(obj != '' && child == ''){
\t\tif(obj.checked){
\t\t   \$('#fbody .form-check-input').prop('checked', true);
\t\t   
\t\t}else{
\t\t\t\$('#fbody .form-check-input').prop('checked', false);
\t\t\t
\t\t}
\t}
\tif(child == 'yes'){
\t\tif(!obj.checked){
\t\t   \$('#selAllChkBx').prop('checked', false);
\t\t   
\t\t}
\t}
\tvar sel_count = 0;
\t\$('.pathwaytable .form-check-input').each(function(){
\t\tif(\$(this).prop('checked')){
\t\t\t sel_count++;
\t\t}
\t});
\tif(sel_count==0){
\t\t\$('#download_btn').removeClass('secondarybtn');
\t\t\$('#download_btn').addClass('secondarybtn-fade');
\t\t \$('#download_btn').attr('data-download', 'no');
\t}else{
\t\t \$('#download_btn').removeClass('secondarybtn-fade');
\t\t \$('#download_btn').addClass('secondarybtn');
\t\t \$('#download_btn').attr('data-download', 'yes');
\t
\t}

}
 </script>
 <footer>
        <div class=\"footersection\">
        <p>&copy;2023 PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of Its subsidiaries or affiliates.</p>

        <ul>
            <li><a href=\"#\"> Help Center </a></li>
            <li><a href=\"#\"> Privacy Policy</a></li>
            <li><a href=\"#\"> Cookie Notice</a></li>
            <li><a href=\"#\"> Terms & Conditions</a></li>            
        </ul>
    </div>
    </footer>

<script src=\"";
        // line 904
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "js/pagejs/task_list.js\"></script>

";
    }

    public function getTemplateName()
    {
        return "Org_1/Home/task_list.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1281 => 904,  854 => 480,  827 => 456,  794 => 426,  773 => 407,  769 => 406,  756 => 396,  752 => 395,  721 => 366,  715 => 362,  711 => 360,  690 => 351,  680 => 349,  678 => 348,  669 => 347,  667 => 346,  662 => 344,  656 => 343,  650 => 342,  646 => 341,  639 => 337,  630 => 331,  627 => 330,  621 => 329,  619 => 328,  614 => 327,  612 => 326,  607 => 323,  601 => 322,  595 => 320,  593 => 319,  589 => 318,  585 => 317,  581 => 316,  576 => 314,  563 => 306,  559 => 305,  552 => 301,  546 => 300,  539 => 298,  534 => 296,  529 => 294,  522 => 292,  515 => 290,  479 => 257,  475 => 256,  468 => 252,  459 => 246,  450 => 240,  441 => 234,  431 => 226,  426 => 224,  422 => 223,  419 => 222,  403 => 218,  395 => 215,  389 => 212,  384 => 209,  382 => 208,  376 => 205,  367 => 198,  362 => 196,  358 => 195,  355 => 194,  341 => 190,  337 => 189,  332 => 186,  328 => 185,  324 => 184,  317 => 180,  264 => 130,  255 => 123,  250 => 121,  246 => 119,  240 => 118,  238 => 117,  227 => 115,  223 => 113,  219 => 112,  213 => 109,  209 => 107,  206 => 106,  192 => 95,  188 => 93,  172 => 89,  168 => 87,  164 => 86,  158 => 83,  149 => 77,  139 => 70,  127 => 61,  111 => 47,  108 => 46,  103 => 44,  85 => 29,  77 => 24,  63 => 13,  51 => 3,  47 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'Org_1/Layout/app_home.twig' %}
{% block content %}

  <section class=\"\">
        <div class=\"pathwaytable-section\">

            <div >

                <div class=\"d-flex justify-content-between custom-ul pathwayheader\">

                    <ul class=\"mb-0\">
                        <li>
                            <h1 class=\"serifb-text\">{{\"pathways\" | trans}}</h1>
                        </li>
                    </ul>

                </div>


                <ul class=\"nav nav-tabs customtab\" id=\"myTab\" role=\"tablist\">
                    <li class=\"nav-item\" role=\"presentation\">
                        <a class=\"nav-link active\" id=\"home-tab\" data-bs-toggle=\"tab\"
                            href=\"#home-tab-pane\" type=\"button\" role=\"tab\" aria-controls=\"home-tab-pane\"
                            aria-selected=\"true\" onclick=\"loadFilter()\">{{\"drafts\" | trans}}</a>
                    </li>
                    <li class=\"nav-item\" role=\"presentation\">
                        <a class=\"nav-link\" id=\"profile-tab\" data-bs-toggle=\"tab\"
                            href=\"#home-tab-pane\" type=\"button\" role=\"tab\" aria-controls=\"home-tab-pane\"
                            aria-selected=\"false\" onclick=\"loadFilter()\">{{\"published\" | trans}}</a>
                    </li>
                </ul>
                <div class=\"tab-content\" id=\"myTabContent\">
                    <div class=\"tab-pane fade show active\" id=\"home-tab-pane\" role=\"tabpanel\" aria-labelledby=\"home-tab\"
                        tabindex=\"0\">


                        <div class=\"d-flex justify-content-between custom-ul pathwaysubhead\">

                            <ul class=\"mb-0\">
                                <li>
                                </li>
                            </ul>
                            <ul class=\"mb-0\">
                                <li><span  id=\"download_btn\" class=\"secondarybtn-fade mgr-20\" data-download=\"no\" onclick=\"downloadPathwayExl(this)\">{{\"download\" | trans}}</span></li>
                                <li>
                                    <a href=\"{{path_for('newFormRender',{lang: lang, formName:\"pwc-create-pathway
\"})}}
\" class=\"primarybtn\"> Add Pathway </a>
                                </li>
                                
                            </ul>
                        </div>


                        <div class=\"custom-ul filtersection\">

                            <ul class=\"mb-0 searchsection\">
                                <li class=\"pathwaysearch-row position-relative\">
                                    <input type=\"text\" class=\"form-control\" id=\"filterTextBox\"
                                        aria-describedby=\"search\" placeholder=\"Search pathway\" onkeyup=\"loadSearchFilter()\">
                                    <img class=\"pathwaysearchinput-icon\" src=\"{{constant('HTTP_SERVER')}}images/search-icon.svg\" alt=\"\" id=\"searchBoxImgIcon\" style=\"cursor:pointer;\">
                                </li>
                                <li>

                                </li>
                            </ul>
                            <ul class=\"mb-0 dropdown-row mt-32\">

                                <li>
                                <label class=\"filter-bar\">{{\"filter\" | trans}}</label>
                                </li>

                                <li>
                                    <div class=\"dropdown\">
                                        <button class=\"btn btn-secondary dropdown-toggle\" type=\"button\"
                                            aria-expanded=\"false\" id=\"durationBtn\">
                                            {{\"duration\" | trans}}
                                        </button>
                                     <ul class=\"dropdown-menu\" id=\"duration\">
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"form-check-label\" for=\"check_duration_selectall\" id=\"level_duration_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_duration_selectall\" onclick=\"selectAll('duration', this)\"> {{\"selectAll\" | trans}}</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t{% for key, d_value in duration %}
                                            <li class=\"dropdown-item bdr-row\"><div class=\"form-check\">
                                                    
                                                    <label class=\"form-check-label\" for=\"check_child_{{key}}\" id=\"level_child_{{key}}\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_child_{{key}}\" onclick=\"selectAll('', this, 'check_duration_selectall')\"> {{d_value}}</label>
                                                </div>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\"></li>
\t\t\t\t\t\t\t\t\t\t<li><button type=\"button\" class=\"cancelbtn d-inline\" id=\"cancelbtn\">Cancel</button>
                                        <button type=\"submit\" class=\"publishbtn d-inline\" id=\"submit\" onclick=\"addSelection()\">{{\"apply\" | trans}}</button></li>
                                        </ul>
                                    </div>
                                </li> 
                                <li>
                                    <div class=\"dropdown\">
                                        <button class=\"btn btn-secondary dropdown-toggle level\" type=\"button\"
                                             aria-expanded=\"false\" id=\"levelBtn\">
                                            Level
                                        </button>\t\t\t\t\t\t\t\t\t\t
                                        <ul class=\"dropdown-menu\" id=\"level_sel_id\">\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t{% if level|length > 0 %}{% set nos=1 %}
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"form-check-label\" for=\"check_avl_selectall\" id=\"level_avl_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_avl_selectall\" onclick=\"selectAll('level_sel_id', this)\"> {{\"selectAll\" | trans}}</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t             \t{% for data in level %}
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\">
                                                <div class=\"form-check\">                                                    
                                                    <label class=\"form-check-label\" for=\"check_child_{{nos}}\" id=\"level_child_{{nos}}\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_child_{{nos}}\"> {{data.value_of_data}}</label>
                                                </div>
                                            </li> {% set nos=nos+1 %}
\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\"></li>
\t\t\t\t\t\t\t\t\t\t<li><button type=\"button\" class=\"cancelbtn d-inline\" id=\"cancelbtn\" onclick=\"\$('#level_sel_id').removeClass('show')\">Cancel</button>
                                        <button type=\"submit\" class=\"publishbtn d-inline\" id=\"submit\" onclick=\"addSelection()\">{{\"apply\" | trans}}</button></li>
\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t
                                        </ul>\t\t\t\t\t\t\t\t\t\t
                                    </div>
                                </li>
\t\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\t\tfunction searchInList(obj){
\t\t\t\t\t\t\t\t\t\t if(obj.value.length >= 2){
\t\t\t\t\t\t\t\t\t\t\t var avl_length = '{{availability|length}}';
\t\t\t\t\t\t\t\t\t\t \t \$('#avail_menu').find('li').each(function(){
\t\t\t\t\t\t\t\t\t\t\t\t 
\t\t\t\t\t\t\t\t\t\t\t\tif(\$(this).index() > 1){ \t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t\$(this).hide();
\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t\t\t });
\t\t\t\t\t\t\t\t\t\t\t var txt = \$.trim(obj.value).toLowerCase();
\t\t\t\t\t\t\t\t\t\t\t //var s = \"India\";
\t\t\t\t\t\t\t\t\t\t\t\$('#avail_menu').find('li').each(function(){
\t\t\t\t\t\t\t\t\t\t\t\tvar str= \$.trim(\$(this).text());
\t\t\t\t\t\t\t\t\t\t\t\tif (str.toLowerCase().indexOf(txt) >= 0){
\t\t\t\t\t\t\t\t\t\t\t\t\t \$(this).show();
\t\t\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t\t\t});
\t\t\t\t\t\t\t\t\t\t\t//alert(txt);
\t\t\t\t\t\t\t\t\t\t\t \$('#avail_menu #avl_applybtn').show();

\t\t\t\t\t\t\t\t\t\t\t 

\t\t\t\t\t\t\t\t\t\t }else{
\t\t\t\t\t\t\t\t\t\t \t\$('#avail_menu').find('li').each(function(){
\t\t\t\t\t\t\t\t\t\t\t\t 
\t\t\t\t\t\t\t\t\t\t\t\tif(\$(this).index() > 1){ \t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t\$(this).show();
\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t\t\t });
\t\t\t\t\t\t\t\t\t\t }
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t</script>
                                <li>
                                    <div class=\"dropdown\">
                                        <button class=\"btn btn-secondary dropdown-toggle\" type=\"button\"
                                             aria-expanded=\"false\" id=\"avlBtn\">
                                            Availability
                                        </button>
                                        <ul class=\"dropdown-menu\" id=\"avail_menu\">

                                        <li class=\"dropdown-item pos-r\">
                                        <input type=\"text\" class=\"form-control-search\" placeholder=\"Search\" onkeyup=\"searchInList(this)\">

                                        <i class=\"filter-searchicon\"></i>
                                        </li>

\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">                                                    
                                                    <label class=\"form-check-label\" for=\"avl_selectall\" id=\"level_avl_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"avl_selectall\" onclick=\"selectAll('avail_menu', this)\">{{\"selectAll\" | trans}}</label>
                                                </div>
\t\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t\t{% if availability|length > 0 %}\t\t\t\t\t\t\t
\t\t\t\t\t\t             \t{% for data in availability %}
                                             
\t\t\t\t\t\t\t\t\t\t\t <li class=\"dropdown-item bdr-row\">
                                                <div class=\"form-check\">
                                                    <input type=\"checkbox\" class=\"form-check-input\" id=\"avl_{{data.value_of_data}}\" onclick=\"selectAll('', this, 'avl_selectall')\">
                                                    <label class=\"form-check-label\" for=\"avl_{{data.value_of_data}}\" id=\"level_avl_{{data.value_of_data}}\">{{data.value_of_data}}</label>
                                                </div>
                                            </li>
                                        {% endfor %}
\t\t\t\t\t\t\t\t\t\t<li class=\"filter-btnrow\" id=\"avl_applybtn\">
                                        <button type=\"button\" class=\"cancelbtn d-inline\"  style=\"cursor:pointer\" onclick=\"\">{{\"cancel\" | trans}}</button>
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"publishbtn d-inline\"  onclick=\"addSelection()\">{{\"apply\" | trans}}</button></li>
\t\t\t\t\t\t\t\t\t\t{% endif %}
                                        </ul>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"dropdown\" id=\"pathway_type_menu\">
                                        <button class=\"btn btn-secondary dropdown-toggle\" type=\"button\"
                                             aria-expanded=\"false\" id=\"ptypeBtn\">
                                            {{\"pathwayType\" | trans}}
                                        </button>
                                        <ul class=\"dropdown-menu\" id=\"pathway_menu\">
\t\t\t\t\t\t\t\t\t\t{% if pathway_type|length > 0 %}
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"form-check-label\" for=\"check_pathway_selectall\" id=\"level_pathway_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_pathway_selectall\" onclick=\"selectAll('pathway_menu', this)\"> {{\"selectAll\" | trans}}</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t             \t{% for data in pathway_type %}                                            
\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\">
                                                <div class=\"form-check\">                                                    
                                                    <label class=\"form-check-label\" for=\"ptype_{{data.value_of_data}}\" id=\"level_ptype_{{data.value_of_data|replace({' ': '-'})}}\"><input type=\"checkbox\" class=\"form-check-input\" id=\"ptype_{{data.value_of_data|replace({' ':'-'})}}\" onclick=\"selectAll('', this, 'check_pathway_selectall')\">{{data.value_of_data}}</label>
                                                </div>
                                            </li>
\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\"></li>
\t\t\t\t\t\t\t\t\t\t<li><button type=\"button\" class=\"cancelbtn d-inline\"  style=\"cursor:pointer\" onclick=\"\">{{\"cancel\" | trans}}</button>
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"publishbtn d-inline\"  onclick=\"addSelection()\">{{\"apply\" | trans}}</button></li>
\t\t\t\t\t\t\t\t\t\t{% endif %}
                                        </ul>
                                    </div>
                                </li>

                                <li>
                                    <div class=\"dropdown\">
                                        <button class=\"btn btn-secondary dropdown-toggle\" type=\"button\"
                                            aria-expanded=\"false\" id=\"statusBtn\">
                                            {{\"status\" | trans}}
                                        </button>
                                        <ul class=\"dropdown-menu\" id=\"status_menu\">
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-check\">
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"form-check-label\" for=\"check_status_selectall\" id=\"level_status_selectall\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_status_selectall\" onclick=\"selectAll('status_menu', this)\"> {{\"selectAll\" | trans}}</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\" >
                                                <div class=\"form-check\">
                                                    
                                                    <label class=\"form-check-label\" for=\"check_active\" id=\"level_active\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_active\" onclick=\"selectAll('', this, 'check_status_selectall')\"> {{\"active\" | trans}}</label>
                                                </div>
                                            </li>
\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\">
                                                <div class=\"form-check\">
                                                    
                                                    <label class=\"form-check-label\" for=\"check_inactive\" id=\"level_inactive\"><input type=\"checkbox\" class=\"form-check-input\" id=\"check_inactive\" onclick=\"selectAll('', this, 'check_status_selectall')\"> {{\"inactive\" | trans}}</label>
                                                </div>
                                            </li>
\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-item bdr-row\"></li>
                                            <li><button type=\"button\" class=\"cancelbtn d-inline\"  style=\"cursor:pointer\">{{\"cancel\" | trans}}</button>
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"publishbtn d-inline\"  onclick=\"addSelection()\">{{\"apply\" | trans}}</button></li>                                                                                         
                                        </ul>
                                    </div>
                                </li>
                            </ul>
\t\t\t\t\t\t\t<ul class=\"mb-0 mt-32\" id=\"fSelSection\" style=\"display:none\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<label class=\"filter-bar\">Selected</label>
                                </li> 
                            </ul>
\t\t\t\t\t\t
                        </div>

\t\t\t\t\t\t<!-- ############### -->
\t\t\t\t\t\t<div class=\"task-list-data\">
\t\t\t\t\t\t   <div class=\"spinner-border\" role=\"status\" style=\"margin:50px 0px 0px 50%\">
\t\t\t\t\t\t\t  <span class=\"visually-hidden\">Loading...</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- ################ -->

                    </div>
                    <div class=\"tab-pane fade\" id=\"profile-tab-pane\" role=\"tabpanel\" aria-labelledby=\"profile-tab\"
                        tabindex=\"0\">


<div class=\"pathwaytable\">
                        <table class=\"table pathwaytable\">
                            <thead>
                                <tr>
                                    <th scope=\"col\">
                                        <input class=\"form-check-input\" type=\"checkbox\" value=\"\" id=\"flexCheckDefault\">
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"{{constant('HTTP_SERVER')}}images/sorting-icon.svg\" alt=\"\"> {{\"title\" | trans}}
                                    </th>
                                    <th scope=\"col\"> <img class=\"sorting-btn\" src=\"{{constant('HTTP_SERVER')}}images/sorting-icon.svg\" alt=\"\"> {{\"duration\" | trans}}
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"{{constant('HTTP_SERVER')}}images/sorting-icon.svg\" alt=\"\"> Level
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"{{constant('HTTP_SERVER')}}images/sorting-icon.svg\" alt=\"\"> Availability
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"{{constant('HTTP_SERVER')}}images/sorting-icon.svg\" alt=\"\"> {{\"pathwayType\" | trans}}
                                    </th>
                                    <th scope=\"col\"><img class=\"sorting-btn\" src=\"{{constant('HTTP_SERVER')}}images/sorting-icon.svg\" alt=\"\"> {{\"status\" | trans}}</th>
                                    <th scope=\"col\">{{\"actions\" | trans}}</th>
                                </tr>
                            </thead>                            
                            <tbody id=\"fbody1\">     
                            {% if pathwayListPub|length > 0 %}                         
                            {% for data in pathwayListPub %}   

                                <tr>
                                    <th scope=\"row\" class=\"move-btnrow\">
                                        <input class=\"form-check-input\" type=\"checkbox\" value=\"\" id=\"flexCheckDefault\">
                                        <!-- <a href=\"#\" class=\"\"> <img src=\"images/moveup-icon.svg\" alt=\"\"></a>
                                        <a href=\"#\" class=\"\"><img src=\"images/movedown-icon.svg\" alt=\"\"></a> -->
                                    </th>
                                    <td>{{data.title}}</td>
                                    
                                    <td>{{data.duration |capitalize}}</td>
                                    <td>{{data.proficency_level |capitalize}}</td>
                                    <td>{{data.availability}}</td>
                                    {% if(data.pathway_type == 'completionRule') %}
                                    <td>{{\"completionRules\" | trans}}</td>
                                    {% else %}
                                    <td>{{data.pathway_type |capitalize }}</td>
                                    {%endif%} 


                                    {% if(data.is_active == '1') %}
                                    <td>{{\"active\" | trans}}</td>
                                    {% elseif(data.is_active == '2') %}
                                    <td>{{\"inactive\" | trans}}</td>
                                    {%endif%} 
                                    <!--<td><a href=\"{{path_for('pathwayDetails',{id: data.id, lang: lang})}}\" class=\"table-circlebtn \"> <img src=\"images/more-icon.svg\" alt=\"\">
                                        </a></td> -->
                                     <td>
                                        <div class=\"dropdown elipses-btn\">
                                            <a class=\"table-circlebtn dropdown-toggle\" href=\"#\" role=\"button\"
                                                data-bs-toggle=\"dropdown\" aria-expanded=\"false\">
                                                <img src=\"{{constant('HTTP_SERVER')}}images/more-icon.svg\" alt=\"\">
                                            </a>

                                            <ul class=\"dropdown-menu\">
                                                <li><a class=\"dropdown-item\" href=\"#\">{{\"previewPathway\" | trans}} </a></li>
                                                <li><a class=\"dropdown-item\" href=\"{{path_for('editDraft',{id: data.mongo_id,form_type: \"pwc-create-pathway\", lang: lang})}}\">{{\"editDetails\" | trans}} </a></li>
                                                <li><a class=\"dropdown-item\" href=\"{{path_for('pathwayDetails',{id: data.id, lang: lang})}}\">{{\"editPathway\" | trans}} </a></li>
                                                <li><a class=\"dropdown-item\" href=\"#\">{{\"managePeople\" | trans}} </a></li>

                                                {% if(data.is_active == '1') %}
                                                <li class=\"inactive\" id=\"{{data.id}}\" data-active=\"inactive\"><a class=\"dropdown-item\" href=\"javascript:void(0)\" onclick=\"changeStatus('{{data.id}}', 'inactive')\">{{\"makePathwayInactive\" | trans}}</a></li>
                                                {% elseif(data.is_active == '2') %}
                                                <li class=\"inactive\" id=\"{{data.id}}\" data-active=\"active\"><a class=\"dropdown-item\" href=\"javascript:void(0)\" onclick=\"changeStatus('{{data.id}}', 'active')\">{{\"makePathwayActive\" | trans}}</a></li>
                                                {%endif%}
                                                <li class=\"copyPathway\" id=\"{{data.id}}\" ><a class=\"dropdown-item\" href=\"javascript:void(0)\" onclick=\"copyPathway('{{data.id}}', 'active')\">{{\"makeACopy\" | trans}}</a></li>  



                                            </ul>
                                        </div>
                                    </td>
                                </tr> 
                                
                            {% endfor %}                        
                                {% else %}
                                  <tr>
                                      <td> <p>No record found.</p></td>
                                  </tr>
                                {% endif %}
                            </tbody>
                            
                        </table>

                    </div>
                    </div>
                </div>





            </div>
        </div>
    </section>   


 <div id=\"myModal\" class=\"modal\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
          <div class=\"modal-header\">
            <!-- <h1 class=\"modal-title fs-5\" id=\"exampleModalLabel\">Delete Learning Object?</h1> -->
            <button type=\"button\" id=\"closelBtnLO\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
          </div>
          <div class=\"modal-body\">
             <p>Are you sure you want to <span id=\"statusText\"></span> this item?</p>
        </div>

        <div class=\"modal-footer\">
            <button id=\"cancelBtn\" class=\"cancelbtn\">{{\"cancel\" | trans}}</button>
            <button id=\"confirmBtn\" class=\"deletebtn\">{{\"yes\" | trans}}</button>
            
          </div>
      </div>
    </div> 

</div>
    
{% endblock %}

{% block scriptBlock %}
 <script>
 function changeStatus(id, active){
\t//var id = \$(li).attr('id');

    //var active = \$(li).attr('data-active');
\tif(active=='active'){
\t\t\$('#statusText').text('activate');
\t}else{
\t\t\$('#statusText').text('inactivate');
\t}
    \$(\"#myModal\").show();
      
    \$(\"#cancelBtn\").click(function(){
        \$(\"#myModal\").hide();
        return false;
    });

      \$(\"#confirmBtn\").click(function(){
         \$.ajax({
                url: '{{path_for(\"inactivatePathway\")}}',
                type: 'POST',
                data: {'id': id,'active': active},
                success: function success(response) {
                  if (response.success) {
                    location.reload();
                    } else {
                       
                    }
                }               
              });
        \$(\"#myModal\").hide();
      });
 
 }
document.querySelectorAll(\".inactive\").forEach(function(li) {
    li.addEventListener(\"click\", function() {
    var id = \$(li).attr('id');

    var active = \$(li).attr('data-active');

    \$(\"#myModal\").show();
      
    \$(\"#cancelBtn\").click(function(){
        \$(\"#myModal\").hide();
        return false;
    });

      \$(\"#confirmBtn\").click(function(){
         \$.ajax({
                url: '{{path_for(\"inactivatePathway\")}}',
                type: 'POST',
                data: {'id': id,'active': active},
                success: function success(response) {
                  if (response.success) {
                    location.reload();
                    } else {
                       
                    }
                }               
              });
        \$(\"#myModal\").hide();
      });
  
      
  
    });
});


 function copyPathway(id, active){
    
     // \$(\"#confirmBtn\").click(function(){
         \$.ajax({
                url: '{{path_for(\"copyPathway\")}}',
                type: 'POST',
                data: {'id': id},
                success: function success(response) {
                  if (response.success) {
                    location.reload();
                    } else {
                       
                    }
                }               
              });
        //\$(\"#myModal\").hide();
     // });
 
 }

  


\$(function() {
  
  \$('a[data-bs-toggle=\"tab\"]').on('shown.bs.tab', function (e) {
    localStorage.setItem('lastTab', \$(this).attr('href'));
  });
  var lastTab = localStorage.getItem('lastTab');
  
  if (lastTab) {
    \$('[href=\"' + lastTab + '\"]').tab('show');
  }
  
});


function loadPagingData(page_no, move=''){
\t\$('.task-list-data').html('<div class=\"spinner-border\" role=\"status\" style=\"margin:50px 0px 0px 50%\"><span class=\"visually-hidden\">Loading...</span></div>');
\t\$.ajax({
\t   url: 'task-list-data?page='+page_no+((move=='yes')?'&move=y':''),
\t\ttype: 'POST',
\t\tdata: {'level':'', 'is_published' : 0},                
\t\tsuccess: function success(response) {
\t\t\t//console.log('non',response); return;
\t\t\t\$('.task-list-data').html('');
\t\t\t\$('.task-list-data').append(response);
\t\t\t
\t\t},
\t\terror: function error(err) {
\t\t\tif (err.status == 401) {
\t\t\t\tlocation.reload();
\t\t\t}
\t\t}
\t});

}

\$(document).ready(function () {
\t\$('ul#myTab  a#home-tab').addClass('active');
\t\$('ul#myTab  a#profile-tab').removeClass('active');

\tlet pub = sessionStorage.getItem(\"published\");
\tif(pub == null){
\t\tsessionStorage.setItem(\"published\", \"0\");
\t\tpub=0;
\t}else if(pub == 1){
\t\t\$('ul#myTab  a#home-tab').removeClass('active');
\t\t\$('ul#myTab  a#profile-tab').addClass('active');
\t}
\t//\$(\".lds-spinner\").show();
\t
\t\$.ajax({
               url: 'task-list-data',
                type: 'POST',
                data: {'level':'', 'is_published' : pub},                
                success: function success(response) {
                    //console.log('non',response); return;
                    \$('.task-list-data').html('');
                    \$('.task-list-data').append(response);
                    
                },
                error: function error(err) {
                    if (err.status == 401) {
                        location.reload();
                    }
                }
            });
});
function getCookie(cname) {
  let name = cname + \"=\";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i <ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return \"\";
}
\$('#filterTextBox').keydown(function (event) {
    let keyPressed = event.keyCode || event.which;
    if (keyPressed === 13) {
       \t   loadSearchFilter();
    }
});

\$('#searchBoxImgIcon').click(loadSearchFilter);
function loadSearchFilter(){
\t loadFilter();

}
function selectAll(id='', obj='', selAll=''){
\tif(id != ''){
\t\t\$('#'+id+' li input[type=checkbox]').each(function(){
\t\t\t   if(obj.checked){
\t\t\t\t\t\$(this).prop('checked', true);
\t\t\t   }else{
\t\t\t\t \$(this).prop('checked', false);
\t\t\t   }
\t   
\t   });
\t}
\tif(!obj.checked && selAll != ''){
\t\t\$('#'+selAll).prop('checked', false);
\t}
\tevent.stopPropagation();
}
function addSelection(){
\t\$('.filtersection ul').removeClass('show');
\t\$('.filtersection button').removeClass('show');
\t\$('#fSelSection li').remove();
\t\$('#fSelSection').append('<li><label class=\"filter-bar\">Selected</label></li>');
\t\$('#fSelSection').show();
\t\$('#duration li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_child_'+idsArr[2]).text();
\t\tleveText = \$.trim(leveText);
\t\tif(leveText == ''){
\t\t\tleveText = \$('#level_'+idsArr[1]+'_'+idsArr[2]).text();
\t\t}
\t\t//alert(leveText);
\t\tif(\$.trim(leveText) == 'Select all'){
\t\t\tleveText = 'All Duration';
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"duration_li_'+idsArr[2]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'duration\\', \\''+idsArr[2]+'\\');loadFilter()\"></button></li>');
\t\t\treturn false;
\t\t}else{
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"duration_li_'+idsArr[2]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'duration\\', \\''+idsArr[2]+'\\');loadFilter()\"></button></li>');
\t\t}
\t});
\t\$('#level_sel_id li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_child_'+idsArr[2]).text();
\t\tif(leveText == ''){
\t\t\tleveText = \$('#level_'+idsArr[1]+'_'+idsArr[2]).text();
\t\t}
\t\tleveText = \$.trim(leveText);
\t\tif(leveText == 'Select all'){
\t\t\tleveText = 'All Level';
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"level_li_'+idsArr[2]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'level\\', \\''+idsArr[2]+'\\');loadFilter()\"></button></li>');
\t\t\treturn false;
\t\t}else{
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"level_li_'+idsArr[2]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'level\\', '+idsArr[2]+');loadFilter()\"></button></li>');
\t\t}
\t});
\t
\t\$('#avail_menu li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_avl_'+idsArr[1]).text();
\t\tleveText = \$.trim(leveText);
\t\tif(leveText=='Select all'){
\t\t\tleveText = 'All Countries';
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"avail_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'avail\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t\treturn false;
\t\t}else{
\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"avail_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'avail\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t}
\t});
\t\$('#pathway_type_menu li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_ptype_'+idsArr[1]).text();
\t\tleveText = \$.trim(leveText);
\t\tif(leveText == ''){
\t\t\tleveText = \$('#level_'+idsArr[1]+'_'+idsArr[2]).text();
\t\t}
\t\tif(\$.trim(leveText) == 'Select all'){
\t\t\tleveText = 'All Pathway Type';
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"ptype_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'ptype\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t\treturn false;
\t\t}else{

\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"ptype_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'ptype\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t}
\t});
\t\$('#status_menu li input[type=checkbox]:checked').each(function(){
\t\tvar ids = \$(this).attr('id');
\t\tidsArr = ids.split('_');
\t\tvar leveText = \$('#level_'+idsArr[1]).text();
\t\tleveText = \$.trim(leveText);
\t\tif(leveText == ''){
\t\t\tleveText = \$('#level_'+idsArr[1]+'_'+idsArr[2]).text();
\t\t}
\t\tif(\$.trim(leveText) == 'Select all'){
\t\t\tleveText = 'All Status';
\t\t   \$('#fSelSection').append('<li class=\"filterbar\" id=\"status_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'status\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t   return false;
\t\t}else{
\t\t\t\$('#fSelSection').append('<li class=\"filterbar\" id=\"status_li_'+idsArr[1]+'\"><span>'+leveText+'</span><button type=\"button\" class=\"closebtn\" data-bs-dismiss=\"alert\" onclick=\"removeElem(\\'status\\', \\''+idsArr[1]+'\\');loadFilter()\"></button></li>');
\t\t}
\t});
\t\$('#fSelSection').append('<li><label class=\"clearfilters\" onclick=\"clearAllFil();loadFilter()\" style=\"cursor:pointer\">&nbsp;Clear all filters</label></li>');
\tloadFilter();
\t //if(\$('#check_child_'+id).is(':checked')){
\t \t// var leveText = \$('#level_child_'+id).text();
\t\t //\$('#fSelSection').append('<div class=\"alert alert-primary alert-dismissible fade show\" style=\"width:120px;\"><strong>'+leveText+'</strong><button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\"></button></div>');
\t //}

}
function removeElem(wFil, id){
\tif(wFil == 'duration'){
\t  \$('#duration_li_'+id).remove();
\t  
\t  \$('#check_child_'+id).prop('checked', false);
\t  if(id == 'selectall'){
\t  \t \$('#duration li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
\tif(wFil == 'level'){
\t  \$('#level_li_'+id).remove();
\t  
\t  \$('#check_child_'+id).prop('checked', false);
\t  if(id == 'selectall'){
\t  \t \$('#level_sel_id li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
\tif(wFil == 'status'){
\t  \$('#status_li_'+id).remove();\t  
\t  \$('#check_'+id).prop('checked', false);
\t  if(id == 'status'){
\t  \t \$('#status_menu li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
\tif(wFil == 'avail'){
\t  \$('#avail_li_'+id).remove();\t  
\t  \$('#avl_'+id).prop('checked', false);
\t  if(id == 'selectall'){
\t  \t \$('#avail_menu li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
\tif(wFil == 'ptype'){
\t  \$('#ptype_li_'+id).remove();\t  
\t  \$('#ptype_'+id).prop('checked', false);
\t   if(id == 'pathway'){
\t  \t \$('#pathway_menu li input[type=checkbox]').each(function (){
\t\t\t\$(this).prop('checked', false);
\t\t 
\t\t });
\t  }
\t}
}
function clearAllFil(){
\t\$('#filterTextBox').val('');
\t\$('#fSelSection li').remove();
\t\$('#duration li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#level_sel_id li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#status_menu li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#avail_menu li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#pathway_type_menu li input[type=checkbox]').each(function(){
\t\t\t\t  \$(this).prop('checked', false);
\t
\t});
\t\$('#fSelSection').append('<li><label class=\"filter-bar\">Selected</label></li>');
\t\$('#fSelSection').hide();
}
function loadFilter(obj='', sort=''){
\tvar classes = \$('ul#myTab  a#profile-tab').attr('class');
\tvar clsArr = classes.split(' ');
\tvar actCls = \$.trim(clsArr[1]);
\tvar\tpublished = 0;
\t
\t
\tif(actCls=='active'){
\t   published = 1;
\t   sessionStorage.setItem(\"published\", \"1\"); 
\t}else{
\t   sessionStorage.setItem(\"published\", \"0\");
\t}
\tif(obj != ''){
\t//\$('button.level').text(obj);
\t}else{
\t  obj = \$.trim(\$('button.level').text());\t
\t}
\tvar flevel = '';
\tif(obj != 'Level'){
\t\t flevel =  obj;
\t}
\tvar searchText = '';
\tif(\$.trim(\$('#filterTextBox').val()) != ''){
\t\t searchText = \$.trim(\$('#filterTextBox').val());
\t}
\tlet filter_data = [];
\tvar cnt = 0;
\t\$('#fSelSection').find('li').each(function(){
\t\tif(\$(this).text() != 'Selected'){
\t\t\tif(\$.trim(\$(this).text()) != 'Clear all filters'){
\t\t\t\tfilter_data[cnt]= \$(this).text();
\t\t\t\tcnt++;
\t\t\t}
\t\t}
\t});
\tif(filter_data == ''){
\t\t\$('#fSelSection li').remove();
\t}
   \$('.task-list-data').html('<div class=\"spinner-border\" role=\"status\" style=\"margin:50px 0px 0px 50%\"><span class=\"visually-hidden\">Loading...</span></div>');
   \$.ajax({
               url: 'task-list-data',
                type: 'POST',
                data: {'fil_data':filter_data, 'is_published' : published, 'searchText': searchText, 'sort': sort},                
                success: function success(response) {
                    //console.log('non',response); return;
                    \$('.task-list-data').html('');
                    \$('.task-list-data').append(response);
                    
                },
                error: function error(err) {
                    if (err.status == 401) {
                        location.reload();
                    }
                }
            });
}


 function sortThis(obj, str=''){
 \t var classArr = obj.className;
\t var classes = classArr.split(' ');
\t if(classes.length==1){
\t \t\$(obj).addClass('filtershow');
\t\t loadFilter('', str);

\t }else{
\t \t\$(obj).removeClass('filtershow');
\t\tloadFilter('', str+'-no')
\t }
 }
 
 

function checkAll(obj='', child=''){
\tif(obj != '' && child == ''){
\t\tif(obj.checked){
\t\t   \$('#fbody .form-check-input').prop('checked', true);
\t\t   
\t\t}else{
\t\t\t\$('#fbody .form-check-input').prop('checked', false);
\t\t\t
\t\t}
\t}
\tif(child == 'yes'){
\t\tif(!obj.checked){
\t\t   \$('#selAllChkBx').prop('checked', false);
\t\t   
\t\t}
\t}
\tvar sel_count = 0;
\t\$('.pathwaytable .form-check-input').each(function(){
\t\tif(\$(this).prop('checked')){
\t\t\t sel_count++;
\t\t}
\t});
\tif(sel_count==0){
\t\t\$('#download_btn').removeClass('secondarybtn');
\t\t\$('#download_btn').addClass('secondarybtn-fade');
\t\t \$('#download_btn').attr('data-download', 'no');
\t}else{
\t\t \$('#download_btn').removeClass('secondarybtn-fade');
\t\t \$('#download_btn').addClass('secondarybtn');
\t\t \$('#download_btn').attr('data-download', 'yes');
\t
\t}

}
 </script>
 <footer>
        <div class=\"footersection\">
        <p>&copy;2023 PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of Its subsidiaries or affiliates.</p>

        <ul>
            <li><a href=\"#\"> Help Center </a></li>
            <li><a href=\"#\"> Privacy Policy</a></li>
            <li><a href=\"#\"> Cookie Notice</a></li>
            <li><a href=\"#\"> Terms & Conditions</a></li>            
        </ul>
    </div>
    </footer>

<script src=\"{{constant('HTTP_SERVER')}}js/pagejs/task_list.js\"></script>

{% endblock %}", "Org_1/Home/task_list.twig", "/home/phpapp/pwc_qc/templates/Org_1/Home/task_list.twig");
    }
}
