<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Org_1/Home/edit_form.twig */
class __TwigTemplate_1fb0bfd50f47865b2ddc292e38a588a7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "Org_1/Layout/app_home.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("Org_1/Layout/app_home.twig", "Org_1/Home/edit_form.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 3
        echo "    <div class=\"bannerrow bannerrow-sa bannerimg\"> 
        <div class=\"leftcontent\">
            <h3>";
        // line 5
        echo twig_escape_filter($this->env, ($context["title"] ?? null), "html", null, true);
        echo "</h3>
        </div>
    </div>

    <div class=\"loader-overlay form-preloader col-sm-12\" id=\"home-loader-overlay\">
        <div id=\"preloader\" >
            <div class=\"lds-spinner\"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>        
        </div>
    </div> 
\t
    <!--<div class=\"faqsection\">
\t    <h1> Edit learning object</h1>
        <div id=\"formio-id\"></div>
    </div> -->

\t<div class=\"formsection\">
\t\t";
        // line 21
        if ((($context["formKey"] ?? null) == "pwc-create-pathway")) {
            // line 22
            echo "\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Edit pathway details</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t";
        } elseif ((        // line 26
($context["formKey"] ?? null) == "pwc-section-details")) {
            // line 27
            echo "\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Edit section</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t";
        } elseif ((        // line 31
($context["formKey"] ?? null) == "pwc-sub-section-details")) {
            // line 32
            echo "\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Edit subsection</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t";
        } elseif ((        // line 36
($context["formKey"] ?? null) == "pwc-external-learning-object")) {
            // line 37
            echo "\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\"> Edit learning item (External)</h1>
\t\t\t</div>
\t\t";
        }
        // line 40
        echo "  
      <div id=\"formio-id\" class=\"request-custom-form\"/></div>
</div>


<span id=\"formData\" 
mongoId = \"";
        // line 46
        echo twig_escape_filter($this->env, ($context["mongo_id"] ?? null), "html", null, true);
        echo "\" 
getFormData = \"";
        // line 47
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("getFormData"), "html", null, true);
        echo "\" 
form_id = \"";
        // line 48
        echo twig_escape_filter($this->env, ($context["form_id"] ?? null), "html", null, true);
        echo "\" 
FORM_URL = \"";
        // line 49
        echo twig_escape_filter($this->env, ($context["FORM_URL"] ?? null), "html", null, true);
        echo "\" 
form_id = \"";
        // line 50
        echo twig_escape_filter($this->env, ($context["form_id"] ?? null), "html", null, true);
        echo "\" 
task_id = \"";
        // line 51
        echo twig_escape_filter($this->env, ($context["task_id"] ?? null), "html", null, true);
        echo "\" 
user_id = \"";
        // line 52
        echo twig_escape_filter($this->env, ($context["user_id"] ?? null), "html", null, true);
        echo "\" 
form_type = \"";
        // line 53
        echo twig_escape_filter($this->env, ($context["form_type"] ?? null), "html", null, true);
        echo "\" 
mode = \"";
        // line 54
        echo twig_escape_filter($this->env, ($context["mode"] ?? null), "html", null, true);
        echo "\" 
type = \"";
        // line 55
        echo twig_escape_filter($this->env, ($context["type"] ?? null), "html", null, true);
        echo "\" 
custom_filter_v = \"";
        // line 56
        echo twig_escape_filter($this->env, ($context["custom_filter_v"] ?? null), "html", null, true);
        echo "\" 
is_mandatory = \"";
        // line 57
        echo twig_escape_filter($this->env, ($context["is_mandatory"] ?? null), "html", null, true);
        echo "\" 
type_k = \"";
        // line 58
        echo twig_escape_filter($this->env, ($context["type_k"] ?? null), "html", null, true);
        echo "\" 
updatDraft = \"";
        // line 59
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("updatDraft", ["form_type" => ($context["form_type"] ?? null), "id" => ($context["form_id"] ?? null), "lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\" 
taskListUrl = \"";
        // line 60
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("taskList", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\" 
pathwayDetailsUrl = \"";
        // line 61
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("pathwayDetails", ["lang" => ($context["lang"] ?? null), "id" => ($context["pathwayId"] ?? null)]), "html", null, true);
        echo "\" 
getFormCustomFilterLoUrl = \"";
        // line 62
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("getFormCustomFilterLo"), "html", null, true);
        echo "\" 
HTTP_SERVER = \"";
        // line 63
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "\" 
getFormCustomFilterUrl = \"";
        // line 64
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("getFormCustomFilter"), "html", null, true);
        echo "\" 
saveFilterValueUrl = \"";
        // line 65
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("saveFilterValue"), "html", null, true);
        echo "\" 
saveCustomFilterUrl = \"";
        // line 66
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("saveCustomFilter"), "html", null, true);
        echo "\" 
getCustomFilterUrl = \"";
        // line 67
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("getCustomFilter"), "html", null, true);
        echo "\" 
deleteCustomFilterUrl = \"";
        // line 68
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("deleteCustomFilter"), "html", null, true);
        echo "\"
autoSaveText = \"";
        // line 69
        echo twig_escape_filter($this->env, ($context["autoSaveText"] ?? null), "html", null, true);
        echo "\"
></span>

<footer>
    <div class=\"footersection\">
        <p>©2023 PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of Its subsidiaries or affiliates.</p>

        <ul>
            <li><a href=\"#\"> Help Center </a></li>
            <li><a href=\"#\"> Privacy Policy</a></li>
            <li><a href=\"#\"> Cookie Notice</a></li>
            <li><a href=\"#\"> Terms & Conditions</a></li>            
        </ul>
    </div>
</footer>

    <!-- add custom filter popup -->

    <div class=\"modal fade\" id=\"customFilterModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"customFilterModalLabel\" aria-hidden=\"true\">
      <div class=\"modal-dialog\" role=\"document\">
        <div class=\"modal-content\">
          <div class=\"modal-header\">
            <h5 class=\"modal-title\" id=\"customFilterLabel\">Edit custom filter</h5>
            <button type=\"button\" class=\"close\" data-bs-dismiss=\"modal\" aria-label=\"Close\">
              <span aria-hidden=\"true\">&times;</span>
            </button>
          </div>
          <form id=\"customFormSubmit\" type=\"post\">
              <div class=\"modal-body\">
                  <div class=\"form-group\">
                    <label for=\"customFilterName\">Custom filter name</label>
                    <input type=\"text\" class=\"form-control\" name=\"customFilterName\" id=\"customFilterName\" placeholder=\"Example Priority\">
                  </div>
                  <input type=\"hidden\" name=\"customFilterId\" id=\"customFilterId\">
                  <div id=\"customFilterValueShow\">
                      
                  </div>
                  <a id=\"addAdditionalValue\">+ Add additional value</a>
              </div>
              <div class=\"modal-footer\">
                <button type=\"button\" class=\"cancelbtn\" data-bs-dismiss=\"modal\">Close</button>
                <button type=\"submit\" class=\"publishbtn\">Save changes</button>
              </div>
          </form>
        </div>
      </div>
    </div>

    <!-- add custom filter popup -->
    <script src=\"";
        // line 118
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "js/pagejs/edit_form.js?v=";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_date_converter($this->env), "timestamp", [], "any", false, false, false, 118), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "Org_1/Home/edit_form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 118,  205 => 69,  201 => 68,  197 => 67,  193 => 66,  189 => 65,  185 => 64,  181 => 63,  177 => 62,  173 => 61,  169 => 60,  165 => 59,  161 => 58,  157 => 57,  153 => 56,  149 => 55,  145 => 54,  141 => 53,  137 => 52,  133 => 51,  129 => 50,  125 => 49,  121 => 48,  117 => 47,  113 => 46,  105 => 40,  99 => 37,  97 => 36,  91 => 32,  89 => 31,  83 => 27,  81 => 26,  75 => 22,  73 => 21,  54 => 5,  50 => 3,  46 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'Org_1/Layout/app_home.twig' %}
{% block content %}
    <div class=\"bannerrow bannerrow-sa bannerimg\"> 
        <div class=\"leftcontent\">
            <h3>{{title}}</h3>
        </div>
    </div>

    <div class=\"loader-overlay form-preloader col-sm-12\" id=\"home-loader-overlay\">
        <div id=\"preloader\" >
            <div class=\"lds-spinner\"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>        
        </div>
    </div> 
\t
    <!--<div class=\"faqsection\">
\t    <h1> Edit learning object</h1>
        <div id=\"formio-id\"></div>
    </div> -->

\t<div class=\"formsection\">
\t\t{% if (formKey == 'pwc-create-pathway') %}
\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Edit pathway details</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t{% elseif (formKey == 'pwc-section-details') %}
\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Edit section</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t{% elseif (formKey == 'pwc-sub-section-details') %}
\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Edit subsection</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t{% elseif (formKey == 'pwc-external-learning-object') %}
\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\"> Edit learning item (External)</h1>
\t\t\t</div>
\t\t{%endif%}  
      <div id=\"formio-id\" class=\"request-custom-form\"/></div>
</div>


<span id=\"formData\" 
mongoId = \"{{mongo_id}}\" 
getFormData = \"{{path_for('getFormData')}}\" 
form_id = \"{{form_id}}\" 
FORM_URL = \"{{FORM_URL}}\" 
form_id = \"{{form_id}}\" 
task_id = \"{{task_id}}\" 
user_id = \"{{user_id}}\" 
form_type = \"{{form_type}}\" 
mode = \"{{mode}}\" 
type = \"{{type}}\" 
custom_filter_v = \"{{custom_filter_v}}\" 
is_mandatory = \"{{is_mandatory}}\" 
type_k = \"{{type_k}}\" 
updatDraft = \"{{path_for('updatDraft',{form_type: form_type, id:form_id, lang:lang})}}\" 
taskListUrl = \"{{path_for('taskList', {lang: lang})}}\" 
pathwayDetailsUrl = \"{{path_for('pathwayDetails', {lang:lang, id:pathwayId})}}\" 
getFormCustomFilterLoUrl = \"{{path_for('getFormCustomFilterLo')}}\" 
HTTP_SERVER = \"{{constant('HTTP_SERVER')}}\" 
getFormCustomFilterUrl = \"{{path_for('getFormCustomFilter')}}\" 
saveFilterValueUrl = \"{{path_for('saveFilterValue')}}\" 
saveCustomFilterUrl = \"{{path_for('saveCustomFilter')}}\" 
getCustomFilterUrl = \"{{path_for('getCustomFilter')}}\" 
deleteCustomFilterUrl = \"{{path_for('deleteCustomFilter')}}\"
autoSaveText = \"{{autoSaveText}}\"
></span>

<footer>
    <div class=\"footersection\">
        <p>©2023 PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of Its subsidiaries or affiliates.</p>

        <ul>
            <li><a href=\"#\"> Help Center </a></li>
            <li><a href=\"#\"> Privacy Policy</a></li>
            <li><a href=\"#\"> Cookie Notice</a></li>
            <li><a href=\"#\"> Terms & Conditions</a></li>            
        </ul>
    </div>
</footer>

    <!-- add custom filter popup -->

    <div class=\"modal fade\" id=\"customFilterModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"customFilterModalLabel\" aria-hidden=\"true\">
      <div class=\"modal-dialog\" role=\"document\">
        <div class=\"modal-content\">
          <div class=\"modal-header\">
            <h5 class=\"modal-title\" id=\"customFilterLabel\">Edit custom filter</h5>
            <button type=\"button\" class=\"close\" data-bs-dismiss=\"modal\" aria-label=\"Close\">
              <span aria-hidden=\"true\">&times;</span>
            </button>
          </div>
          <form id=\"customFormSubmit\" type=\"post\">
              <div class=\"modal-body\">
                  <div class=\"form-group\">
                    <label for=\"customFilterName\">Custom filter name</label>
                    <input type=\"text\" class=\"form-control\" name=\"customFilterName\" id=\"customFilterName\" placeholder=\"Example Priority\">
                  </div>
                  <input type=\"hidden\" name=\"customFilterId\" id=\"customFilterId\">
                  <div id=\"customFilterValueShow\">
                      
                  </div>
                  <a id=\"addAdditionalValue\">+ Add additional value</a>
              </div>
              <div class=\"modal-footer\">
                <button type=\"button\" class=\"cancelbtn\" data-bs-dismiss=\"modal\">Close</button>
                <button type=\"submit\" class=\"publishbtn\">Save changes</button>
              </div>
          </form>
        </div>
      </div>
    </div>

    <!-- add custom filter popup -->
    <script src=\"{{constant('HTTP_SERVER')}}js/pagejs/edit_form.js?v={{ date().timestamp }}\"></script>
{% endblock %}
", "Org_1/Home/edit_form.twig", "/home/phpapp/pwc_qc/templates/Org_1/Home/edit_form.twig");
    }
}
