<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Org_1/Home/form.twig */
class __TwigTemplate_b8e56b1f3a22a55e14dfb36ab9037d7d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "Org_1/Layout/app_home.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("Org_1/Layout/app_home.twig", "Org_1/Home/form.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "   
   <!-- <div class=\"connectmid-sec darkblue-bg\">
\t<nav aria-label=\"breadcrumb\" class=\"nav-bread breadcrump-click-stream\">
\t\t<ol class=\"breadcrumb breadcrumbCustom\">
\t\t\t<li class=\"breadcrumb-item \">
\t\t\t\t<a href=\"";
        // line 8
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo twig_escape_filter($this->env, ($context["lang"] ?? null), "html", null, true);
        echo "\">Home</a>
\t\t\t\t<img class=\"breadcrumbIconbtn\" alt=\"breadcrumbIcon\"/>
\t\t\t</li>

                ";
        // line 12
        if (((($context["formKey"] ?? null) != "help") && (($context["formKey"] ?? null) != "home-banner"))) {
            // line 13
            echo "
                <li class=\"breadcrumb-item\">
\t\t\t\t<a href=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("taskList", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
            echo "\">Pathway List (s)</a>
\t\t\t\t<img class=\"breadcrumbIconbtn\" alt=\"breadcrumbIcon\"/>
\t\t\t</li>
                ";
        }
        // line 18
        echo "              
                
            </ol>
\t</nav>
</div> -->

<div class=\"formsection\">
\t\t";
        // line 25
        if ((($context["formKey"] ?? null) == "pwc-create-pathway")) {
            // line 26
            echo "\t\t\t<div>
\t\t\t\t<h1 class=\"headingbar\">Create pathway</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t";
        } elseif ((        // line 30
($context["formKey"] ?? null) == "pwc-section-details")) {
            // line 31
            echo "\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Add section</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t";
        } elseif ((        // line 35
($context["formKey"] ?? null) == "pwc-sub-section-details")) {
            // line 36
            echo "\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Add subsection</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t";
        } elseif ((        // line 40
($context["formKey"] ?? null) == "pwc-external-learning-object")) {
            // line 41
            echo "\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\"> Add learning item</h1>
\t\t\t</div>
\t\t";
        }
        // line 44
        echo "  
      <div id=\"formio-id\" class=\"request-custom-form\"/></div>
</div>

<footer>
    <div class=\"footersection\">
        <p>©2023 PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of Its subsidiaries or affiliates.</p>

        <ul>
            <li><a href=\"#\"> Help Center </a></li>
            <li><a href=\"#\"> Privacy Policy</a></li>
            <li><a href=\"#\"> Cookie Notice</a></li>
            <li><a href=\"#\"> Terms & Conditions</a></li>            
        </ul>
    </div>
</footer>

<!-- add custom filter popup -->

<div class=\"modal fade\" id=\"customFilterModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"customFilterModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h5 class=\"modal-title\" id=\"customFilterLabel\">Edit custom filter</h5>
        <button type=\"button\" class=\"close\" data-bs-dismiss=\"modal\" aria-label=\"Close\">
          <span aria-hidden=\"true\">&times;</span>
        </button>
      </div>
      <form id=\"customFormSubmit\" type=\"post\">
\t      <div class=\"modal-body\">
\t\t\t  <div class=\"form-group\">
\t\t\t    <label for=\"customFilterName\">Custom filter name</label>
\t\t\t    <input type=\"text\" class=\"form-control\" name=\"customFilterName\" id=\"customFilterName\" placeholder=\"Example Priority\">
\t\t\t  </div>
\t\t\t  <input type=\"hidden\" name=\"customFilterId\" id=\"customFilterId\">
\t\t\t  <div id=\"customFilterValueShow\">
\t\t\t\t  
\t\t\t  </div>
\t\t\t  <a id=\"addAdditionalValue\">+ Add additional value</a>
\t      </div>
\t      <div class=\"modal-footer\">
\t        <button type=\"button\" class=\"cancelbtn\" data-bs-dismiss=\"modal\">Close</button>
\t        <button type=\"submit\" class=\"publishbtn\">Save changes</button>
\t      </div>
      </form>
    </div>
  </div>
</div>

<!-- add custom filter popup -->

<span 
id = \"formData\" 
pathwayId = \"";
        // line 97
        echo twig_escape_filter($this->env, ($context["pathwayId"] ?? null), "html", null, true);
        echo "\" 
sectionId = \"";
        // line 98
        echo twig_escape_filter($this->env, ($context["sectionId"] ?? null), "html", null, true);
        echo "\"
mongoId = \"\"
FORM_URL = \"";
        // line 100
        echo twig_escape_filter($this->env, ($context["FORM_URL"] ?? null), "html", null, true);
        echo "\"
form_id = \"";
        // line 101
        echo twig_escape_filter($this->env, ($context["form_id"] ?? null), "html", null, true);
        echo "\"
formKey = \"";
        // line 102
        echo twig_escape_filter($this->env, ($context["formKey"] ?? null), "html", null, true);
        echo "\"
type_id = \"";
        // line 103
        echo twig_escape_filter($this->env, ($context["type_id"] ?? null), "html", null, true);
        echo "\"
saveCustomFilterUrl = \"";
        // line 104
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("saveCustomFilter"), "html", null, true);
        echo "\"
getCustomFilterUrl = \"";
        // line 105
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("getCustomFilter"), "html", null, true);
        echo "\"
addPathwayDataUrl = \"";
        // line 106
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("addPathwayData", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\"
addSectionDetailsUrl = \"";
        // line 107
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("addSectionDetails", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\"
pathwayDetailsUrl = \"";
        // line 108
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("pathwayDetails", ["lang" => ($context["lang"] ?? null), "id" => ($context["pathwayId"] ?? null)]), "html", null, true);
        echo "\"
addExternalLearningUrl = \"";
        // line 109
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("addExternalLearning", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\"
taskListUrl = \"";
        // line 110
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("taskList", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\"
></span>

<script src=\"";
        // line 113
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "js/pagejs/form.js?v=";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_date_converter($this->env), "timestamp", [], "any", false, false, false, 113), "html", null, true);
        echo "\"></script>

";
    }

    public function getTemplateName()
    {
        return "Org_1/Home/form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  228 => 113,  222 => 110,  218 => 109,  214 => 108,  210 => 107,  206 => 106,  202 => 105,  198 => 104,  194 => 103,  190 => 102,  186 => 101,  182 => 100,  177 => 98,  173 => 97,  118 => 44,  112 => 41,  110 => 40,  104 => 36,  102 => 35,  96 => 31,  94 => 30,  88 => 26,  86 => 25,  77 => 18,  70 => 15,  66 => 13,  64 => 12,  56 => 8,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'Org_1/Layout/app_home.twig' %}

{% block content %}   
   <!-- <div class=\"connectmid-sec darkblue-bg\">
\t<nav aria-label=\"breadcrumb\" class=\"nav-bread breadcrump-click-stream\">
\t\t<ol class=\"breadcrumb breadcrumbCustom\">
\t\t\t<li class=\"breadcrumb-item \">
\t\t\t\t<a href=\"{{constant('HTTP_SERVER')}}{{lang}}\">Home</a>
\t\t\t\t<img class=\"breadcrumbIconbtn\" alt=\"breadcrumbIcon\"/>
\t\t\t</li>

                {% if (formKey != 'help' and formKey != 'home-banner') %}

                <li class=\"breadcrumb-item\">
\t\t\t\t<a href=\"{{path_for('taskList', {lang: lang})}}\">Pathway List (s)</a>
\t\t\t\t<img class=\"breadcrumbIconbtn\" alt=\"breadcrumbIcon\"/>
\t\t\t</li>
                {%endif%}              
                
            </ol>
\t</nav>
</div> -->

<div class=\"formsection\">
\t\t{% if (formKey == 'pwc-create-pathway') %}
\t\t\t<div>
\t\t\t\t<h1 class=\"headingbar\">Create pathway</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t{% elseif (formKey == 'pwc-section-details') %}
\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Add section</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t{% elseif (formKey == 'pwc-sub-section-details') %}
\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\">Add subsection</h1>
\t\t\t\t<span class=\"field-required\">Required information</span>
\t\t\t</div>
\t\t{% elseif (formKey == 'pwc-external-learning-object') %}
\t\t\t<div class=\"mb-32\">
\t\t\t\t<h1 class=\"headingbar\"> Add learning item</h1>
\t\t\t</div>
\t\t{%endif%}  
      <div id=\"formio-id\" class=\"request-custom-form\"/></div>
</div>

<footer>
    <div class=\"footersection\">
        <p>©2023 PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of Its subsidiaries or affiliates.</p>

        <ul>
            <li><a href=\"#\"> Help Center </a></li>
            <li><a href=\"#\"> Privacy Policy</a></li>
            <li><a href=\"#\"> Cookie Notice</a></li>
            <li><a href=\"#\"> Terms & Conditions</a></li>            
        </ul>
    </div>
</footer>

<!-- add custom filter popup -->

<div class=\"modal fade\" id=\"customFilterModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"customFilterModalLabel\" aria-hidden=\"true\">
  <div class=\"modal-dialog\" role=\"document\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h5 class=\"modal-title\" id=\"customFilterLabel\">Edit custom filter</h5>
        <button type=\"button\" class=\"close\" data-bs-dismiss=\"modal\" aria-label=\"Close\">
          <span aria-hidden=\"true\">&times;</span>
        </button>
      </div>
      <form id=\"customFormSubmit\" type=\"post\">
\t      <div class=\"modal-body\">
\t\t\t  <div class=\"form-group\">
\t\t\t    <label for=\"customFilterName\">Custom filter name</label>
\t\t\t    <input type=\"text\" class=\"form-control\" name=\"customFilterName\" id=\"customFilterName\" placeholder=\"Example Priority\">
\t\t\t  </div>
\t\t\t  <input type=\"hidden\" name=\"customFilterId\" id=\"customFilterId\">
\t\t\t  <div id=\"customFilterValueShow\">
\t\t\t\t  
\t\t\t  </div>
\t\t\t  <a id=\"addAdditionalValue\">+ Add additional value</a>
\t      </div>
\t      <div class=\"modal-footer\">
\t        <button type=\"button\" class=\"cancelbtn\" data-bs-dismiss=\"modal\">Close</button>
\t        <button type=\"submit\" class=\"publishbtn\">Save changes</button>
\t      </div>
      </form>
    </div>
  </div>
</div>

<!-- add custom filter popup -->

<span 
id = \"formData\" 
pathwayId = \"{{pathwayId}}\" 
sectionId = \"{{sectionId}}\"
mongoId = \"\"
FORM_URL = \"{{FORM_URL}}\"
form_id = \"{{form_id}}\"
formKey = \"{{formKey}}\"
type_id = \"{{type_id}}\"
saveCustomFilterUrl = \"{{path_for('saveCustomFilter')}}\"
getCustomFilterUrl = \"{{path_for('getCustomFilter')}}\"
addPathwayDataUrl = \"{{path_for('addPathwayData',{lang: lang})}}\"
addSectionDetailsUrl = \"{{path_for('addSectionDetails', {lang: lang})}}\"
pathwayDetailsUrl = \"{{path_for('pathwayDetails', {lang: lang, id:pathwayId})}}\"
addExternalLearningUrl = \"{{path_for('addExternalLearning', {lang: lang})}}\"
taskListUrl = \"{{path_for('taskList', {lang: lang})}}\"
></span>

<script src=\"{{constant('HTTP_SERVER')}}js/pagejs/form.js?v={{ date().timestamp }}\"></script>

{% endblock %}

", "Org_1/Home/form.twig", "/home/phpapp/pwc_qc/templates/Org_1/Home/form.twig");
    }
}
