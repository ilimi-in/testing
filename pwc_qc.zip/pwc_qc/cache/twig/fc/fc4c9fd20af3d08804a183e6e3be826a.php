<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Org_1/Home/pathway_details.twig */
class __TwigTemplate_840308ad1cacbaf54bb09b5d567b69ca extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "Org_1/Layout/app_home.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("Org_1/Layout/app_home.twig", "Org_1/Home/pathway_details.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 3
        echo "    <div class=\"row success-messages\" id=\"section_msg\">           
            ";
        // line 4
        if (twig_get_attribute($this->env, $this->source, ($context["messages"] ?? null), "success", [], "array", true, true, false, 4)) {
            // line 5
            echo "                <div class=\"col-sm-12 text-center\">
                    <div class=\"section_msg\">
                        <b>";
            // line 7
            echo twig_escape_filter($this->env, (($__internal_compile_0 = (($__internal_compile_1 = ($context["messages"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["success"] ?? null) : null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["0"] ?? null) : null), "html", null, true);
            echo "</b>
                    </div>
                </div>
            ";
        }
        // line 11
        echo "    </div>

    <section class=\"pathway-details-sec\">
        <div class=\"bannertop-row\" style=\"background:url('../../upload/";
        // line 14
        echo twig_escape_filter($this->env, ($context["background"] ?? null), "html", null, true);
        echo "')\">
            <div class=\"container-xxl\">
                <div class=\"pathwaybanner\">
                <div class=\"d-flex justify-content-between\">
                    <div class=\"backbtn-row wd80p\">

                        <div class=\"thumbnail-bgimg\">
                            <!-- <img src=\"...\" class=\"rounded\" alt=\"...\"> -->
                            <!-- <img src=\"";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "image", [], "any", false, false, false, 22), "html", null, true);
        echo "\"> -->
                        </div>
                        
                        <div class=\"dis-inblock va-top headingsec\">
                            <div class=\"pathwayrow\">
                            <ul>
                                <li>

                                    <label class=\"pathwaygeneral-text\">Pathway : ";
        // line 30
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "pathway_type_name", [], "any", false, false, false, 30), "html", null, true);
        echo "</label>

                                    
                                </li>
                                <li>PwC</li>
                            </ul>
                        </div>
                            
                            <h1 class=\"serifb-text\">";
        // line 38
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "title", [], "any", false, false, false, 38), "html", null, true);
        echo "</h1>
                            <div class='comment more'>";
        // line 39
        echo twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "description", [], "any", false, false, false, 39);
        echo "</div>

                            <div class=\"pathway-subrow\">
                            <ul class=\"ps-0 pathway-subrow mb-4\">
                                <li>";
        // line 43
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "duration", [], "any", false, false, false, 43), "html", null, true);
        echo "</li>
                                <li>";
        // line 44
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "proficency_level", [], "any", false, false, false, 44), "html", null, true);
        echo "</li>
                            </ul>
                            </div>


                            <a href=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("secFormRender", ["lang" => ($context["lang"] ?? null), "formName" => "pwc-section-details
", "id" =>         // line 50
($context["pathwayId"] ?? null)]), "html", null, true);
        echo "\" class=\"secondary-btn d-inline mgl-o\"> Add section </a>
                            


                            ";
        // line 54
        if ((twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "is_active", [], "any", false, false, false, 54) == "1")) {
            // line 55
            echo "                            
                                <a href=\"javascript:void(0)\" target=\"_blank\" class=\"primary-btn d-inline\" id=\"showPreview\" pathway-id=\"";
            // line 56
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 56), "html", null, true);
            echo "\"> Preview </a>

                            ";
        } elseif ((twig_get_attribute($this->env, $this->source,         // line 58
($context["getPathwayData"] ?? null), "is_active", [], "any", false, false, false, 58) == "2")) {
            // line 59
            echo "                               <button class=\"primary-btn d-inline noneactive\" disabled=\"disabled\">Preview</button>
                            ";
        }
        // line 60
        echo " 
                        </li>
                ";
        // line 62
        if ((twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "pathway_type", [], "any", false, false, false, 62) == "2")) {
            // line 63
            echo "                ";
            if ((twig_length_filter($this->env, ($context["getSectionDetals"] ?? null)) > 0)) {
                // line 64
                echo "                <div class=\"learnercompletes-row detailoption-row\">
                    <p class=\"font-bold\">To complete this pathway, the learner must complete <span class=\"mandatory_label\">*</span></p>
                    <ul>
                        <li><select class=\"form-select numberselcet min-complition\" pathway-id=\"";
                // line 67
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 67), "html", null, true);
                echo "\" mode=\"pathway\" aria-label=\"Default select example\">
                            ";
                // line 68
                if ((twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "completion_min", [], "any", false, false, false, 68) == "")) {
                    // line 69
                    echo "                                <option>0</option>
                            ";
                }
                // line 71
                echo "                            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["getSectionDetals"] ?? null));
                foreach ($context['_seq'] as $context["dataKey"] => $context["data"]) {
                    // line 72
                    echo "                            <option value=\"";
                    echo twig_escape_filter($this->env, ($context["dataKey"] + 1), "html", null, true);
                    echo "\" ";
                    if ((($context["dataKey"] + 1) == twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "completion_min", [], "any", false, false, false, 72))) {
                        echo " selected ";
                    }
                    echo ">";
                    echo twig_escape_filter($this->env, ($context["dataKey"] + 1), "html", null, true);
                    echo "</option>
                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['dataKey'], $context['data'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 74
                echo "                          </select></li>
                        <li>sections out of ";
                // line 75
                echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["getSectionDetals"] ?? null)), "html", null, true);
                echo "</li>
                    </ul>
                </div>
                ";
            }
            // line 79
            echo "            ";
        } elseif ((twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "pathway_type", [], "any", false, false, false, 79) == "4")) {
            // line 80
            echo "                ";
            if ((twig_length_filter($this->env, ($context["getSectionDetals"] ?? null)) > 0)) {
                // line 81
                echo "                    <div class=\"mb-4 smm-row detailoption-row wid-full\">
                        <label for=\"\">Learner starts below sequence from section <span class=\"mandatory_label\">*</span></label>
                        <select class=\"form-select add-sequence\" pathway-id=\"";
                // line 83
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 83), "html", null, true);
                echo "\" mode=\"pathway\" aria-label=\"Default select example\">
                            <option selected>Open this select menu</option>
                            ";
                // line 85
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["getSectionDetals"] ?? null));
                foreach ($context['_seq'] as $context["dataKey"] => $context["data"]) {
                    // line 86
                    echo "                                <option value=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "secid", [], "any", false, false, false, 86), "html", null, true);
                    echo "\" ";
                    if ((twig_get_attribute($this->env, $this->source, $context["data"], "secid", [], "any", false, false, false, 86) == twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "sequence_start", [], "any", false, false, false, 86))) {
                        echo " selected ";
                    }
                    echo ">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "title", [], "any", false, false, false, 86), "html", null, true);
                    echo " </option>
                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['dataKey'], $context['data'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 88
                echo "                        </select>
                    </div>
                ";
            }
            // line 91
            echo "            ";
        }
        echo " 
                        </div>

                    </div>

                    <div class=\"\">
                        <div class=\"dis-inblock dropdown\">
                            <a href=\"#\" class=\"circle-btn\" role=\"button\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\"> 
                                <img src=\"";
        // line 99
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "images/setting-icon.svg\" alt=\"Setting_icon\">
                             </a>

                            <ul class=\"dropdown-menu\" style=\"\">
                                <li><a class=\"dropdown-item\" href=\"#\" data-bs-toggle=\"modal\" data-bs-target=\"#backModal\">Change pathway background</a></li>
                                <li><a class=\"dropdown-item deletePathway\"  pathway-id=\"";
        // line 104
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 104), "html", null, true);
        echo "\" href=\"#\">Delete Pathway</a></li>
\t\t\t\t\t\t\t\t
                    
                            </ul>

                            <div id=\"myModal\" class=\"modal\">
                                <div class=\"modal-dialog\">
                                <div class=\"modal-content\">
                                  <div class=\"modal-header\">
                                    <h1 class=\"modal-title fs-5\" id=\"exampleModalLabel\">Delete pathway</h1>
                                    <button type=\"button\" id=\"closelBtn\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
                                  </div>
                                  <div class=\"modal-body\">
                                <p>Are you sure you want to delete all the information you’ve added? You’ll not be able to undo it.</p>
                                </div>

                                <div class=\"modal-footer\">
                                    <button id=\"cancelBtn\" class=\"cancelbtn\">Cancel</button>
                                    <button id=\"confirmBtn\" class=\"deletebtn\">Yes Delete</button>
                                    
                                  </div>
                              </div>
                            </div> 

                        </div>


                        </div>
                    </div>
                </div>
            </div>

          
            </div>
        </div>


        
    </section>

    ";
        // line 144
        if ((twig_length_filter($this->env, ($context["getSectionDetals"] ?? null)) > 0)) {
            // line 145
            echo "    <section class=\"grabg\">
        <div class=\"container-xxl\">
            <div class=\"accordion mg_t55 mg-l50\" id=\"accordionPanelsStayOpenExample\">

                ";
            // line 149
            $context["sno"] = 0;
            // line 150
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["getSectionDetals"] ?? null));
            foreach ($context['_seq'] as $context["dataKey"] => $context["data"]) {
                // line 151
                echo "                ";
                $context["sno"] = (($context["sno"] ?? null) + 1);
                // line 152
                echo "                <div class=\"accordion-item\">
                    <div class=\"accordion-header\" id=\"headingOne\">
                        <div class=\"accordion-button custom-acco-bar\" id=\"validation_";
                // line 154
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "valid_id", [], "any", false, false, false, 154), "html", null, true);
                echo "\">

                            <span class=\"sidebtn-bar noafter topsection-bar\">
                                <ul>
                                    ";
                // line 158
                if ((twig_get_attribute($this->env, $this->source, (($__internal_compile_2 = ($context["getSectionDetals"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2[(($context["sno"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 158) == "")) {
                    // line 159
                    echo "                                    <li class=\"move-btn noneactive\" data-current=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 159), "html", null, true);
                    echo "\" data-node=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_3 = ($context["getSectionDetals"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3[(($context["sno"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 159), "html", null, true);
                    echo "\" disabled='disabled'>
                                    <img src=\"";
                    // line 160
                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                    echo "images/moveup-icon.svg\" alt=\"up-arrow-disable\">
                                    </li>
                                    ";
                } else {
                    // line 163
                    echo "                                    <li class=\"upButton\" data-current=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 163), "html", null, true);
                    echo "\" data-node=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_4 = ($context["getSectionDetals"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4[(($context["sno"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 163), "html", null, true);
                    echo "\">
                                        <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"";
                    // line 164
                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                    echo "images/moveup-icon.svg\" alt=\"up-arrow\"></a>
                                    </li>
                                    ";
                }
                // line 167
                echo "                                    
                                        
                                    ";
                // line 169
                if ((twig_get_attribute($this->env, $this->source, (($__internal_compile_5 = ($context["getSectionDetals"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5[($context["sno"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 169) == "")) {
                    // line 170
                    echo "                                    <li class=\"move-btn noneactive\" data-current=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 170), "html", null, true);
                    echo "\"  data-node=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_6 = ($context["getSectionDetals"] ?? null)) && is_array($__internal_compile_6) || $__internal_compile_6 instanceof ArrayAccess ? ($__internal_compile_6[($context["sno"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 170), "html", null, true);
                    echo "\" disabled='disabled'>
                                       <img src=\"";
                    // line 171
                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                    echo "images/movedown-icon.svg\" alt=\"down-arrow-disable\">
                                    </li>
                                    ";
                } else {
                    // line 174
                    echo "                                    <li class=\"downButton\" data-current=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 174), "html", null, true);
                    echo "\"  data-node=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_7 = ($context["getSectionDetals"] ?? null)) && is_array($__internal_compile_7) || $__internal_compile_7 instanceof ArrayAccess ? ($__internal_compile_7[($context["sno"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 174), "html", null, true);
                    echo "\" >
                                        <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"";
                    // line 175
                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                    echo "images/movedown-icon.svg\" alt=\"down-arrow\"></a>
                                    </li>
                                    ";
                }
                // line 178
                echo "                                    
                                        
                                </ul>
                            </span>


                            <div class=\"sec-content\">
                                <div class=\"pathwayrow\">
                                    <ul>
                                        <li>
                                            <label class=\"pathwaygeneral-text\">Section: ";
                // line 188
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "type_name", [], "any", false, false, false, 188), "html", null, true);
                echo "</label>
                                        </li>
                                    </ul>
                                </div>

                                
                                <h2>";
                // line 194
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "title", [], "any", false, false, false, 194), "html", null, true);
                echo "</h2>
                                ";
                // line 195
                echo twig_get_attribute($this->env, $this->source, $context["data"], "description", [], "any", false, false, false, 195);
                echo "

                                ";
                // line 197
                if ((twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "pathway_type", [], "any", false, false, false, 197) == "4")) {
                    // line 198
                    echo "                                    ";
                    if ((twig_get_attribute($this->env, $this->source, $context["data"], "secid", [], "any", false, false, false, 198) == twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "sequence_start", [], "any", false, false, false, 198))) {
                        // line 199
                        echo "                                        <p>First in sequence, section unlocked for learner.</p>
                                    ";
                    } else {
                        // line 201
                        echo "                                        <div class=\"mb-4 smm-row\">
                                            <label for=\"\">Unlock this section when Learner completes <span class=\"mandatory_label\">*</span></label>
                                            <select class=\"form-select unlock-this\" pathway-id=\"";
                        // line 203
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 203), "html", null, true);
                        echo "\" section-id=\"";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "secid", [], "any", false, false, false, 203), "html", null, true);
                        echo "\" mode=\"section\" aria-label=\"Default select example\">
                                                <option value=\"\">Open this select menu</option>
                                                ";
                        // line 205
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(($context["getSectionDetals"] ?? null));
                        foreach ($context['_seq'] as $context["datasKey"] => $context["datas"]) {
                            // line 206
                            echo "                                                    ";
                            if ((twig_get_attribute($this->env, $this->source, $context["datas"], "secid", [], "any", false, false, false, 206) != twig_get_attribute($this->env, $this->source, $context["data"], "secid", [], "any", false, false, false, 206))) {
                                // line 207
                                echo "                                                        <option value=\"";
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["datas"], "secid", [], "any", false, false, false, 207), "html", null, true);
                                echo "\" ";
                                if ((twig_get_attribute($this->env, $this->source, $context["datas"], "secid", [], "any", false, false, false, 207) == twig_get_attribute($this->env, $this->source, $context["data"], "sequence_num", [], "any", false, false, false, 207))) {
                                    echo " selected ";
                                }
                                echo ">";
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["datas"], "title", [], "any", false, false, false, 207), "html", null, true);
                                echo "</option>
                                                    ";
                            }
                            // line 209
                            echo "                                                ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['datasKey'], $context['datas'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 210
                        echo "                                            </select>
                                        </div>
                                    ";
                    }
                    // line 213
                    echo "                                ";
                } elseif ((twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "pathway_type", [], "any", false, false, false, 213) == "1")) {
                    // line 214
                    echo "                                    <div class=\"mb-4 smm-row\">
                                        <label for=\"\">Make this section part of a branch? <span class=\"mandatory_label\">*</span></label>
                                        <select class=\"form-select add-branch\" section-id=\"";
                    // line 216
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "secid", [], "any", false, false, false, 216), "html", null, true);
                    echo "\">
                                            <option>Select branch</option>
                                            ";
                    // line 218
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(($context["getBranch"] ?? null));
                    foreach ($context['_seq'] as $context["databKey"] => $context["datab"]) {
                        // line 219
                        echo "                                            <option value=\"";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["datab"], "id", [], "any", false, false, false, 219), "html", null, true);
                        echo "\"  ";
                        if ((twig_get_attribute($this->env, $this->source, $context["datab"], "id", [], "any", false, false, false, 219) == twig_get_attribute($this->env, $this->source, $context["data"], "section_branch", [], "any", false, false, false, 219))) {
                            echo " selected ";
                        }
                        echo ">";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["datab"], "value_of_data", [], "any", false, false, false, 219), "html", null, true);
                        echo "</option>
                                            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['databKey'], $context['datab'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 221
                    echo "                                        </select>
                                    </div>
                                ";
                } elseif ((twig_get_attribute($this->env, $this->source,                 // line 223
($context["getPathwayData"] ?? null), "pathway_type", [], "any", false, false, false, 223) == "3")) {
                    // line 224
                    echo "                                    
                                ";
                }
                // line 226
                echo "

                                ";
                // line 228
                if ((twig_get_attribute($this->env, $this->source, $context["data"], "type_id", [], "any", false, false, false, 228) == 2)) {
                    // line 229
                    echo "                                    ";
                    if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 229)) > 0)) {
                        // line 230
                        echo "                                        <div class=\"learnercompletes-row\">
                                            <p class=\"font-bold\">To complete this section, the learner must complete <span class=\"mandatory_label\">*</span></p>
                                            <ul>
                                                <li><select class=\"form-select numberselcet min-complition-session\" pathway-id=\"";
                        // line 233
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 233), "html", null, true);
                        echo "\" session-id=\"";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 233), "html", null, true);
                        echo "\" mode=\"session\" aria-label=\"Default select example\">
                                                    ";
                        // line 234
                        if ((twig_get_attribute($this->env, $this->source, $context["data"], "completion_min", [], "any", false, false, false, 234) == "")) {
                            // line 235
                            echo "                                                        <option>0</option>
                                                    ";
                        }
                        // line 237
                        echo "                                                    ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 237));
                        foreach ($context['_seq'] as $context["subSecDataKey"] => $context["subSecData"]) {
                            // line 238
                            echo "                                                    <option value=\"";
                            echo twig_escape_filter($this->env, ($context["subSecDataKey"] + 1), "html", null, true);
                            echo "\" ";
                            if ((($context["subSecDataKey"] + 1) == twig_get_attribute($this->env, $this->source, $context["data"], "completion_min", [], "any", false, false, false, 238))) {
                                echo " selected ";
                            }
                            echo ">";
                            echo twig_escape_filter($this->env, ($context["subSecDataKey"] + 1), "html", null, true);
                            echo "</option>
                                                    ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['subSecDataKey'], $context['subSecData'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 240
                        echo "                                                  </select></li>
                                                <li>subsections/learning items out of ";
                        // line 241
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 241)), "html", null, true);
                        echo "</li>
                                            </ul>
                                        </div>
                                    ";
                    }
                    // line 245
                    echo "                                ";
                } elseif ((twig_get_attribute($this->env, $this->source, $context["data"], "type_id", [], "any", false, false, false, 245) == 4)) {
                    // line 246
                    echo "                                    ";
                    if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 246)) > 0)) {
                        // line 247
                        echo "                                        <div class=\"mb-4 smm-row\">
                                            <label for=\"\">Learner starts below sequence from learning item <span class=\"mandatory_label\">*</span></label>
                                            <select class=\"form-select add-sequence-sec\" pathway-id=\"";
                        // line 249
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 249), "html", null, true);
                        echo "\" section-id=\"";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "secid", [], "any", false, false, false, 249), "html", null, true);
                        echo "\" mode=\"section\" aria-label=\"Default select example\">
                                                <option selected>Open this select menu</option>
                                                ";
                        // line 251
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 251));
                        foreach ($context['_seq'] as $context["subSecDataKey"] => $context["subSecData"]) {
                            // line 252
                            echo "                                                    <option value=\"";
                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 252), "html", null, true);
                            echo "\" ";
                            if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 252) == twig_get_attribute($this->env, $this->source, $context["data"], "sequence_start", [], "any", false, false, false, 252))) {
                                echo " selected ";
                            }
                            echo ">";
                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "title", [], "any", false, false, false, 252), "html", null, true);
                            echo " </option>
                                                ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['subSecDataKey'], $context['subSecData'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 254
                        echo "                                            </select>
                                        </div>
                                    ";
                    }
                    // line 257
                    echo "                                ";
                }
                // line 258
                echo "
                                <div class=\"d-flex justify-content-between\">

                                    <ul class=\"mb-0\">
                                        <li>
                                            <a href=\"";
                // line 263
                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("subSecFormRender", ["lang" => ($context["lang"] ?? null), "formName" => "pwc-sub-section-details", "id" => ($context["pathwayId"] ?? null), "sectionId" => twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 263)]), "html", null, true);
                echo "\" class=\"secondary-btn\">
                                                Add subsection </a>
                                        </li>
                                        <li>
                                            <a href=\"";
                // line 267
                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("subSecFormRender", ["lang" => ($context["lang"] ?? null), "formName" => "pwc-external-learning-object", "id" => ($context["pathwayId"] ?? null), "sectionId" => twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 267)]), "html", null, true);
                echo "\" class=\"secondary-btn\">
                                                Add learning object </a>
                                        </li>
                                    </ul>
                                    <ul class=\"mb-0\">
                                        <li>
                                            <a href=\"";
                // line 273
                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("editDraft", ["id" => twig_get_attribute($this->env, $this->source, $context["data"], "mongo_id", [], "any", false, false, false, 273), "form_type" => "pwc-section-details", "lang" => ($context["lang"] ?? null)]), "html", null, true);
                echo "\" class=\"circle-btn\"> <img src=\"";
                echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                echo "images/edit-icon.svg\" alt=\"edit-section\"> </a>
                                        </li>
                                       
                                        <li class=\"delete_subsec\" id=\"";
                // line 276
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "id", [], "any", false, false, false, 276), "html", null, true);
                echo "\" data-title=\"section\">
                                           <a href=\"javascript:void(0)\" class=\"circle-btn\"> <img src=\"";
                // line 277
                echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                echo "images/delete-icon.svg\" alt=\"delete-section\"></a>
                                        </li>

                                         <div id=\"myModalSection\" class=\"modal\">
                                            <div class=\"modal-dialog\">
                                                <div class=\"modal-content\">
                                                  <div class=\"modal-header\">
                                                    <h1 class=\"modal-title fs-5\" id=\"exampleModalLabel\"><p id=\"sechead\"></p></h1>
                                                    <button type=\"button\" id=\"closelBtnsection\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
                                                  </div>
                                                  <div class=\"modal-body\">
                                                <p id=\"secmsg\"></p>
                                                </div>

                                                <div class=\"modal-footer\">
                                                    <button id=\"cancelBtnsetion\" class=\"cancelbtn\">Cancel</button>
                                                    <button id=\"confirmBtnSection\" class=\"deletebtn\">Yes Delete</button>
                                                    
                                                  </div>
                                              </div>
                                            </div> 

                                        </div>
                                        
                                        ";
                // line 301
                if (((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 301)) > 0) || (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "learningObject", [], "any", false, false, false, 301)) > 0))) {
                    // line 302
                    echo "                                        <li>
                                            <a class=\"circle-btn\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapseOne";
                    // line 303
                    echo twig_escape_filter($this->env, ($context["sno"] ?? null), "html", null, true);
                    echo "\" aria-expanded=\"true\" aria-controls=\"collapseOne";
                    echo twig_escape_filter($this->env, ($context["sno"] ?? null), "html", null, true);
                    echo "\">
                                                <img class=\"uparrow-icon\" src=\"";
                    // line 304
                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                    echo "images/uparrow-icon.svg\" alt=\"collapse-icon\">
                                                <img class=\"collapse-icon\" src=\"";
                    // line 305
                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                    echo "images/collapse-icon.svg\" alt=\"collapse-icon\">
                                            </a>
                                        </li>
                                        ";
                }
                // line 309
                echo "
                                    </ul>
                                </div>

                            </div>

                        </div>
                    </div>
                    ";
                // line 317
                if (((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 317)) > 0) || (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "learningObject", [], "any", false, false, false, 317)) > 0))) {
                    // line 318
                    echo "                    <div id=\"collapseOne";
                    echo twig_escape_filter($this->env, ($context["sno"] ?? null), "html", null, true);
                    echo "\" class=\"accordion-collapse collapse show\" aria-labelledby=\"headingOne\"
                        data-bs-parent=\"#accordionExample\">
                        <div class=\"accordion-body\">

                            <div class=\"accordion\" id=\"accordionPanelsStayOpenExampleI\">
                                ";
                    // line 323
                    if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 323)) > 0)) {
                        // line 324
                        echo "                                ";
                        $context["snoSubSec"] = 0;
                        // line 325
                        echo "                                ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 325));
                        foreach ($context['_seq'] as $context["subSecDataKey"] => $context["subSecData"]) {
                            // line 326
                            echo "                                ";
                            $context["snoSubSec"] = (($context["snoSubSec"] ?? null) + 1);
                            // line 327
                            echo "                                <div class=\"accordion-item\">
                                    <div class=\"accordion-header\" id=\"subsection-heading-I\">
                                        <div class=\"accordion-button custom-acco-bar\"  id=\"validation_";
                            // line 329
                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "valid_id", [], "any", false, false, false, 329), "html", null, true);
                            echo "\">

                                            ";
                            // line 331
                            if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "category", [], "any", false, false, false, 331) == "1")) {
                                // line 332
                                echo "                                                <!-- section -->


                                                <div class=\"sidebtn-bar\">
                                                    <ul>
                                                        ";
                                // line 337
                                if ((twig_get_attribute($this->env, $this->source, (($__internal_compile_8 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 337)) && is_array($__internal_compile_8) || $__internal_compile_8 instanceof ArrayAccess ? ($__internal_compile_8[(($context["snoSubSec"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 337) == "")) {
                                    // line 338
                                    echo "                                                         <li class=\"move-btn noneactive\" data-current=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 338), "html", null, true);
                                    echo "\" data-node=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_9 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 338)) && is_array($__internal_compile_9) || $__internal_compile_9 instanceof ArrayAccess ? ($__internal_compile_9[(($context["snoSubSec"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 338), "html", null, true);
                                    echo "\" disabled='disabled'>
                                                            <img src=\"";
                                    // line 339
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/moveup-icon.svg\"
                                                                    alt=\"up-arrow-disable\">
                                                        </li>
                                                        ";
                                } else {
                                    // line 343
                                    echo "                                                         <li class=\"downButton\" data-current=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 343), "html", null, true);
                                    echo "\" data-node=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_10 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 343)) && is_array($__internal_compile_10) || $__internal_compile_10 instanceof ArrayAccess ? ($__internal_compile_10[(($context["snoSubSec"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 343), "html", null, true);
                                    echo "\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"";
                                    // line 344
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/moveup-icon.svg\"
                                                                    alt=\"up-arrow\"></a>
                                                        </li>
                                                        ";
                                }
                                // line 348
                                echo "                                                       

                                                       ";
                                // line 350
                                if ((twig_get_attribute($this->env, $this->source, (($__internal_compile_11 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 350)) && is_array($__internal_compile_11) || $__internal_compile_11 instanceof ArrayAccess ? ($__internal_compile_11[($context["snoSubSec"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 350) == "")) {
                                    // line 351
                                    echo "                                                       <li class=\"move-btn noneactive\" data-current=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 351), "html", null, true);
                                    echo "\" data-node=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_12 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 351)) && is_array($__internal_compile_12) || $__internal_compile_12 instanceof ArrayAccess ? ($__internal_compile_12[($context["snoSubSec"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 351), "html", null, true);
                                    echo "\" disabled='disabled'>
                                                            <img src=\"";
                                    // line 352
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/movedown-icon.svg\"
                                                                    alt=\"down-arrow-disable\">
                                                        </li>
                                                       ";
                                } else {
                                    // line 356
                                    echo "                                                       <li class=\"downButton\" data-current=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 356), "html", null, true);
                                    echo "\" data-node=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_13 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 356)) && is_array($__internal_compile_13) || $__internal_compile_13 instanceof ArrayAccess ? ($__internal_compile_13[($context["snoSubSec"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 356), "html", null, true);
                                    echo "\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"";
                                    // line 357
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/movedown-icon.svg\"
                                                                    alt=\"down-arrow\"></a>
                                                        </li>
                                                       ";
                                }
                                // line 361
                                echo "                                                        
                                                    </ul>
                                                </div>

                                                <div class=\"pathwayrow\">
                                                    <ul>
                                                        <li>
                                                            <label class=\"pathwaygeneral-text\">Subsection: ";
                                // line 368
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "type_name", [], "any", false, false, false, 368), "html", null, true);
                                echo "</label>
                                                        </li>
                                                    </ul>
                                                </div>

                                                
                                                <h2>";
                                // line 374
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "title", [], "any", false, false, false, 374), "html", null, true);
                                echo "</h2>
                                                ";
                                // line 375
                                echo twig_get_attribute($this->env, $this->source, $context["subSecData"], "description", [], "any", false, false, false, 375);
                                echo "


                                                ";
                                // line 378
                                if ((twig_get_attribute($this->env, $this->source, $context["data"], "type_id", [], "any", false, false, false, 378) == 4)) {
                                    // line 379
                                    echo "                                                    ";
                                    if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 379) == twig_get_attribute($this->env, $this->source, $context["data"], "sequence_start", [], "any", false, false, false, 379))) {
                                        // line 380
                                        echo "                                                        <p>First in sequence, learning item unlocked for learner.</p>
                                                    ";
                                    } else {
                                        // line 382
                                        echo "                                                        <div class=\"mb-4 smm-row\">
                                                            <label for=\"\">Unlock this subsection when Learner completes <span class=\"mandatory_label\">*</span></label>
                                                            <select class=\"form-select unlock-this\" pathway-id=\"";
                                        // line 384
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 384), "html", null, true);
                                        echo "\" section-id=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 384), "html", null, true);
                                        echo "\" mode=\"section\" aria-label=\"Default select example\">
                                                                <option value=\"\">Open this select menu</option>
                                                                ";
                                        // line 386
                                        $context['_parent'] = $context;
                                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 386));
                                        foreach ($context['_seq'] as $context["subSecDataKeys"] => $context["subSecDatas"]) {
                                            // line 387
                                            echo "                                                                    ";
                                            if ((twig_get_attribute($this->env, $this->source, $context["subSecDatas"], "subsecid", [], "any", false, false, false, 387) != twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 387))) {
                                                // line 388
                                                echo "                                                                        <option value=\"";
                                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecDatas"], "subsecid", [], "any", false, false, false, 388), "html", null, true);
                                                echo "\" ";
                                                if ((twig_get_attribute($this->env, $this->source, $context["subSecDatas"], "subsecid", [], "any", false, false, false, 388) == twig_get_attribute($this->env, $this->source, $context["subSecData"], "sequence_num", [], "any", false, false, false, 388))) {
                                                    echo " selected ";
                                                }
                                                echo ">";
                                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecDatas"], "title", [], "any", false, false, false, 388), "html", null, true);
                                                echo "</option>
                                                                    ";
                                            }
                                            // line 390
                                            echo "                                                                ";
                                        }
                                        $_parent = $context['_parent'];
                                        unset($context['_seq'], $context['_iterated'], $context['subSecDataKeys'], $context['subSecDatas'], $context['_parent'], $context['loop']);
                                        $context = array_intersect_key($context, $_parent) + $_parent;
                                        // line 391
                                        echo "                                                            </select>
                                                        </div>
                                                    ";
                                    }
                                    // line 394
                                    echo "                                                ";
                                } elseif ((twig_get_attribute($this->env, $this->source, $context["data"], "type_id", [], "any", false, false, false, 394) == 3)) {
                                    // line 395
                                    echo "                                                    
                                                ";
                                }
                                // line 397
                                echo "

                                                ";
                                // line 399
                                if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "type_id", [], "any", false, false, false, 399) == 2)) {
                                    // line 400
                                    echo "                                                    ";
                                    if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 400)) > 0)) {
                                        // line 401
                                        echo "                                                        <div class=\"learnercompletes-row\">
                                                            <p class=\"font-bold\">To complete this subsection, the learner must complete <span class=\"mandatory_label\">*</span></p>
                                                            <ul>
                                                                <li><select class=\"form-select numberselcet min-complition-session\" pathway-id=\"";
                                        // line 404
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 404), "html", null, true);
                                        echo "\" session-id=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 404), "html", null, true);
                                        echo "\" mode=\"session\" aria-label=\"Default select example\">
                                                                    ";
                                        // line 405
                                        if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "completion_min", [], "any", false, false, false, 405) == "")) {
                                            // line 406
                                            echo "                                                                        <option>0</option>
                                                                    ";
                                        }
                                        // line 408
                                        echo "                                                                    ";
                                        $context['_parent'] = $context;
                                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 408));
                                        foreach ($context['_seq'] as $context["learningObjDataKey"] => $context["learningObjData"]) {
                                            // line 409
                                            echo "                                                                    <option value=\"";
                                            echo twig_escape_filter($this->env, ($context["learningObjDataKey"] + 1), "html", null, true);
                                            echo "\" ";
                                            if ((($context["learningObjDataKey"] + 1) == twig_get_attribute($this->env, $this->source, $context["subSecData"], "completion_min", [], "any", false, false, false, 409))) {
                                                echo " selected ";
                                            }
                                            echo ">";
                                            echo twig_escape_filter($this->env, ($context["learningObjDataKey"] + 1), "html", null, true);
                                            echo "</option>
                                                                    ";
                                        }
                                        $_parent = $context['_parent'];
                                        unset($context['_seq'], $context['_iterated'], $context['learningObjDataKey'], $context['learningObjData'], $context['_parent'], $context['loop']);
                                        $context = array_intersect_key($context, $_parent) + $_parent;
                                        // line 411
                                        echo "                                                                  </select></li>
                                                                <li>learning items out of ";
                                        // line 412
                                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 412)), "html", null, true);
                                        echo "</li>
                                                            </ul>
                                                        </div>
                                                    ";
                                    }
                                    // line 416
                                    echo "                                                ";
                                } elseif ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "type_id", [], "any", false, false, false, 416) == 4)) {
                                    // line 417
                                    echo "                                                    ";
                                    if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 417)) > 0)) {
                                        // line 418
                                        echo "                                                        <div class=\"mb-4 smm-row\">
                                                            <label for=\"\">Learner starts below sequence from learning item <span class=\"mandatory_label\">*</span></label>
                                                            <select class=\"form-select add-sequence-sec\" pathway-id=\"";
                                        // line 420
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 420), "html", null, true);
                                        echo "\" section-id=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 420), "html", null, true);
                                        echo "\" mode=\"section\" aria-label=\"Default select example\">
                                                                <option selected>Open this select menu</option>
                                                                ";
                                        // line 422
                                        $context['_parent'] = $context;
                                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 422));
                                        foreach ($context['_seq'] as $context["learningObjDataKey"] => $context["learningObjData"]) {
                                            // line 423
                                            echo "                                                                    <option value=\"";
                                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "lo_id", [], "any", false, false, false, 423), "html", null, true);
                                            echo "\" ";
                                            if ((twig_get_attribute($this->env, $this->source, $context["learningObjData"], "lo_id", [], "any", false, false, false, 423) == twig_get_attribute($this->env, $this->source, $context["subSecData"], "sequence_start", [], "any", false, false, false, 423))) {
                                                echo " selected ";
                                            }
                                            echo ">";
                                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "title", [], "any", false, false, false, 423), "html", null, true);
                                            echo "</option>
                                                                ";
                                        }
                                        $_parent = $context['_parent'];
                                        unset($context['_seq'], $context['_iterated'], $context['learningObjDataKey'], $context['learningObjData'], $context['_parent'], $context['loop']);
                                        $context = array_intersect_key($context, $_parent) + $_parent;
                                        // line 425
                                        echo "                                                            </select>
                                                        </div>
                                                    ";
                                    }
                                    // line 428
                                    echo "                                                ";
                                }
                                // line 429
                                echo "
                                                <div class=\"d-flex justify-content-between\">
                                                    <ul class=\"mb-0\">
                                                        <li>
                                                            <a href=\"";
                                // line 433
                                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("subSecFormRender", ["lang" => ($context["lang"] ?? null), "formName" => "pwc-external-learning-object", "id" => ($context["pathwayId"] ?? null), "sectionId" => twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 433)]), "html", null, true);
                                echo "\" class=\"secondary-btn\">
                                                                Add learning object  </a>
                                                        </li>
                                                    </ul>
                                                   
                                                    <ul class=\"mb-0\">
                                                
                                                            <li>
                                                                <a href=\"";
                                // line 441
                                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("editDraft", ["id" => twig_get_attribute($this->env, $this->source, $context["subSecData"], "mongo_id", [], "any", false, false, false, 441), "form_type" => "pwc-sub-section-details", "lang" => ($context["lang"] ?? null)]), "html", null, true);
                                echo "\" class=\"circle-btn\"> <img src=\"";
                                echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                echo "images/edit-icon.svg\"
                                                                        alt=\"edit-icon\"> </a>
                                                            </li>
                                                        
                                                       
                                                        <li class=\"delete_subsec\" id=\"";
                                // line 446
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 446), "html", null, true);
                                echo "\" data-title=\"subsection\">
                                                           <a href=\"javascript:void(0)\" class=\"circle-btn\"> <img src=\"";
                                // line 447
                                echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                echo "images/delete-icon.svg\" alt=\"delete-icon\"> </a>
                                                        </li>
                                                        ";
                                // line 449
                                if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 449)) > 0)) {
                                    // line 450
                                    echo "                                                        <li>
                                                            <a class=\"circle-btn\"  type=\"button\"
                                                            data-bs-toggle=\"collapse\" data-bs-target=\"#subsection";
                                    // line 452
                                    echo twig_escape_filter($this->env, ($context["snoSubSec"] ?? null), "html", null, true);
                                    echo "\"
                                                            aria-expanded=\"true\" aria-controls=\"subsection";
                                    // line 453
                                    echo twig_escape_filter($this->env, ($context["snoSubSec"] ?? null), "html", null, true);
                                    echo "\"> 
                                                            <img class=\"uparrow-icon\" src=\"";
                                    // line 454
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/uparrow-icon.svg\" alt=\"uparrow-icon\">
                                                            <img class=\"collapse-icon\" src=\"";
                                    // line 455
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/collapse-icon.svg\" alt=\"collapse-icon\">
                                                                 </a>
                                                        </li>
                                                        ";
                                }
                                // line 459
                                echo "                                                    </ul>
                                                </div>

                                            ";
                            } elseif ((twig_get_attribute($this->env, $this->source,                             // line 462
$context["subSecData"], "category", [], "any", false, false, false, 462) == "2")) {
                                // line 463
                                echo "                                                <div class=\"sidebtn-bar\">
                                                    <ul>
                                                        ";
                                // line 465
                                if ((twig_get_attribute($this->env, $this->source, (($__internal_compile_14 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 465)) && is_array($__internal_compile_14) || $__internal_compile_14 instanceof ArrayAccess ? ($__internal_compile_14[(($context["snoSubSec"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 465) == "")) {
                                    // line 466
                                    echo "                                                         <li class=\"move-btn noneactive\" data-current=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 466), "html", null, true);
                                    echo "\" data-node=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_15 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 466)) && is_array($__internal_compile_15) || $__internal_compile_15 instanceof ArrayAccess ? ($__internal_compile_15[(($context["snoSubSec"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 466), "html", null, true);
                                    echo "\" disabled='disabled'>
                                                            <img src=\"";
                                    // line 467
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/moveup-icon.svg\"
                                                                    alt=\"uparrow-icon-disabled\">
                                                        </li>
                                                        ";
                                } else {
                                    // line 471
                                    echo "                                                         <li class=\"downButton\" data-current=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 471), "html", null, true);
                                    echo "\" data-node=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_16 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 471)) && is_array($__internal_compile_16) || $__internal_compile_16 instanceof ArrayAccess ? ($__internal_compile_16[(($context["snoSubSec"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 471), "html", null, true);
                                    echo "\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"";
                                    // line 472
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/moveup-icon.svg\"
                                                                    alt=\"uparrow-icon\"></a>
                                                        </li>
                                                        ";
                                }
                                // line 476
                                echo "                                                       

                                                       ";
                                // line 478
                                if ((twig_get_attribute($this->env, $this->source, (($__internal_compile_17 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 478)) && is_array($__internal_compile_17) || $__internal_compile_17 instanceof ArrayAccess ? ($__internal_compile_17[($context["snoSubSec"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 478) == "")) {
                                    // line 479
                                    echo "                                                       <li class=\"move-btn noneactive\" data-current=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 479), "html", null, true);
                                    echo "\" data-node=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_18 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 479)) && is_array($__internal_compile_18) || $__internal_compile_18 instanceof ArrayAccess ? ($__internal_compile_18[($context["snoSubSec"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 479), "html", null, true);
                                    echo "\" disabled='disabled'>
                                                            <img src=\"";
                                    // line 480
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/movedown-icon.svg\"
                                                                    alt=\"down-arrow-disable\">
                                                        </li>
                                                       ";
                                } else {
                                    // line 484
                                    echo "                                                       <li class=\"downButton\" data-current=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 484), "html", null, true);
                                    echo "\" data-node=\"";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_19 = twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 484)) && is_array($__internal_compile_19) || $__internal_compile_19 instanceof ArrayAccess ? ($__internal_compile_19[($context["snoSubSec"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 484), "html", null, true);
                                    echo "\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"";
                                    // line 485
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/movedown-icon.svg\"
                                                                    alt=\"down-arrow\"></a>
                                                        </li>
                                                       ";
                                }
                                // line 489
                                echo "                                                        
                                                    </ul>
                                                </div>

                                                <div class=\"pathwayrow\">
                                                    <ul>
                                                        ";
                                // line 495
                                if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "lo_type", [], "any", false, false, false, 495) != "")) {
                                    // line 496
                                    echo "                                                            <li><b>";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "lo_type", [], "any", false, false, false, 496), "html", null, true);
                                    echo "</b></li>
                                                        ";
                                }
                                // line 498
                                echo "                                                        ";
                                if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "provider", [], "any", false, false, false, 498) != "")) {
                                    // line 499
                                    echo "                                                            <li>";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "provider", [], "any", false, false, false, 499), "html", null, true);
                                    echo "</li>
                                                        ";
                                }
                                // line 501
                                echo "
                                                        ";
                                // line 502
                                if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "level", [], "any", false, false, false, 502) != "")) {
                                    // line 503
                                    echo "                                                            <li>";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "level", [], "any", false, false, false, 503), "html", null, true);
                                    echo "</li>
                                                        ";
                                }
                                // line 505
                                echo "
                                                        ";
                                // line 506
                                if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "duration", [], "any", false, false, false, 506) != "")) {
                                    // line 507
                                    echo "                                                            <li>";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "duration", [], "any", false, false, false, 507), "html", null, true);
                                    echo "</li>
                                                        ";
                                }
                                // line 509
                                echo "
                                                        ";
                                // line 510
                                if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "is_active", [], "any", false, false, false, 510) == 1)) {
                                    // line 511
                                    echo "                                                            <li>Active</li>
                                                        ";
                                }
                                // line 513
                                echo "                                                    </ul>
                                                </div>
                                                <div class=\"lo_thumbnails\"><img src=\"";
                                // line 515
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "image", [], "any", false, false, false, 515), "html", null, true);
                                echo "\"></div>
                                                <h2>";
                                // line 516
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "title", [], "any", false, false, false, 516), "html", null, true);
                                echo "</h2>
                                                ";
                                // line 517
                                echo twig_get_attribute($this->env, $this->source, $context["subSecData"], "description", [], "any", false, false, false, 517);
                                echo "

                                                    ";
                                // line 519
                                if ((twig_get_attribute($this->env, $this->source, $context["data"], "type_id", [], "any", false, false, false, 519) == 4)) {
                                    // line 520
                                    echo "                                                        ";
                                    if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 520) == twig_get_attribute($this->env, $this->source, $context["data"], "sequence_start", [], "any", false, false, false, 520))) {
                                        // line 521
                                        echo "                                                            <p>First in sequence, learning item unlocked for learner.</p>
                                                        ";
                                    } else {
                                        // line 523
                                        echo "                                                            <div class=\"mb-4 smm-row\">
                                                                <label for=\"\">Unlock this learning item when Learner completes <span class=\"mandatory_label\">*</span></label>
                                                                <select class=\"form-select unlock-this\" pathway-id=\"";
                                        // line 525
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 525), "html", null, true);
                                        echo "\" section-id=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 525), "html", null, true);
                                        echo "\" mode=\"section\" aria-label=\"Default select example\">
                                                                    <option value=\"\">Open this select menu</option>
                                                                    ";
                                        // line 527
                                        $context['_parent'] = $context;
                                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["data"], "subSection", [], "any", false, false, false, 527));
                                        foreach ($context['_seq'] as $context["subSecDataKeys"] => $context["subSecDatas"]) {
                                            // line 528
                                            echo "                                                                        ";
                                            if ((twig_get_attribute($this->env, $this->source, $context["subSecDatas"], "subsecid", [], "any", false, false, false, 528) != twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 528))) {
                                                // line 529
                                                echo "                                                                            <option value=\"";
                                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecDatas"], "subsecid", [], "any", false, false, false, 529), "html", null, true);
                                                echo "\" ";
                                                if ((twig_get_attribute($this->env, $this->source, $context["subSecDatas"], "subsecid", [], "any", false, false, false, 529) == twig_get_attribute($this->env, $this->source, $context["subSecData"], "sequence_num", [], "any", false, false, false, 529))) {
                                                    echo " selected ";
                                                }
                                                echo ">";
                                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecDatas"], "title", [], "any", false, false, false, 529), "html", null, true);
                                                echo "</option>
                                                                        ";
                                            }
                                            // line 531
                                            echo "                                                                    ";
                                        }
                                        $_parent = $context['_parent'];
                                        unset($context['_seq'], $context['_iterated'], $context['subSecDataKeys'], $context['subSecDatas'], $context['_parent'], $context['loop']);
                                        $context = array_intersect_key($context, $_parent) + $_parent;
                                        // line 532
                                        echo "                                                                </select>
                                                            </div>
                                                        ";
                                    }
                                    // line 535
                                    echo "                                                    ";
                                } elseif ((twig_get_attribute($this->env, $this->source, $context["data"], "type_id", [], "any", false, false, false, 535) == 3)) {
                                    // line 536
                                    echo "                                                        
                                                    ";
                                }
                                // line 538
                                echo "
                                                    <div class=\"pathway-subrow\">
                                                        <ul class=\"ps-0 pathway-subrow mb-4\">
                                                            ";
                                // line 541
                                if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "is_mandatory", [], "any", false, false, false, 541) == 1)) {
                                    // line 542
                                    echo "                                                                <li>Mandatory</li>
                                                            ";
                                }
                                // line 544
                                echo "
                                                            ";
                                // line 545
                                if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "customFilter", [], "any", false, false, false, 545)) > 0)) {
                                    // line 546
                                    echo "                                                                ";
                                    $context['_parent'] = $context;
                                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["subSecData"], "customFilter", [], "any", false, false, false, 546));
                                    foreach ($context['_seq'] as $context["cusFilKey"] => $context["cusFilData"]) {
                                        // line 547
                                        echo "                                                                    <li>";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cusFilData"], "filter_key", [], "any", false, false, false, 547), "html", null, true);
                                        echo ": ";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cusFilData"], "filter_value", [], "any", false, false, false, 547), "html", null, true);
                                        echo "</li>
                                                                ";
                                    }
                                    $_parent = $context['_parent'];
                                    unset($context['_seq'], $context['_iterated'], $context['cusFilKey'], $context['cusFilData'], $context['_parent'], $context['loop']);
                                    $context = array_intersect_key($context, $_parent) + $_parent;
                                    // line 549
                                    echo "                                                            ";
                                }
                                // line 550
                                echo "
                                                        </ul>
                                                    </div>


                                                <div class=\"d-flex justify-content-between\">

                                                    <ul class=\"mb-0\">

                                                    </ul>
                                                    <ul class=\"mb-0\">
                                                        <li>
                                                            <a href=\"";
                                // line 562
                                echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("editDraft", ["id" => twig_get_attribute($this->env, $this->source, $context["subSecData"], "mongo_id", [], "any", false, false, false, 562), "form_type" => "pwc-external-learning-object", "lang" => ($context["lang"] ?? null)]), "html", null, true);
                                echo "\" class=\"circle-btn\"> <img
                                                                    src=\"";
                                // line 563
                                echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                echo "images/edit-icon.svg\" alt=\"edit-icon\"> </a>
                                                        </li>
                                                        <li  class=\"delete_lo\" id=\"";
                                // line 565
                                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "id", [], "any", false, false, false, 565), "html", null, true);
                                echo "\" >
                                                             <a href=\"javascript:void(0)\" class=\"circle-btn\"><img src=\"";
                                // line 566
                                echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                echo "images/delete-icon.svg\" alt=\"delete-icon\"> </a>
                                                        </li>

                                                    </ul>
                                                </div>
                                            ";
                            } else {
                                // line 572
                                echo "                                                <!-- nothing -->
                                            ";
                            }
                            // line 574
                            echo "
                                        </div>
                                    </div>
                                    ";
                            // line 577
                            if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 577)) > 0)) {
                                // line 578
                                echo "                                    <div id=\"subsection";
                                echo twig_escape_filter($this->env, ($context["snoSubSec"] ?? null), "html", null, true);
                                echo "\" class=\"accordion-collapse collapse show\"
                                        aria-labelledby=\"subsection-heading-I\" data-bs-parent=\"#accordionExampleI\">
                                        <div class=\"accordion-body losection\">

                                            ";
                                // line 582
                                $context["snoSubSecLO"] = 0;
                                // line 583
                                echo "                                            ";
                                $context['_parent'] = $context;
                                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 583));
                                foreach ($context['_seq'] as $context["learningObjDataKey"] => $context["learningObjData"]) {
                                    // line 584
                                    echo "                                            ";
                                    $context["snoSubSecLO"] = (($context["snoSubSecLO"] ?? null) + 1);
                                    // line 585
                                    echo "                                            <div class=\"custom-acco-bar lo-row position-relative\" id=\"validation_";
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "valid_id", [], "any", false, false, false, 585), "html", null, true);
                                    echo "\">


                                                <span class=\"sidebtn-bar\">
                                                    <ul>
                                                        ";
                                    // line 590
                                    if ((twig_get_attribute($this->env, $this->source, (($__internal_compile_20 = twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 590)) && is_array($__internal_compile_20) || $__internal_compile_20 instanceof ArrayAccess ? ($__internal_compile_20[(($context["snoSubSecLO"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 590) == "")) {
                                        // line 591
                                        echo "                                                        <li class=\"move-btn noneactive\" data-current=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "id", [], "any", false, false, false, 591), "html", null, true);
                                        echo "\" data-node=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_21 = twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 591)) && is_array($__internal_compile_21) || $__internal_compile_21 instanceof ArrayAccess ? ($__internal_compile_21[(($context["snoSubSecLO"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 591), "html", null, true);
                                        echo "\">
                                                           <img
                                                                    src=\"";
                                        // line 593
                                        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                        echo "images/moveup-icon.svg\" alt=\"up-arrow-disable\">
                                                        </li>
                                                        ";
                                    } else {
                                        // line 596
                                        echo "                                                        <li class=\"upButtonLO\" data-current=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "id", [], "any", false, false, false, 596), "html", null, true);
                                        echo "\" data-node=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_22 = twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 596)) && is_array($__internal_compile_22) || $__internal_compile_22 instanceof ArrayAccess ? ($__internal_compile_22[(($context["snoSubSecLO"] ?? null) - 2)] ?? null) : null), "id", [], "any", false, false, false, 596), "html", null, true);
                                        echo "\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img
                                                                    src=\"";
                                        // line 598
                                        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                        echo "images/moveup-icon.svg\" alt=\"uparrow-icon\"></a>
                                                        </li>
                                                        ";
                                    }
                                    // line 601
                                    echo "                                                        

                                                        ";
                                    // line 603
                                    if ((twig_get_attribute($this->env, $this->source, (($__internal_compile_23 = twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 603)) && is_array($__internal_compile_23) || $__internal_compile_23 instanceof ArrayAccess ? ($__internal_compile_23[($context["snoSubSecLO"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 603) == "")) {
                                        // line 604
                                        echo "                                                        <li class=\"move-btn noneactive\" data-current=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "id", [], "any", false, false, false, 604), "html", null, true);
                                        echo "\" data-node=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_24 = twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 604)) && is_array($__internal_compile_24) || $__internal_compile_24 instanceof ArrayAccess ? ($__internal_compile_24[($context["snoSubSecLO"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 604), "html", null, true);
                                        echo "\">
                                                        <img src=\"";
                                        // line 605
                                        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                        echo "images/movedown-icon.svg\" alt=\"down-arrow-disable\">
                                                        </li>
                                                        ";
                                    } else {
                                        // line 608
                                        echo "                                                        <li class=\"downButtonLO\" data-current=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "id", [], "any", false, false, false, 608), "html", null, true);
                                        echo "\" data-node=\"";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_25 = twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 608)) && is_array($__internal_compile_25) || $__internal_compile_25 instanceof ArrayAccess ? ($__internal_compile_25[($context["snoSubSecLO"] ?? null)] ?? null) : null), "id", [], "any", false, false, false, 608), "html", null, true);
                                        echo "\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img
                                                                    src=\"";
                                        // line 610
                                        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                        echo "images/movedown-icon.svg\" alt=\"down-arrow\"></a>
                                                        </li>
                                                        ";
                                    }
                                    // line 613
                                    echo "                                                        
                                                    </ul>
                                                </span>


                                                <div class=\"pathwayrow\">
                                                    <ul>
                                                        ";
                                    // line 620
                                    if ((twig_get_attribute($this->env, $this->source, $context["learningObjData"], "lo_type", [], "any", false, false, false, 620) != "")) {
                                        // line 621
                                        echo "                                                            <li><b>";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "lo_type", [], "any", false, false, false, 621), "html", null, true);
                                        echo "</b></li>
                                                        ";
                                    }
                                    // line 623
                                    echo "
                                                        ";
                                    // line 624
                                    if ((twig_get_attribute($this->env, $this->source, $context["learningObjData"], "provider", [], "any", false, false, false, 624) != "")) {
                                        // line 625
                                        echo "                                                            <li>";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "provider", [], "any", false, false, false, 625), "html", null, true);
                                        echo "</li>
                                                        ";
                                    }
                                    // line 627
                                    echo "
                                                        ";
                                    // line 628
                                    if ((twig_get_attribute($this->env, $this->source, $context["learningObjData"], "level", [], "any", false, false, false, 628) != "")) {
                                        // line 629
                                        echo "                                                            <li>";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "level", [], "any", false, false, false, 629), "html", null, true);
                                        echo "</li>
                                                        ";
                                    }
                                    // line 631
                                    echo "
                                                        ";
                                    // line 632
                                    if ((twig_get_attribute($this->env, $this->source, $context["learningObjData"], "duration", [], "any", false, false, false, 632) != "")) {
                                        // line 633
                                        echo "                                                            <li>";
                                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "duration", [], "any", false, false, false, 633), "html", null, true);
                                        echo "</li>
                                                        ";
                                    }
                                    // line 635
                                    echo "
                                                        ";
                                    // line 636
                                    if ((twig_get_attribute($this->env, $this->source, $context["learningObjData"], "is_active", [], "any", false, false, false, 636) == 1)) {
                                        // line 637
                                        echo "                                                            <li>Active</li>
                                                        ";
                                    }
                                    // line 639
                                    echo "                                                    </ul>
                                                </div>
                                                <div class=\"lo_thumbnails\"><img src=\"";
                                    // line 641
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "image", [], "any", false, false, false, 641), "html", null, true);
                                    echo "\"></div>
                                                <h2>";
                                    // line 642
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "title", [], "any", false, false, false, 642), "html", null, true);
                                    echo "</h2>
                                                ";
                                    // line 643
                                    echo twig_get_attribute($this->env, $this->source, $context["learningObjData"], "description", [], "any", false, false, false, 643);
                                    echo "

                                                ";
                                    // line 645
                                    if ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "type_id", [], "any", false, false, false, 645) == 4)) {
                                        // line 646
                                        echo "                                                    ";
                                        if ((twig_get_attribute($this->env, $this->source, $context["learningObjData"], "lo_id", [], "any", false, false, false, 646) == twig_get_attribute($this->env, $this->source, $context["subSecData"], "sequence_start", [], "any", false, false, false, 646))) {
                                            // line 647
                                            echo "                                                        <p>First in sequence, learning item unlocked for learner.</p>
                                                    ";
                                        } else {
                                            // line 649
                                            echo "                                                        <div class=\"mb-4 smm-row\">
                                                            <label for=\"\">Unlock this learning item when Learner completes <span class=\"mandatory_label\">*</span></label>
                                                            <select class=\"form-select unlock-this\" pathway-id=\"";
                                            // line 651
                                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 651), "html", null, true);
                                            echo "\" section-id=\"";
                                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subSecData"], "subsecid", [], "any", false, false, false, 651), "html", null, true);
                                            echo "\" learning-object=\"";
                                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "lo_id", [], "any", false, false, false, 651), "html", null, true);
                                            echo "\" mode=\"lo\" aria-label=\"Default select example\">
                                                                <option value=\"\">Open this select menu</option>
                                                                ";
                                            // line 653
                                            $context['_parent'] = $context;
                                            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["subSecData"], "learningObject", [], "any", false, false, false, 653));
                                            foreach ($context['_seq'] as $context["learningObjDataKeys"] => $context["learningObjDatas"]) {
                                                // line 654
                                                echo "                                                                    ";
                                                if ((twig_get_attribute($this->env, $this->source, $context["learningObjDatas"], "lo_id", [], "any", false, false, false, 654) != twig_get_attribute($this->env, $this->source, $context["learningObjData"], "lo_id", [], "any", false, false, false, 654))) {
                                                    // line 655
                                                    echo "                                                                        <option value=\"";
                                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjDatas"], "lo_id", [], "any", false, false, false, 655), "html", null, true);
                                                    echo "\" ";
                                                    if ((twig_get_attribute($this->env, $this->source, $context["learningObjDatas"], "lo_id", [], "any", false, false, false, 655) == twig_get_attribute($this->env, $this->source, $context["learningObjData"], "sequence_num", [], "any", false, false, false, 655))) {
                                                        echo " selected ";
                                                    }
                                                    echo ">";
                                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjDatas"], "title", [], "any", false, false, false, 655), "html", null, true);
                                                    echo "</option>
                                                                    ";
                                                }
                                                // line 657
                                                echo "                                                                ";
                                            }
                                            $_parent = $context['_parent'];
                                            unset($context['_seq'], $context['_iterated'], $context['learningObjDataKeys'], $context['learningObjDatas'], $context['_parent'], $context['loop']);
                                            $context = array_intersect_key($context, $_parent) + $_parent;
                                            // line 658
                                            echo "                                                            </select>
                                                        </div>
                                                    ";
                                        }
                                        // line 661
                                        echo "                                                ";
                                    } elseif ((twig_get_attribute($this->env, $this->source, $context["subSecData"], "type_id", [], "any", false, false, false, 661) == 3)) {
                                        // line 662
                                        echo "                                                    
                                                ";
                                    }
                                    // line 664
                                    echo "
                                                    <div class=\"pathway-subrow\">
                                                        <ul class=\"ps-0 pathway-subrow mb-4\">
                                                            ";
                                    // line 667
                                    if ((twig_get_attribute($this->env, $this->source, $context["learningObjData"], "is_mandatory", [], "any", false, false, false, 667) == 1)) {
                                        // line 668
                                        echo "                                                                <li>Mandatory</li>
                                                            ";
                                    }
                                    // line 670
                                    echo "                                                            ";
                                    if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "customFilter", [], "any", false, false, false, 670)) > 0)) {
                                        // line 671
                                        echo "                                                                ";
                                        $context['_parent'] = $context;
                                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["learningObjData"], "customFilter", [], "any", false, false, false, 671));
                                        foreach ($context['_seq'] as $context["cusFilKey"] => $context["cusFilData"]) {
                                            // line 672
                                            echo "                                                                    <li>";
                                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cusFilData"], "filter_key", [], "any", false, false, false, 672), "html", null, true);
                                            echo ": ";
                                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cusFilData"], "filter_value", [], "any", false, false, false, 672), "html", null, true);
                                            echo "</li>
                                                                ";
                                        }
                                        $_parent = $context['_parent'];
                                        unset($context['_seq'], $context['_iterated'], $context['cusFilKey'], $context['cusFilData'], $context['_parent'], $context['loop']);
                                        $context = array_intersect_key($context, $_parent) + $_parent;
                                        // line 674
                                        echo "                                                            ";
                                    }
                                    // line 675
                                    echo "                                                        </ul>
                                                    </div>



                                                <div class=\"d-flex justify-content-between\">

                                                    <ul class=\"mb-0\">

                                                    </ul>
                                                    <ul class=\"mb-0\">
                                                        <li>
                                                            <a href=\"";
                                    // line 687
                                    echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("editDraft", ["id" => twig_get_attribute($this->env, $this->source, $context["learningObjData"], "mongo_id", [], "any", false, false, false, 687), "form_type" => "pwc-external-learning-object", "lang" => ($context["lang"] ?? null)]), "html", null, true);
                                    echo "\" class=\"circle-btn\"> <img
                                                                    src=\"";
                                    // line 688
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/edit-icon.svg\" alt=\"edit-icon\"> </a>
                                                        </li>
                                                        <li class=\"delete_lo\" id=\"";
                                    // line 690
                                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["learningObjData"], "id", [], "any", false, false, false, 690), "html", null, true);
                                    echo "\" >
                                                            <a href=\"javascript:void(0)\" class=\"circle-btn\"> <img src=\"";
                                    // line 691
                                    echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
                                    echo "images/delete-icon.svg\" alt=\"delete-icon\"> </a>
                                                        </li>

                                                        

                                                    </ul>
                                                </div>

                                            </div>
                                            ";
                                }
                                $_parent = $context['_parent'];
                                unset($context['_seq'], $context['_iterated'], $context['learningObjDataKey'], $context['learningObjData'], $context['_parent'], $context['loop']);
                                $context = array_intersect_key($context, $_parent) + $_parent;
                                // line 701
                                echo "
                                            
                                        </div>
                                    </div>
                                    ";
                            }
                            // line 706
                            echo "                                </div>
                                ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['subSecDataKey'], $context['subSecData'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 708
                        echo "                                ";
                    }
                    // line 709
                    echo "                                
                            </div>

                        </div>
                    </div>
                    ";
                }
                // line 715
                echo "                </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['dataKey'], $context['data'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 717
            echo "

            </div>
        </div>
    </section>

    ";
        } else {
            // line 724
            echo "    
        <div class=\"container-xxl\">
        <div class=\"nodata-sec\">
            <img class=\"no-data-content_img\" src=\"";
            // line 727
            echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
            echo "images/no-data-img.svg\" alt=\"no-data-content_img\">
            <h2 class=\"nodata-bar\">It’s empty here. Go ahead, add a section.</h2>
        </div>
        </div>
    
    ";
        }
        // line 733
        echo "

        <div class=\"backtop-bar\">
        <i class=\"bt-icon\"></i>
        <span>Back to top</span>
        </div>

        <div id=\"msg1\" class=\"alert alert-danger\" role=\"alert\" style=\"display: none\">
       
        </div>


<div class=\"sticky-footer\">
        <div class=\"container-xxl\">
        <div class=\"d-flex justify-content-between\">

            <ul class=\"mb-0\">
                <!-- <li  class=\"back-btn\">
                    <a href=\"";
        // line 751
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("taskList", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\" class=\"back-btn\">Back</a>
                </li> -->
            </ul>
            <ul class=\"mb-0\">
                ";
        // line 755
        if ((twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "is_published", [], "any", false, false, false, 755) == "1")) {
            // line 756
            echo "                <li class=\"mgr-30\">
                    Last published: ";
            // line 757
            echo twig_escape_filter($this->env, ($context["lastUpdate"] ?? null), "html", null, true);
            echo " ET
                </li>
                ";
        } else {
            // line 760
            echo "                <li class=\"mgr-30\">
                    Last saved: ";
            // line 761
            echo twig_escape_filter($this->env, ($context["lastUpdate"] ?? null), "html", null, true);
            echo " ET
                </li>
                ";
        }
        // line 763
        echo " 
                
                <li  class=\"back-btn\">
                    <a href=\"";
        // line 766
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("taskList", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\" class=\"back-btn\">Back</a>
                </li>
               
                <li  class=\"publish-btn\" >
                    ";
        // line 770
        if ((twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "is_active", [], "any", false, false, false, 770) == "1")) {
            // line 771
            echo "                    <a href=\"javascript:void(0)\"  class=\"publish-btn publish-pathway\" pathway-id=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["getPathwayData"] ?? null), "id", [], "any", false, false, false, 771), "html", null, true);
            echo "\"> Publish </a>
                    ";
        } elseif ((twig_get_attribute($this->env, $this->source,         // line 772
($context["getPathwayData"] ?? null), "is_active", [], "any", false, false, false, 772) == "2")) {
            // line 773
            echo "                    <button class=\"publish-btn noneactive\" disabled=\"disabled\">Publish</button>
                    ";
        }
        // line 774
        echo " 
                </li>
            </ul>
        </div>
        </div>
    </div>
<!-- Modal -->
<div class=\"modal fade\" id=\"backModal\" tabindex=\"-1\" aria-labelledby=\"backModal\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h3 id=\"exampleModalLabel\"><u>Change Background Image</u></h3>
        <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
      </div>
      <div class=\"modal-body\">
        <form id=\"backUpldFrm\" enctype=\"multipart/form-data\">
\t\t\t<input name=\"backfile\" type=\"file\" id=\"backfile\" />
\t\t\t<input type=\"button\" class=\"btn btn-primary\" id=\"uploadBack\" value=\"Upload\" />
\t\t</form>
\t\t<br /><br />
      </div>
      <!--<div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-secondary\" data-bs-dismiss=\"modal\">Close</button>
        <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
      </div> -->
    </div>
  </div>
</div>
 <!-- Modal End -->

 <div id=\"myModalLO\" class=\"modal\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
          <div class=\"modal-header\">
            <h1 class=\"modal-title fs-5\" id=\"exampleModalLabel\">Delete Learning Object?</h1>
            <button type=\"button\" id=\"closelBtnLO\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
          </div>
          <div class=\"modal-body\">
        <p>Are you sure you want to delete the learning item (LO) you’ve added? You’ll not be able to undo it.</p>
        </div>

        <div class=\"modal-footer\">
            <button id=\"cancelBtnLO\" class=\"cancelbtn\">Cancel</button>
            <button id=\"confirmBtnLO\" class=\"deletebtn\">Yes Delete</button>
            
          </div>
      </div>
    </div> 

</div>
    <footer>
        <div class=\"footersection\">
        <p>©2023 PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of Its subsidiaries or affiliates.</p>

        <ul>
            <li><a href=\"#\"> Help Center </a></li>
            <li><a href=\"#\"> Privacy Policy</a></li>
            <li><a href=\"#\"> Cookie Notice</a></li>
            <li><a href=\"#\"> Terms & Conditions</a></li>            
        </ul>
    </div>
    </footer>
    <!--script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js\"
        integrity=\"sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4\"
        crossorigin=\"anonymous\"></script-->
<!--/body>

</html-->

<span 
id = \"pathwayDetails\"
pathwayId = \"";
        // line 845
        echo twig_escape_filter($this->env, ($context["pathwayId"] ?? null), "html", null, true);
        echo "\"
changeSectionPositionUrl = \"";
        // line 846
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("changeSectionPosition"), "html", null, true);
        echo "\"
changeLOPositionUrl = \"";
        // line 847
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("changeLOPosition"), "html", null, true);
        echo "\"
deleteLO = \"";
        // line 848
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("deleteLO"), "html", null, true);
        echo "\"
deleteSubSectionUrl = \"";
        // line 849
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("deleteSubSection"), "html", null, true);
        echo "\"
publishPathwayUrl = \"";
        // line 850
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("publishPathway"), "html", null, true);
        echo "\"
saveMinimumComplitionUrl = \"";
        // line 851
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("saveMinimumComplition"), "html", null, true);
        echo "\"
saveSequenceStartUrl = \"";
        // line 852
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("saveSequenceStart"), "html", null, true);
        echo "\"
sequenceUnlockUrl = \"";
        // line 853
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("sequenceUnlock"), "html", null, true);
        echo "\"
addBranchUrl = \"";
        // line 854
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("addBranch"), "html", null, true);
        echo "\"
deletePathwayUrl = \"";
        // line 855
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("deletePathway"), "html", null, true);
        echo "\"
taskListUrl = \"";
        // line 856
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("taskList", ["lang" => ($context["lang"] ?? null)]), "html", null, true);
        echo "\"
uploadBackGroungImageUrl = \"";
        // line 857
        echo twig_escape_filter($this->env, $this->extensions['Slim\Views\TwigExtension']->pathFor("uploadBackGroungImage", ["id" => ($context["pathwayId"] ?? null)]), "html", null, true);
        echo "\"
>
</span>

<script src=\"";
        // line 861
        echo twig_escape_filter($this->env, twig_constant("HTTP_SERVER"), "html", null, true);
        echo "js/pagejs/pathway_details.js?v=";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_date_converter($this->env), "timestamp", [], "any", false, false, false, 861), "html", null, true);
        echo "\"></script>

";
    }

    public function getTemplateName()
    {
        return "Org_1/Home/pathway_details.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1907 => 861,  1900 => 857,  1896 => 856,  1892 => 855,  1888 => 854,  1884 => 853,  1880 => 852,  1876 => 851,  1872 => 850,  1868 => 849,  1864 => 848,  1860 => 847,  1856 => 846,  1852 => 845,  1779 => 774,  1775 => 773,  1773 => 772,  1768 => 771,  1766 => 770,  1759 => 766,  1754 => 763,  1748 => 761,  1745 => 760,  1739 => 757,  1736 => 756,  1734 => 755,  1727 => 751,  1707 => 733,  1698 => 727,  1693 => 724,  1684 => 717,  1677 => 715,  1669 => 709,  1666 => 708,  1659 => 706,  1652 => 701,  1636 => 691,  1632 => 690,  1627 => 688,  1623 => 687,  1609 => 675,  1606 => 674,  1595 => 672,  1590 => 671,  1587 => 670,  1583 => 668,  1581 => 667,  1576 => 664,  1572 => 662,  1569 => 661,  1564 => 658,  1558 => 657,  1546 => 655,  1543 => 654,  1539 => 653,  1530 => 651,  1526 => 649,  1522 => 647,  1519 => 646,  1517 => 645,  1512 => 643,  1508 => 642,  1504 => 641,  1500 => 639,  1496 => 637,  1494 => 636,  1491 => 635,  1485 => 633,  1483 => 632,  1480 => 631,  1474 => 629,  1472 => 628,  1469 => 627,  1463 => 625,  1461 => 624,  1458 => 623,  1452 => 621,  1450 => 620,  1441 => 613,  1435 => 610,  1427 => 608,  1421 => 605,  1414 => 604,  1412 => 603,  1408 => 601,  1402 => 598,  1394 => 596,  1388 => 593,  1380 => 591,  1378 => 590,  1369 => 585,  1366 => 584,  1361 => 583,  1359 => 582,  1351 => 578,  1349 => 577,  1344 => 574,  1340 => 572,  1331 => 566,  1327 => 565,  1322 => 563,  1318 => 562,  1304 => 550,  1301 => 549,  1290 => 547,  1285 => 546,  1283 => 545,  1280 => 544,  1276 => 542,  1274 => 541,  1269 => 538,  1265 => 536,  1262 => 535,  1257 => 532,  1251 => 531,  1239 => 529,  1236 => 528,  1232 => 527,  1225 => 525,  1221 => 523,  1217 => 521,  1214 => 520,  1212 => 519,  1207 => 517,  1203 => 516,  1199 => 515,  1195 => 513,  1191 => 511,  1189 => 510,  1186 => 509,  1180 => 507,  1178 => 506,  1175 => 505,  1169 => 503,  1167 => 502,  1164 => 501,  1158 => 499,  1155 => 498,  1149 => 496,  1147 => 495,  1139 => 489,  1132 => 485,  1125 => 484,  1118 => 480,  1111 => 479,  1109 => 478,  1105 => 476,  1098 => 472,  1091 => 471,  1084 => 467,  1077 => 466,  1075 => 465,  1071 => 463,  1069 => 462,  1064 => 459,  1057 => 455,  1053 => 454,  1049 => 453,  1045 => 452,  1041 => 450,  1039 => 449,  1034 => 447,  1030 => 446,  1020 => 441,  1009 => 433,  1003 => 429,  1000 => 428,  995 => 425,  980 => 423,  976 => 422,  969 => 420,  965 => 418,  962 => 417,  959 => 416,  952 => 412,  949 => 411,  934 => 409,  929 => 408,  925 => 406,  923 => 405,  917 => 404,  912 => 401,  909 => 400,  907 => 399,  903 => 397,  899 => 395,  896 => 394,  891 => 391,  885 => 390,  873 => 388,  870 => 387,  866 => 386,  859 => 384,  855 => 382,  851 => 380,  848 => 379,  846 => 378,  840 => 375,  836 => 374,  827 => 368,  818 => 361,  811 => 357,  804 => 356,  797 => 352,  790 => 351,  788 => 350,  784 => 348,  777 => 344,  770 => 343,  763 => 339,  756 => 338,  754 => 337,  747 => 332,  745 => 331,  740 => 329,  736 => 327,  733 => 326,  728 => 325,  725 => 324,  723 => 323,  714 => 318,  712 => 317,  702 => 309,  695 => 305,  691 => 304,  685 => 303,  682 => 302,  680 => 301,  653 => 277,  649 => 276,  641 => 273,  632 => 267,  625 => 263,  618 => 258,  615 => 257,  610 => 254,  595 => 252,  591 => 251,  584 => 249,  580 => 247,  577 => 246,  574 => 245,  567 => 241,  564 => 240,  549 => 238,  544 => 237,  540 => 235,  538 => 234,  532 => 233,  527 => 230,  524 => 229,  522 => 228,  518 => 226,  514 => 224,  512 => 223,  508 => 221,  493 => 219,  489 => 218,  484 => 216,  480 => 214,  477 => 213,  472 => 210,  466 => 209,  454 => 207,  451 => 206,  447 => 205,  440 => 203,  436 => 201,  432 => 199,  429 => 198,  427 => 197,  422 => 195,  418 => 194,  409 => 188,  397 => 178,  391 => 175,  384 => 174,  378 => 171,  371 => 170,  369 => 169,  365 => 167,  359 => 164,  352 => 163,  346 => 160,  339 => 159,  337 => 158,  330 => 154,  326 => 152,  323 => 151,  318 => 150,  316 => 149,  310 => 145,  308 => 144,  265 => 104,  257 => 99,  245 => 91,  240 => 88,  225 => 86,  221 => 85,  216 => 83,  212 => 81,  209 => 80,  206 => 79,  199 => 75,  196 => 74,  181 => 72,  176 => 71,  172 => 69,  170 => 68,  166 => 67,  161 => 64,  158 => 63,  156 => 62,  152 => 60,  148 => 59,  146 => 58,  141 => 56,  138 => 55,  136 => 54,  129 => 50,  127 => 49,  119 => 44,  115 => 43,  108 => 39,  104 => 38,  93 => 30,  82 => 22,  71 => 14,  66 => 11,  59 => 7,  55 => 5,  53 => 4,  50 => 3,  46 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'Org_1/Layout/app_home.twig' %}
{% block content %}
    <div class=\"row success-messages\" id=\"section_msg\">           
            {% if messages['success'] is defined %}
                <div class=\"col-sm-12 text-center\">
                    <div class=\"section_msg\">
                        <b>{{ messages['success']['0'] }}</b>
                    </div>
                </div>
            {% endif %}
    </div>

    <section class=\"pathway-details-sec\">
        <div class=\"bannertop-row\" style=\"background:url('../../upload/{{background}}')\">
            <div class=\"container-xxl\">
                <div class=\"pathwaybanner\">
                <div class=\"d-flex justify-content-between\">
                    <div class=\"backbtn-row wd80p\">

                        <div class=\"thumbnail-bgimg\">
                            <!-- <img src=\"...\" class=\"rounded\" alt=\"...\"> -->
                            <!-- <img src=\"{{getPathwayData.image}}\"> -->
                        </div>
                        
                        <div class=\"dis-inblock va-top headingsec\">
                            <div class=\"pathwayrow\">
                            <ul>
                                <li>

                                    <label class=\"pathwaygeneral-text\">Pathway : {{getPathwayData.pathway_type_name}}</label>

                                    
                                </li>
                                <li>PwC</li>
                            </ul>
                        </div>
                            
                            <h1 class=\"serifb-text\">{{getPathwayData.title}}</h1>
                            <div class='comment more'>{{getPathwayData.description | raw}}</div>

                            <div class=\"pathway-subrow\">
                            <ul class=\"ps-0 pathway-subrow mb-4\">
                                <li>{{getPathwayData.duration}}</li>
                                <li>{{getPathwayData.proficency_level}}</li>
                            </ul>
                            </div>


                            <a href=\"{{path_for('secFormRender',{lang: lang, formName:'pwc-section-details
', id: pathwayId})}}\" class=\"secondary-btn d-inline mgl-o\"> Add section </a>
                            


                            {% if(getPathwayData.is_active == '1') %}
                            
                                <a href=\"javascript:void(0)\" target=\"_blank\" class=\"primary-btn d-inline\" id=\"showPreview\" pathway-id=\"{{getPathwayData.id}}\"> Preview </a>

                            {% elseif(getPathwayData.is_active == '2') %}
                               <button class=\"primary-btn d-inline noneactive\" disabled=\"disabled\">Preview</button>
                            {%endif%} 
                        </li>
                {% if getPathwayData.pathway_type == '2' %}
                {% if getSectionDetals|length > 0 %}
                <div class=\"learnercompletes-row detailoption-row\">
                    <p class=\"font-bold\">To complete this pathway, the learner must complete <span class=\"mandatory_label\">*</span></p>
                    <ul>
                        <li><select class=\"form-select numberselcet min-complition\" pathway-id=\"{{getPathwayData.id}}\" mode=\"pathway\" aria-label=\"Default select example\">
                            {% if getPathwayData.completion_min  == '' %}
                                <option>0</option>
                            {% endif %}
                            {% for dataKey, data in getSectionDetals %}
                            <option value=\"{{dataKey + 1}}\" {% if dataKey + 1 == getPathwayData.completion_min %} selected {% endif %}>{{dataKey + 1}}</option>
                            {% endfor %}
                          </select></li>
                        <li>sections out of {{getSectionDetals|length}}</li>
                    </ul>
                </div>
                {% endif %}
            {% elseif getPathwayData.pathway_type == '4' %}
                {% if getSectionDetals|length > 0 %}
                    <div class=\"mb-4 smm-row detailoption-row wid-full\">
                        <label for=\"\">Learner starts below sequence from section <span class=\"mandatory_label\">*</span></label>
                        <select class=\"form-select add-sequence\" pathway-id=\"{{getPathwayData.id}}\" mode=\"pathway\" aria-label=\"Default select example\">
                            <option selected>Open this select menu</option>
                            {% for dataKey, data in getSectionDetals %}
                                <option value=\"{{data.secid}}\" {% if data.secid == getPathwayData.sequence_start %} selected {% endif  %}>{{data.title}} </option>
                            {% endfor %}
                        </select>
                    </div>
                {% endif %}
            {% endif %} 
                        </div>

                    </div>

                    <div class=\"\">
                        <div class=\"dis-inblock dropdown\">
                            <a href=\"#\" class=\"circle-btn\" role=\"button\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\"> 
                                <img src=\"{{constant('HTTP_SERVER')}}images/setting-icon.svg\" alt=\"Setting_icon\">
                             </a>

                            <ul class=\"dropdown-menu\" style=\"\">
                                <li><a class=\"dropdown-item\" href=\"#\" data-bs-toggle=\"modal\" data-bs-target=\"#backModal\">Change pathway background</a></li>
                                <li><a class=\"dropdown-item deletePathway\"  pathway-id=\"{{getPathwayData.id}}\" href=\"#\">Delete Pathway</a></li>
\t\t\t\t\t\t\t\t
                    
                            </ul>

                            <div id=\"myModal\" class=\"modal\">
                                <div class=\"modal-dialog\">
                                <div class=\"modal-content\">
                                  <div class=\"modal-header\">
                                    <h1 class=\"modal-title fs-5\" id=\"exampleModalLabel\">Delete pathway</h1>
                                    <button type=\"button\" id=\"closelBtn\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
                                  </div>
                                  <div class=\"modal-body\">
                                <p>Are you sure you want to delete all the information you’ve added? You’ll not be able to undo it.</p>
                                </div>

                                <div class=\"modal-footer\">
                                    <button id=\"cancelBtn\" class=\"cancelbtn\">Cancel</button>
                                    <button id=\"confirmBtn\" class=\"deletebtn\">Yes Delete</button>
                                    
                                  </div>
                              </div>
                            </div> 

                        </div>


                        </div>
                    </div>
                </div>
            </div>

          
            </div>
        </div>


        
    </section>

    {% if getSectionDetals|length > 0 %}
    <section class=\"grabg\">
        <div class=\"container-xxl\">
            <div class=\"accordion mg_t55 mg-l50\" id=\"accordionPanelsStayOpenExample\">

                {% set sno = 0 %}
                {% for dataKey, data in getSectionDetals %}
                {% set sno = sno+1 %}
                <div class=\"accordion-item\">
                    <div class=\"accordion-header\" id=\"headingOne\">
                        <div class=\"accordion-button custom-acco-bar\" id=\"validation_{{data.valid_id}}\">

                            <span class=\"sidebtn-bar noafter topsection-bar\">
                                <ul>
                                    {% if(getSectionDetals[sno-2].id=='') %}
                                    <li class=\"move-btn noneactive\" data-current=\"{{data.id}}\" data-node=\"{{getSectionDetals[sno-2].id}}\" disabled='disabled'>
                                    <img src=\"{{constant('HTTP_SERVER')}}images/moveup-icon.svg\" alt=\"up-arrow-disable\">
                                    </li>
                                    {% else %}
                                    <li class=\"upButton\" data-current=\"{{data.id}}\" data-node=\"{{getSectionDetals[sno-2].id}}\">
                                        <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"{{constant('HTTP_SERVER')}}images/moveup-icon.svg\" alt=\"up-arrow\"></a>
                                    </li>
                                    {%endif%}
                                    
                                        
                                    {% if(getSectionDetals[sno].id=='') %}
                                    <li class=\"move-btn noneactive\" data-current=\"{{data.id}}\"  data-node=\"{{getSectionDetals[sno].id}}\" disabled='disabled'>
                                       <img src=\"{{constant('HTTP_SERVER')}}images/movedown-icon.svg\" alt=\"down-arrow-disable\">
                                    </li>
                                    {% else %}
                                    <li class=\"downButton\" data-current=\"{{data.id}}\"  data-node=\"{{getSectionDetals[sno].id}}\" >
                                        <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"{{constant('HTTP_SERVER')}}images/movedown-icon.svg\" alt=\"down-arrow\"></a>
                                    </li>
                                    {%endif%}
                                    
                                        
                                </ul>
                            </span>


                            <div class=\"sec-content\">
                                <div class=\"pathwayrow\">
                                    <ul>
                                        <li>
                                            <label class=\"pathwaygeneral-text\">Section: {{data.type_name}}</label>
                                        </li>
                                    </ul>
                                </div>

                                
                                <h2>{{data.title}}</h2>
                                {{data.description | raw}}

                                {% if getPathwayData.pathway_type == '4' %}
                                    {% if data.secid == getPathwayData.sequence_start %}
                                        <p>First in sequence, section unlocked for learner.</p>
                                    {% else %}
                                        <div class=\"mb-4 smm-row\">
                                            <label for=\"\">Unlock this section when Learner completes <span class=\"mandatory_label\">*</span></label>
                                            <select class=\"form-select unlock-this\" pathway-id=\"{{getPathwayData.id}}\" section-id=\"{{data.secid}}\" mode=\"section\" aria-label=\"Default select example\">
                                                <option value=\"\">Open this select menu</option>
                                                {% for datasKey, datas in getSectionDetals %}
                                                    {% if datas.secid != data.secid %}
                                                        <option value=\"{{datas.secid}}\" {% if datas.secid == data.sequence_num %} selected {% endif %}>{{datas.title}}</option>
                                                    {% endif  %}
                                                {% endfor %}
                                            </select>
                                        </div>
                                    {% endif %}
                                {% elseif getPathwayData.pathway_type ==  \"1\" %}
                                    <div class=\"mb-4 smm-row\">
                                        <label for=\"\">Make this section part of a branch? <span class=\"mandatory_label\">*</span></label>
                                        <select class=\"form-select add-branch\" section-id=\"{{data.secid}}\">
                                            <option>Select branch</option>
                                            {% for databKey, datab in getBranch %}
                                            <option value=\"{{datab.id}}\"  {% if datab.id == data.section_branch %} selected {% endif %}>{{datab.value_of_data}}</option>
                                            {% endfor %}
                                        </select>
                                    </div>
                                {% elseif getPathwayData.pathway_type ==  \"3\" %}
                                    
                                {% endif %}


                                {% if data.type_id == 2 %}
                                    {% if data.subSection|length > 0 %}
                                        <div class=\"learnercompletes-row\">
                                            <p class=\"font-bold\">To complete this section, the learner must complete <span class=\"mandatory_label\">*</span></p>
                                            <ul>
                                                <li><select class=\"form-select numberselcet min-complition-session\" pathway-id=\"{{getPathwayData.id}}\" session-id=\"{{data.id}}\" mode=\"session\" aria-label=\"Default select example\">
                                                    {% if data.completion_min  == '' %}
                                                        <option>0</option>
                                                    {% endif %}
                                                    {% for subSecDataKey, subSecData in data.subSection %}
                                                    <option value=\"{{subSecDataKey + 1}}\" {% if subSecDataKey + 1 == data.completion_min %} selected {% endif %}>{{subSecDataKey + 1}}</option>
                                                    {% endfor %}
                                                  </select></li>
                                                <li>subsections/learning items out of {{data.subSection|length}}</li>
                                            </ul>
                                        </div>
                                    {% endif %}
                                {% elseif data.type_id == 4 %}
                                    {% if data.subSection|length > 0 %}
                                        <div class=\"mb-4 smm-row\">
                                            <label for=\"\">Learner starts below sequence from learning item <span class=\"mandatory_label\">*</span></label>
                                            <select class=\"form-select add-sequence-sec\" pathway-id=\"{{getPathwayData.id}}\" section-id=\"{{data.secid}}\" mode=\"section\" aria-label=\"Default select example\">
                                                <option selected>Open this select menu</option>
                                                {% for subSecDataKey, subSecData in data.subSection %}
                                                    <option value=\"{{subSecData.subsecid}}\" {% if subSecData.subsecid == data.sequence_start %} selected {% endif  %}>{{subSecData.title}} </option>
                                                {% endfor %}
                                            </select>
                                        </div>
                                    {% endif %}
                                {% endif %}

                                <div class=\"d-flex justify-content-between\">

                                    <ul class=\"mb-0\">
                                        <li>
                                            <a href=\"{{path_for('subSecFormRender',{lang: lang, formName:'pwc-sub-section-details', id: pathwayId, sectionId:data.id })}}\" class=\"secondary-btn\">
                                                Add subsection </a>
                                        </li>
                                        <li>
                                            <a href=\"{{path_for('subSecFormRender',{lang: lang, formName:'pwc-external-learning-object', id: pathwayId, sectionId:data.id })}}\" class=\"secondary-btn\">
                                                Add learning object </a>
                                        </li>
                                    </ul>
                                    <ul class=\"mb-0\">
                                        <li>
                                            <a href=\"{{path_for('editDraft',{id: data.mongo_id,form_type: 'pwc-section-details', lang: lang})}}\" class=\"circle-btn\"> <img src=\"{{constant('HTTP_SERVER')}}images/edit-icon.svg\" alt=\"edit-section\"> </a>
                                        </li>
                                       
                                        <li class=\"delete_subsec\" id=\"{{data.id}}\" data-title=\"section\">
                                           <a href=\"javascript:void(0)\" class=\"circle-btn\"> <img src=\"{{constant('HTTP_SERVER')}}images/delete-icon.svg\" alt=\"delete-section\"></a>
                                        </li>

                                         <div id=\"myModalSection\" class=\"modal\">
                                            <div class=\"modal-dialog\">
                                                <div class=\"modal-content\">
                                                  <div class=\"modal-header\">
                                                    <h1 class=\"modal-title fs-5\" id=\"exampleModalLabel\"><p id=\"sechead\"></p></h1>
                                                    <button type=\"button\" id=\"closelBtnsection\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
                                                  </div>
                                                  <div class=\"modal-body\">
                                                <p id=\"secmsg\"></p>
                                                </div>

                                                <div class=\"modal-footer\">
                                                    <button id=\"cancelBtnsetion\" class=\"cancelbtn\">Cancel</button>
                                                    <button id=\"confirmBtnSection\" class=\"deletebtn\">Yes Delete</button>
                                                    
                                                  </div>
                                              </div>
                                            </div> 

                                        </div>
                                        
                                        {% if (data.subSection|length > 0 or data.learningObject|length > 0) %}
                                        <li>
                                            <a class=\"circle-btn\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapseOne{{sno}}\" aria-expanded=\"true\" aria-controls=\"collapseOne{{sno}}\">
                                                <img class=\"uparrow-icon\" src=\"{{constant('HTTP_SERVER')}}images/uparrow-icon.svg\" alt=\"collapse-icon\">
                                                <img class=\"collapse-icon\" src=\"{{constant('HTTP_SERVER')}}images/collapse-icon.svg\" alt=\"collapse-icon\">
                                            </a>
                                        </li>
                                        {%endif%}

                                    </ul>
                                </div>

                            </div>

                        </div>
                    </div>
                    {% if (data.subSection|length > 0 or data.learningObject|length > 0) %}
                    <div id=\"collapseOne{{sno}}\" class=\"accordion-collapse collapse show\" aria-labelledby=\"headingOne\"
                        data-bs-parent=\"#accordionExample\">
                        <div class=\"accordion-body\">

                            <div class=\"accordion\" id=\"accordionPanelsStayOpenExampleI\">
                                {% if data.subSection|length > 0 %}
                                {% set snoSubSec = 0 %}
                                {% for subSecDataKey, subSecData in data.subSection %}
                                {% set snoSubSec = snoSubSec+1 %}
                                <div class=\"accordion-item\">
                                    <div class=\"accordion-header\" id=\"subsection-heading-I\">
                                        <div class=\"accordion-button custom-acco-bar\"  id=\"validation_{{subSecData.valid_id}}\">

                                            {% if subSecData.category == '1' %}
                                                <!-- section -->


                                                <div class=\"sidebtn-bar\">
                                                    <ul>
                                                        {% if(data.subSection[snoSubSec-2].id=='') %}
                                                         <li class=\"move-btn noneactive\" data-current=\"{{subSecData.id}}\" data-node=\"{{data.subSection[snoSubSec-2].id}}\" disabled='disabled'>
                                                            <img src=\"{{constant('HTTP_SERVER')}}images/moveup-icon.svg\"
                                                                    alt=\"up-arrow-disable\">
                                                        </li>
                                                        {% else %}
                                                         <li class=\"downButton\" data-current=\"{{subSecData.id}}\" data-node=\"{{data.subSection[snoSubSec-2].id}}\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"{{constant('HTTP_SERVER')}}images/moveup-icon.svg\"
                                                                    alt=\"up-arrow\"></a>
                                                        </li>
                                                        {%endif%}
                                                       

                                                       {% if(data.subSection[snoSubSec].id=='') %}
                                                       <li class=\"move-btn noneactive\" data-current=\"{{subSecData.id}}\" data-node=\"{{data.subSection[snoSubSec].id}}\" disabled='disabled'>
                                                            <img src=\"{{constant('HTTP_SERVER')}}images/movedown-icon.svg\"
                                                                    alt=\"down-arrow-disable\">
                                                        </li>
                                                       {% else %}
                                                       <li class=\"downButton\" data-current=\"{{subSecData.id}}\" data-node=\"{{data.subSection[snoSubSec].id}}\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"{{constant('HTTP_SERVER')}}images/movedown-icon.svg\"
                                                                    alt=\"down-arrow\"></a>
                                                        </li>
                                                       {%endif%}
                                                        
                                                    </ul>
                                                </div>

                                                <div class=\"pathwayrow\">
                                                    <ul>
                                                        <li>
                                                            <label class=\"pathwaygeneral-text\">Subsection: {{subSecData.type_name}}</label>
                                                        </li>
                                                    </ul>
                                                </div>

                                                
                                                <h2>{{subSecData.title}}</h2>
                                                {{subSecData.description | raw}}


                                                {% if data.type_id == 4 %}
                                                    {% if subSecData.subsecid == data.sequence_start %}
                                                        <p>First in sequence, learning item unlocked for learner.</p>
                                                    {% else %}
                                                        <div class=\"mb-4 smm-row\">
                                                            <label for=\"\">Unlock this subsection when Learner completes <span class=\"mandatory_label\">*</span></label>
                                                            <select class=\"form-select unlock-this\" pathway-id=\"{{getPathwayData.id}}\" section-id=\"{{subSecData.subsecid}}\" mode=\"section\" aria-label=\"Default select example\">
                                                                <option value=\"\">Open this select menu</option>
                                                                {% for subSecDataKeys, subSecDatas in data.subSection %}
                                                                    {% if subSecDatas.subsecid != subSecData.subsecid %}
                                                                        <option value=\"{{subSecDatas.subsecid}}\" {% if subSecDatas.subsecid == subSecData.sequence_num %} selected {% endif %}>{{subSecDatas.title}}</option>
                                                                    {% endif  %}
                                                                {% endfor %}
                                                            </select>
                                                        </div>
                                                    {% endif %}
                                                {% elseif data.type_id == 3 %}
                                                    
                                                {% endif %}


                                                {% if subSecData.type_id == 2 %}
                                                    {% if subSecData.learningObject|length > 0 %}
                                                        <div class=\"learnercompletes-row\">
                                                            <p class=\"font-bold\">To complete this subsection, the learner must complete <span class=\"mandatory_label\">*</span></p>
                                                            <ul>
                                                                <li><select class=\"form-select numberselcet min-complition-session\" pathway-id=\"{{getPathwayData.id}}\" session-id=\"{{subSecData.id}}\" mode=\"session\" aria-label=\"Default select example\">
                                                                    {% if subSecData.completion_min == '' %}
                                                                        <option>0</option>
                                                                    {% endif %}
                                                                    {% for learningObjDataKey, learningObjData in subSecData.learningObject %}
                                                                    <option value=\"{{learningObjDataKey + 1}}\" {% if learningObjDataKey + 1 == subSecData.completion_min %} selected {% endif %}>{{learningObjDataKey + 1}}</option>
                                                                    {% endfor %}
                                                                  </select></li>
                                                                <li>learning items out of {{subSecData.learningObject|length}}</li>
                                                            </ul>
                                                        </div>
                                                    {% endif %}
                                                {% elseif subSecData.type_id == 4 %}
                                                    {% if subSecData.learningObject|length > 0 %}
                                                        <div class=\"mb-4 smm-row\">
                                                            <label for=\"\">Learner starts below sequence from learning item <span class=\"mandatory_label\">*</span></label>
                                                            <select class=\"form-select add-sequence-sec\" pathway-id=\"{{getPathwayData.id}}\" section-id=\"{{subSecData.subsecid}}\" mode=\"section\" aria-label=\"Default select example\">
                                                                <option selected>Open this select menu</option>
                                                                {% for learningObjDataKey, learningObjData in subSecData.learningObject %}
                                                                    <option value=\"{{learningObjData.lo_id}}\" {% if learningObjData.lo_id == subSecData.sequence_start %} selected {% endif  %}>{{learningObjData.title}}</option>
                                                                {% endfor %}
                                                            </select>
                                                        </div>
                                                    {% endif %}
                                                {% endif %}

                                                <div class=\"d-flex justify-content-between\">
                                                    <ul class=\"mb-0\">
                                                        <li>
                                                            <a href=\"{{path_for('subSecFormRender',{lang: lang, formName:'pwc-external-learning-object', id: pathwayId, sectionId:subSecData.id })}}\" class=\"secondary-btn\">
                                                                Add learning object  </a>
                                                        </li>
                                                    </ul>
                                                   
                                                    <ul class=\"mb-0\">
                                                
                                                            <li>
                                                                <a href=\"{{path_for('editDraft',{id: subSecData.mongo_id,form_type: 'pwc-sub-section-details', lang: lang})}}\" class=\"circle-btn\"> <img src=\"{{constant('HTTP_SERVER')}}images/edit-icon.svg\"
                                                                        alt=\"edit-icon\"> </a>
                                                            </li>
                                                        
                                                       
                                                        <li class=\"delete_subsec\" id=\"{{subSecData.id}}\" data-title=\"subsection\">
                                                           <a href=\"javascript:void(0)\" class=\"circle-btn\"> <img src=\"{{constant('HTTP_SERVER')}}images/delete-icon.svg\" alt=\"delete-icon\"> </a>
                                                        </li>
                                                        {% if subSecData.learningObject|length > 0 %}
                                                        <li>
                                                            <a class=\"circle-btn\"  type=\"button\"
                                                            data-bs-toggle=\"collapse\" data-bs-target=\"#subsection{{snoSubSec}}\"
                                                            aria-expanded=\"true\" aria-controls=\"subsection{{snoSubSec}}\"> 
                                                            <img class=\"uparrow-icon\" src=\"{{constant('HTTP_SERVER')}}images/uparrow-icon.svg\" alt=\"uparrow-icon\">
                                                            <img class=\"collapse-icon\" src=\"{{constant('HTTP_SERVER')}}images/collapse-icon.svg\" alt=\"collapse-icon\">
                                                                 </a>
                                                        </li>
                                                        {%endif%}
                                                    </ul>
                                                </div>

                                            {% elseif subSecData.category == '2'  %}
                                                <div class=\"sidebtn-bar\">
                                                    <ul>
                                                        {% if(data.subSection[snoSubSec-2].id=='') %}
                                                         <li class=\"move-btn noneactive\" data-current=\"{{subSecData.id}}\" data-node=\"{{data.subSection[snoSubSec-2].id}}\" disabled='disabled'>
                                                            <img src=\"{{constant('HTTP_SERVER')}}images/moveup-icon.svg\"
                                                                    alt=\"uparrow-icon-disabled\">
                                                        </li>
                                                        {% else %}
                                                         <li class=\"downButton\" data-current=\"{{subSecData.id}}\" data-node=\"{{data.subSection[snoSubSec-2].id}}\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"{{constant('HTTP_SERVER')}}images/moveup-icon.svg\"
                                                                    alt=\"uparrow-icon\"></a>
                                                        </li>
                                                        {%endif%}
                                                       

                                                       {% if(data.subSection[snoSubSec].id=='') %}
                                                       <li class=\"move-btn noneactive\" data-current=\"{{subSecData.id}}\" data-node=\"{{data.subSection[snoSubSec].id}}\" disabled='disabled'>
                                                            <img src=\"{{constant('HTTP_SERVER')}}images/movedown-icon.svg\"
                                                                    alt=\"down-arrow-disable\">
                                                        </li>
                                                       {% else %}
                                                       <li class=\"downButton\" data-current=\"{{subSecData.id}}\" data-node=\"{{data.subSection[snoSubSec].id}}\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img src=\"{{constant('HTTP_SERVER')}}images/movedown-icon.svg\"
                                                                    alt=\"down-arrow\"></a>
                                                        </li>
                                                       {%endif%}
                                                        
                                                    </ul>
                                                </div>

                                                <div class=\"pathwayrow\">
                                                    <ul>
                                                        {% if subSecData.lo_type != '' %}
                                                            <li><b>{{subSecData.lo_type}}</b></li>
                                                        {% endif %}
                                                        {% if subSecData.provider != '' %}
                                                            <li>{{subSecData.provider}}</li>
                                                        {% endif %}

                                                        {% if subSecData.level != '' %}
                                                            <li>{{subSecData.level}}</li>
                                                        {% endif %}

                                                        {% if subSecData.duration != '' %}
                                                            <li>{{subSecData.duration}}</li>
                                                        {% endif %}

                                                        {% if subSecData.is_active == 1 %}
                                                            <li>Active</li>
                                                        {% endif %}
                                                    </ul>
                                                </div>
                                                <div class=\"lo_thumbnails\"><img src=\"{{subSecData.image}}\"></div>
                                                <h2>{{subSecData.title}}</h2>
                                                {{subSecData.description | raw}}

                                                    {% if data.type_id == 4 %}
                                                        {% if subSecData.subsecid == data.sequence_start %}
                                                            <p>First in sequence, learning item unlocked for learner.</p>
                                                        {% else %}
                                                            <div class=\"mb-4 smm-row\">
                                                                <label for=\"\">Unlock this learning item when Learner completes <span class=\"mandatory_label\">*</span></label>
                                                                <select class=\"form-select unlock-this\" pathway-id=\"{{getPathwayData.id}}\" section-id=\"{{subSecData.subsecid}}\" mode=\"section\" aria-label=\"Default select example\">
                                                                    <option value=\"\">Open this select menu</option>
                                                                    {% for subSecDataKeys, subSecDatas in data.subSection %}
                                                                        {% if subSecDatas.subsecid != subSecData.subsecid %}
                                                                            <option value=\"{{subSecDatas.subsecid}}\" {% if subSecDatas.subsecid == subSecData.sequence_num %} selected {% endif %}>{{subSecDatas.title}}</option>
                                                                        {% endif  %}
                                                                    {% endfor %}
                                                                </select>
                                                            </div>
                                                        {% endif %}
                                                    {% elseif data.type_id == 3 %}
                                                        
                                                    {% endif %}

                                                    <div class=\"pathway-subrow\">
                                                        <ul class=\"ps-0 pathway-subrow mb-4\">
                                                            {% if subSecData.is_mandatory == 1 %}
                                                                <li>Mandatory</li>
                                                            {% endif %}

                                                            {% if subSecData.customFilter|length > 0 %}
                                                                {% for cusFilKey, cusFilData in subSecData.customFilter %}
                                                                    <li>{{cusFilData.filter_key}}: {{cusFilData.filter_value}}</li>
                                                                {% endfor %}
                                                            {% endif %}

                                                        </ul>
                                                    </div>


                                                <div class=\"d-flex justify-content-between\">

                                                    <ul class=\"mb-0\">

                                                    </ul>
                                                    <ul class=\"mb-0\">
                                                        <li>
                                                            <a href=\"{{path_for('editDraft',{id: subSecData.mongo_id,form_type: 'pwc-external-learning-object', lang: lang})}}\" class=\"circle-btn\"> <img
                                                                    src=\"{{constant('HTTP_SERVER')}}images/edit-icon.svg\" alt=\"edit-icon\"> </a>
                                                        </li>
                                                        <li  class=\"delete_lo\" id=\"{{subSecData.id}}\" >
                                                             <a href=\"javascript:void(0)\" class=\"circle-btn\"><img src=\"{{constant('HTTP_SERVER')}}images/delete-icon.svg\" alt=\"delete-icon\"> </a>
                                                        </li>

                                                    </ul>
                                                </div>
                                            {% else %}
                                                <!-- nothing -->
                                            {% endif  %}

                                        </div>
                                    </div>
                                    {% if subSecData.learningObject|length > 0 %}
                                    <div id=\"subsection{{snoSubSec}}\" class=\"accordion-collapse collapse show\"
                                        aria-labelledby=\"subsection-heading-I\" data-bs-parent=\"#accordionExampleI\">
                                        <div class=\"accordion-body losection\">

                                            {% set snoSubSecLO = 0 %}
                                            {% for learningObjDataKey, learningObjData in subSecData.learningObject %}
                                            {% set snoSubSecLO = snoSubSecLO+1 %}
                                            <div class=\"custom-acco-bar lo-row position-relative\" id=\"validation_{{learningObjData.valid_id}}\">


                                                <span class=\"sidebtn-bar\">
                                                    <ul>
                                                        {% if(subSecData.learningObject[snoSubSecLO-2].id=='') %}
                                                        <li class=\"move-btn noneactive\" data-current=\"{{learningObjData.id}}\" data-node=\"{{subSecData.learningObject[snoSubSecLO-2].id}}\">
                                                           <img
                                                                    src=\"{{constant('HTTP_SERVER')}}images/moveup-icon.svg\" alt=\"up-arrow-disable\">
                                                        </li>
                                                        {% else %}
                                                        <li class=\"upButtonLO\" data-current=\"{{learningObjData.id}}\" data-node=\"{{subSecData.learningObject[snoSubSecLO-2].id}}\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img
                                                                    src=\"{{constant('HTTP_SERVER')}}images/moveup-icon.svg\" alt=\"uparrow-icon\"></a>
                                                        </li>
                                                        {%endif%}
                                                        

                                                        {% if(subSecData.learningObject[snoSubSecLO].id=='') %}
                                                        <li class=\"move-btn noneactive\" data-current=\"{{learningObjData.id}}\" data-node=\"{{subSecData.learningObject[snoSubSecLO].id}}\">
                                                        <img src=\"{{constant('HTTP_SERVER')}}images/movedown-icon.svg\" alt=\"down-arrow-disable\">
                                                        </li>
                                                        {% else %}
                                                        <li class=\"downButtonLO\" data-current=\"{{learningObjData.id}}\" data-node=\"{{subSecData.learningObject[snoSubSecLO].id}}\">
                                                            <a href=\"javascript:void(0)\" class=\"move-btn\"><img
                                                                    src=\"{{constant('HTTP_SERVER')}}images/movedown-icon.svg\" alt=\"down-arrow\"></a>
                                                        </li>
                                                        {%endif%}
                                                        
                                                    </ul>
                                                </span>


                                                <div class=\"pathwayrow\">
                                                    <ul>
                                                        {% if learningObjData.lo_type != '' %}
                                                            <li><b>{{learningObjData.lo_type}}</b></li>
                                                        {% endif %}

                                                        {% if learningObjData.provider != '' %}
                                                            <li>{{learningObjData.provider}}</li>
                                                        {% endif %}

                                                        {% if learningObjData.level != '' %}
                                                            <li>{{learningObjData.level}}</li>
                                                        {% endif %}

                                                        {% if learningObjData.duration != '' %}
                                                            <li>{{learningObjData.duration}}</li>
                                                        {% endif %}

                                                        {% if learningObjData.is_active == 1 %}
                                                            <li>Active</li>
                                                        {% endif %}
                                                    </ul>
                                                </div>
                                                <div class=\"lo_thumbnails\"><img src=\"{{learningObjData.image}}\"></div>
                                                <h2>{{learningObjData.title}}</h2>
                                                {{learningObjData.description | raw}}

                                                {% if subSecData.type_id == 4 %}
                                                    {% if learningObjData.lo_id == subSecData.sequence_start %}
                                                        <p>First in sequence, learning item unlocked for learner.</p>
                                                    {% else %}
                                                        <div class=\"mb-4 smm-row\">
                                                            <label for=\"\">Unlock this learning item when Learner completes <span class=\"mandatory_label\">*</span></label>
                                                            <select class=\"form-select unlock-this\" pathway-id=\"{{getPathwayData.id}}\" section-id=\"{{subSecData.subsecid}}\" learning-object=\"{{learningObjData.lo_id}}\" mode=\"lo\" aria-label=\"Default select example\">
                                                                <option value=\"\">Open this select menu</option>
                                                                {% for learningObjDataKeys, learningObjDatas in subSecData.learningObject %}
                                                                    {% if learningObjDatas.lo_id != learningObjData.lo_id %}
                                                                        <option value=\"{{learningObjDatas.lo_id}}\" {% if learningObjDatas.lo_id == learningObjData.sequence_num %} selected {% endif %}>{{learningObjDatas.title}}</option>
                                                                    {% endif  %}
                                                                {% endfor %}
                                                            </select>
                                                        </div>
                                                    {% endif %}
                                                {% elseif subSecData.type_id == 3 %}
                                                    
                                                {% endif %}

                                                    <div class=\"pathway-subrow\">
                                                        <ul class=\"ps-0 pathway-subrow mb-4\">
                                                            {% if learningObjData.is_mandatory == 1 %}
                                                                <li>Mandatory</li>
                                                            {% endif %}
                                                            {% if learningObjData.customFilter|length > 0 %}
                                                                {% for cusFilKey, cusFilData in learningObjData.customFilter %}
                                                                    <li>{{cusFilData.filter_key}}: {{cusFilData.filter_value}}</li>
                                                                {% endfor %}
                                                            {% endif %}
                                                        </ul>
                                                    </div>



                                                <div class=\"d-flex justify-content-between\">

                                                    <ul class=\"mb-0\">

                                                    </ul>
                                                    <ul class=\"mb-0\">
                                                        <li>
                                                            <a href=\"{{path_for('editDraft',{id: learningObjData.mongo_id,form_type: 'pwc-external-learning-object', lang: lang})}}\" class=\"circle-btn\"> <img
                                                                    src=\"{{constant('HTTP_SERVER')}}images/edit-icon.svg\" alt=\"edit-icon\"> </a>
                                                        </li>
                                                        <li class=\"delete_lo\" id=\"{{learningObjData.id}}\" >
                                                            <a href=\"javascript:void(0)\" class=\"circle-btn\"> <img src=\"{{constant('HTTP_SERVER')}}images/delete-icon.svg\" alt=\"delete-icon\"> </a>
                                                        </li>

                                                        

                                                    </ul>
                                                </div>

                                            </div>
                                            {% endfor %}

                                            
                                        </div>
                                    </div>
                                    {% endif %}
                                </div>
                                {% endfor %}
                                {% endif %}
                                
                            </div>

                        </div>
                    </div>
                    {% endif %}
                </div>
                {% endfor %}


            </div>
        </div>
    </section>

    {% else %}
    
        <div class=\"container-xxl\">
        <div class=\"nodata-sec\">
            <img class=\"no-data-content_img\" src=\"{{constant('HTTP_SERVER')}}images/no-data-img.svg\" alt=\"no-data-content_img\">
            <h2 class=\"nodata-bar\">It’s empty here. Go ahead, add a section.</h2>
        </div>
        </div>
    
    {% endif %}


        <div class=\"backtop-bar\">
        <i class=\"bt-icon\"></i>
        <span>Back to top</span>
        </div>

        <div id=\"msg1\" class=\"alert alert-danger\" role=\"alert\" style=\"display: none\">
       
        </div>


<div class=\"sticky-footer\">
        <div class=\"container-xxl\">
        <div class=\"d-flex justify-content-between\">

            <ul class=\"mb-0\">
                <!-- <li  class=\"back-btn\">
                    <a href=\"{{path_for('taskList', {lang: lang})}}\" class=\"back-btn\">Back</a>
                </li> -->
            </ul>
            <ul class=\"mb-0\">
                {% if(getPathwayData.is_published == '1') %}
                <li class=\"mgr-30\">
                    Last published: {{lastUpdate}} ET
                </li>
                {% else %}
                <li class=\"mgr-30\">
                    Last saved: {{lastUpdate}} ET
                </li>
                {%endif%} 
                
                <li  class=\"back-btn\">
                    <a href=\"{{path_for('taskList', {lang: lang})}}\" class=\"back-btn\">Back</a>
                </li>
               
                <li  class=\"publish-btn\" >
                    {% if(getPathwayData.is_active == '1') %}
                    <a href=\"javascript:void(0)\"  class=\"publish-btn publish-pathway\" pathway-id=\"{{getPathwayData.id}}\"> Publish </a>
                    {% elseif(getPathwayData.is_active == '2') %}
                    <button class=\"publish-btn noneactive\" disabled=\"disabled\">Publish</button>
                    {%endif%} 
                </li>
            </ul>
        </div>
        </div>
    </div>
<!-- Modal -->
<div class=\"modal fade\" id=\"backModal\" tabindex=\"-1\" aria-labelledby=\"backModal\" aria-hidden=\"true\">
  <div class=\"modal-dialog\">
    <div class=\"modal-content\">
      <div class=\"modal-header\">
        <h3 id=\"exampleModalLabel\"><u>Change Background Image</u></h3>
        <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
      </div>
      <div class=\"modal-body\">
        <form id=\"backUpldFrm\" enctype=\"multipart/form-data\">
\t\t\t<input name=\"backfile\" type=\"file\" id=\"backfile\" />
\t\t\t<input type=\"button\" class=\"btn btn-primary\" id=\"uploadBack\" value=\"Upload\" />
\t\t</form>
\t\t<br /><br />
      </div>
      <!--<div class=\"modal-footer\">
        <button type=\"button\" class=\"btn btn-secondary\" data-bs-dismiss=\"modal\">Close</button>
        <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
      </div> -->
    </div>
  </div>
</div>
 <!-- Modal End -->

 <div id=\"myModalLO\" class=\"modal\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
          <div class=\"modal-header\">
            <h1 class=\"modal-title fs-5\" id=\"exampleModalLabel\">Delete Learning Object?</h1>
            <button type=\"button\" id=\"closelBtnLO\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"Close\"></button>
          </div>
          <div class=\"modal-body\">
        <p>Are you sure you want to delete the learning item (LO) you’ve added? You’ll not be able to undo it.</p>
        </div>

        <div class=\"modal-footer\">
            <button id=\"cancelBtnLO\" class=\"cancelbtn\">Cancel</button>
            <button id=\"confirmBtnLO\" class=\"deletebtn\">Yes Delete</button>
            
          </div>
      </div>
    </div> 

</div>
    <footer>
        <div class=\"footersection\">
        <p>©2023 PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of Its subsidiaries or affiliates.</p>

        <ul>
            <li><a href=\"#\"> Help Center </a></li>
            <li><a href=\"#\"> Privacy Policy</a></li>
            <li><a href=\"#\"> Cookie Notice</a></li>
            <li><a href=\"#\"> Terms & Conditions</a></li>            
        </ul>
    </div>
    </footer>
    <!--script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js\"
        integrity=\"sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4\"
        crossorigin=\"anonymous\"></script-->
<!--/body>

</html-->

<span 
id = \"pathwayDetails\"
pathwayId = \"{{pathwayId}}\"
changeSectionPositionUrl = \"{{path_for('changeSectionPosition')}}\"
changeLOPositionUrl = \"{{path_for('changeLOPosition')}}\"
deleteLO = \"{{path_for('deleteLO')}}\"
deleteSubSectionUrl = \"{{path_for('deleteSubSection')}}\"
publishPathwayUrl = \"{{path_for('publishPathway')}}\"
saveMinimumComplitionUrl = \"{{path_for(\"saveMinimumComplition\")}}\"
saveSequenceStartUrl = \"{{path_for('saveSequenceStart')}}\"
sequenceUnlockUrl = \"{{path_for('sequenceUnlock')}}\"
addBranchUrl = \"{{path_for('addBranch')}}\"
deletePathwayUrl = \"{{path_for('deletePathway')}}\"
taskListUrl = \"{{path_for('taskList', {lang: lang})}}\"
uploadBackGroungImageUrl = \"{{path_for('uploadBackGroungImage', {'id': pathwayId})}}\"
>
</span>

<script src=\"{{constant('HTTP_SERVER')}}js/pagejs/pathway_details.js?v={{ date().timestamp }}\"></script>

{% endblock %}", "Org_1/Home/pathway_details.twig", "/home/phpapp/pwc_qc/templates/Org_1/Home/pathway_details.twig");
    }
}
