<?php
return [
    'settings' => [
        'displayErrorDetails' => true, // set to false in production
        'addContentLengthHeader' => false, // Allow the web server to send the content-length header
        'determineRouteBeforeAppMiddleware' => true,

        // View settings
        'view' => [
            'template_path' => __DIR__ . '/../templates',
            'twig' => [
                'cache' => __DIR__ . '/../cache/twig',
                'debug' => true,
                'auto_reload' => true,
            ],
        ],

        // doctrine settings
        'doctrine' => [
            'meta' => [
                'entity_path' => [
                    __DIR__ . '/src/Entity'
                ],
                'auto_generate_proxies' => true,
                'proxy_dir' =>  __DIR__.'/../cache/proxies',
                'cache' => null,
            ],
            'connection' => [
              'driver' => 'pdo_sqlite',
              'path' => __DIR__.'/../sql/blog.sqlite'
            ]
        ],

        // monolog settings
        'logger' => [
            'name' => 'app',
            'path' => __DIR__ . '/../log/app.log',
        ],

		// JWT
		'jwt' => [
			'path' => ['/member'],
            'ignore' => ["/member/login"],
            'secret' => 'supersecretkeyyoushouldnotcommittogithub',
            'validity' => 3600,
            'refresh' => 1800, /* Refresh the jwt/cookie each */
            'relaxed' => ['127.0.0.1', 'localhost', 'slim3.dev.local'], /* Url without HTTPS check */
            'algorithm' => 'HS256'
        ],

        'db' => [
            'driver' => 'pgsql',
            'host' => 'pwc-qc.cym1rjhksvpk.ap-south-1.rds.amazonaws.com',
            'database' => 'pwc',
            'username' => 'pwc',
            'password' => 'pwcqc',
            'charset' => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix' => '',
        ],
    ],
];
