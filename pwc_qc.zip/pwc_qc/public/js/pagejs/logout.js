localStorage.clear();
sessionStorage.clear();